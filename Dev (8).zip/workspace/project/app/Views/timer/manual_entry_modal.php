<?php
/**
 * Manual time entry modal.
 *
 * @var list<array<string, mixed>> $projects
 * @var bool $canManual
 */

$projects = $projects ?? [];
$canManual = $canManual ?? false;
$nowLocal = FormatHelper::datetime(gmdate('Y-m-d H:i:s'), 'Y-m-d\TH:i');
$startDefault = old('start_time', $nowLocal);
$endDefault   = old('end_time', $nowLocal);
$showManual   = !empty($showManual);
$openOnError  = field_error('start_time') || field_error('end_time') || field_error('project_id') || $showManual;
?>
<div class="modal fade" id="manualEntryModal" tabindex="-1" aria-labelledby="manualEntryTitle" aria-hidden="true"
     data-open="<?= $openOnError ? '1' : '0' ?>">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <form method="post" action="<?= e(url('/time/manual')) ?>" id="manualEntryForm" class="modal-content" novalidate data-single-submit>
            <?= csrf_field() ?>
            <div class="modal-header">
                <h2 class="modal-title h5" id="manualEntryTitle">Add time</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="manual_project_id" class="form-label">Project</label>
                        <select id="manual_project_id" name="project_id" required
                                class="form-select<?= field_error('project_id') ? ' is-invalid' : '' ?>"
                                data-timer-project-select>
                            <option value="">Choose a project</option>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?= (int) $project['id'] ?>"
                                        data-billable="<?= (int) ($project['is_billable'] ?? 1) ?>"
                                    <?= (string) old('project_id') === (string) $project['id'] ? ' selected' : '' ?>>
                                    <?= e($project['name']) ?><?= !empty($project['client_name']) ? ' · ' . e($project['client_name']) : '' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (field_error('project_id')): ?><div class="invalid-feedback"><?= e(field_error('project_id')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="manual_task_id" class="form-label">Task</label>
                        <select id="manual_task_id" name="task_id" class="form-select<?= field_error('task_id') ? ' is-invalid' : '' ?>"
                                data-timer-task-select data-selected-task="<?= e(old('task_id')) ?>">
                            <option value="">No task</option>
                        </select>
                        <?php if (field_error('task_id')): ?><div class="invalid-feedback"><?= e(field_error('task_id')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <label for="manual_start_time" class="form-label">Start</label>
                        <input type="datetime-local" id="manual_start_time" name="start_time" required
                               class="form-control<?= field_error('start_time') ? ' is-invalid' : '' ?>"
                               value="<?= e($startDefault) ?>">
                        <?php if (field_error('start_time')): ?><div class="invalid-feedback"><?= e(field_error('start_time')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <label for="manual_end_time" class="form-label">End</label>
                        <input type="datetime-local" id="manual_end_time" name="end_time" required
                               class="form-control<?= field_error('end_time') ? ' is-invalid' : '' ?>"
                               value="<?= e($endDefault) ?>">
                        <?php if (field_error('end_time')): ?><div class="invalid-feedback"><?= e(field_error('end_time')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <label for="manual_break_minutes" class="form-label">Break (minutes)</label>
                        <input type="number" id="manual_break_minutes" name="break_minutes" min="0" max="1440" step="1"
                               class="form-control<?= field_error('break_minutes') ? ' is-invalid' : '' ?>"
                               value="<?= e(old('break_minutes', '0')) ?>">
                        <?php if (field_error('break_minutes')): ?><div class="invalid-feedback"><?= e(field_error('break_minutes')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-12">
                        <label for="manual_description" class="form-label">Description</label>
                        <input type="text" id="manual_description" name="description" maxlength="255"
                               class="form-control<?= field_error('description') ? ' is-invalid' : '' ?>"
                               value="<?= e(old('description')) ?>">
                        <?php if (field_error('description')): ?><div class="invalid-feedback"><?= e(field_error('description')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-12">
                        <div class="form-check">
                            <input type="hidden" name="is_billable" value="0">
                            <input class="form-check-input" type="checkbox" value="1" id="manual_is_billable" name="is_billable"
                                <?= old('is_billable', '1') !== '0' ? ' checked' : '' ?>>
                            <label class="form-check-label" for="manual_is_billable">Billable</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <?php if ($canManual): ?>
                    <button type="submit" class="btn btn-primary">Save entry</button>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>
