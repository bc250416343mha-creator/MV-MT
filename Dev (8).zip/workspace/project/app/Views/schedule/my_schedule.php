<?php
/**
 * Timeline of the signed-in user's upcoming planned blocks.
 *
 * @var array<string, array{label: string, items: list<array<string, mixed>>}> $groups
 * @var bool $canTimer
 * @var bool $canCreate
 * @var bool $canTeam
 * @var string $activeTab
 */

$groups    = $groups ?? [];
$canTimer  = $canTimer ?? false;
$canCreate = $canCreate ?? false;
$canTeam   = $canTeam ?? false;
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">My schedule</h2>
        <p class="page-lead">Upcoming planned blocks. Start a timer when you begin the work.</p>
    </div>
    <?php if ($canCreate): ?>
        <button type="button" class="btn btn-primary" id="scheduleNewBtn">
            <i class="fa-solid fa-plus me-1" aria-hidden="true"></i>Plan work
        </button>
    <?php endif; ?>
</div>

<nav class="filter-tabs" aria-label="Schedule views">
    <a class="filter-tab" href="<?= e(url('/schedule')) ?>">Calendar</a>
    <a class="filter-tab is-active" href="<?= e(url('/schedule/my')) ?>">My schedule</a>
    <?php if ($canTeam): ?>
        <a class="filter-tab" href="<?= e(url('/schedule/team')) ?>">Team</a>
    <?php endif; ?>
</nav>

<?php if ($groups === []): ?>
    <section class="panel">
        <div class="empty-state">
            <i class="fa-regular fa-calendar" aria-hidden="true"></i>
            <p>Nothing planned from today onward.</p>
        </div>
    </section>
<?php else: ?>
    <?php foreach ($groups as $day): ?>
        <section class="panel mb-3">
            <div class="panel-head">
                <h2 class="panel-title"><?= e($day['label']) ?></h2>
            </div>
            <ul class="schedule-timeline">
                <?php foreach ($day['items'] as $block): ?>
                    <?php
                    $statusClass = match ((string) $block['status']) {
                        'In Progress' => 'active',
                        'Completed'   => 'completed',
                        'Missed'      => 'cancelled',
                        'Cancelled'   => 'archived',
                        'Rescheduled' => 'hold',
                        default       => 'planning',
                    };
                    ?>
                    <li>
                        <span class="timeline-time mono">
                            <?= e(FormatHelper::datetime((string) $block['start_datetime'], 'H:i')) ?>
                            –
                            <?= e(FormatHelper::datetime((string) $block['end_datetime'], 'H:i')) ?>
                        </span>
                        <span class="timeline-body">
                            <strong><?= e($block['project_name']) ?></strong>
                            <?php if (!empty($block['task_name'])): ?>
                                <span class="text-secondary"> · <?= e($block['task_name']) ?></span>
                            <?php endif; ?>
                            <?php if (!empty($block['notes'])): ?>
                                <div class="small text-secondary"><?= e($block['notes']) ?></div>
                            <?php endif; ?>
                        </span>
                        <span class="status-badge status-<?= e($statusClass) ?>"><?= e($block['status']) ?></span>
                        <span class="timeline-hours mono"><?= e(number_format((float) $block['estimated_hours'], 1)) ?>h</span>
                        <?php if ($canTimer && $block['status'] !== 'Cancelled' && $block['status'] !== 'Completed'): ?>
                            <button type="button" class="btn btn-sm btn-primary"
                                    data-timer-start
                                    data-project-id="<?= (int) $block['project_id'] ?>"
                                    <?= !empty($block['task_id']) ? 'data-task-id="' . (int) $block['task_id'] . '"' : '' ?>>
                                Start timer
                            </button>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endforeach; ?>
<?php endif; ?>

<div id="scheduleCalendar"
     hidden
     data-view="week"
     data-user-id="<?= (int) AuthHelper::id() ?>"
     data-events-url="<?= e(url('/schedule/events')) ?>"
     data-store-url="<?= e(url('/schedule')) ?>"
     data-tasks-url="<?= e(url('/schedule/tasks')) ?>"
     data-assignees-url="<?= e(url('/schedule/assignees')) ?>"
     data-timezone="<?= e(FormatHelper::displayTimezone()) ?>"
     data-can-create="<?= $canCreate ? '1' : '0' ?>"
     data-can-edit="<?= !empty($canEdit) ? '1' : '0' ?>"
     data-can-delete="<?= !empty($canDelete) ? '1' : '0' ?>"
     data-has-tasks="<?= !empty($hasTasks) ? '1' : '0' ?>">
</div>

<?php require APP_PATH . '/Views/schedule/modal_form.php'; ?>
