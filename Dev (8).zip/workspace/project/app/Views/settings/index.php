<?php
/**
 * System settings form (Phase 9).
 *
 * @var array<string, string> $settings
 * @var list<string> $timezones
 * @var list<string> $currencies
 */

$val = static fn (string $key, string $default = ''): string => old($key, (string) ($settings[$key] ?? $default));
$selectedZone = old('default_timezone', (string) ($settings['default_timezone'] ?? 'UTC'));
$selectedCurrency = old('currency', (string) ($settings['currency'] ?? 'USD'));
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">System settings</h2>
        <p class="page-lead">Company identity, billing defaults and the working day.</p>
    </div>
</div>

<div class="row g-4">
    <div class="col-xl-8">
        <section class="panel">
            <div class="panel-head">
                <h2 class="panel-title">General &amp; billing</h2>
            </div>
            <form method="post" action="<?= e(url('/settings')) ?>" novalidate data-single-submit class="panel-body">
                <?= csrf_field() ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="company_name" class="form-label">Company name</label>
                        <input type="text" id="company_name" name="company_name" maxlength="160" required
                               class="form-control<?= field_error('company_name') ? ' is-invalid' : '' ?>" value="<?= e($val('company_name')) ?>">
                        <?php if (field_error('company_name')): ?><div class="invalid-feedback"><?= e(field_error('company_name')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-3">
                        <label for="currency" class="form-label">Currency code</label>
                        <select id="currency" name="currency" class="form-select<?= field_error('currency') ? ' is-invalid' : '' ?>">
                            <?php foreach ($currencies as $currency): ?>
                                <option value="<?= e($currency) ?>"<?= $selectedCurrency === $currency ? ' selected' : '' ?>><?= e($currency) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (field_error('currency')): ?><div class="invalid-feedback"><?= e(field_error('currency')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-3">
                        <label for="currency_symbol" class="form-label">Currency symbol</label>
                        <input type="text" id="currency_symbol" name="currency_symbol" maxlength="6" required
                               class="form-control<?= field_error('currency_symbol') ? ' is-invalid' : '' ?>" value="<?= e($val('currency_symbol', '$')) ?>">
                        <?php if (field_error('currency_symbol')): ?><div class="invalid-feedback"><?= e(field_error('currency_symbol')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="default_hourly_rate" class="form-label">Default hourly rate</label>
                        <input type="number" id="default_hourly_rate" name="default_hourly_rate" min="0" step="0.01" inputmode="decimal" required
                               class="form-control<?= field_error('default_hourly_rate') ? ' is-invalid' : '' ?>" value="<?= e($val('default_hourly_rate', '0')) ?>">
                        <?php if (field_error('default_hourly_rate')): ?><div class="invalid-feedback"><?= e(field_error('default_hourly_rate')) ?></div><?php endif; ?>
                        <div class="form-text">Used when a project or person has no rate of their own.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="working_hours_per_day" class="form-label">Working hours per day</label>
                        <input type="number" id="working_hours_per_day" name="working_hours_per_day" min="1" max="24" step="0.5" inputmode="decimal" required
                               class="form-control<?= field_error('working_hours_per_day') ? ' is-invalid' : '' ?>" value="<?= e($val('working_hours_per_day', '8')) ?>">
                        <?php if (field_error('working_hours_per_day')): ?><div class="invalid-feedback"><?= e(field_error('working_hours_per_day')) ?></div><?php endif; ?>
                        <div class="form-text">Capacity shown on schedule and workload views.</div>
                    </div>
                    <div class="col-12">
                        <label for="default_timezone" class="form-label">Default timezone</label>
                        <select id="default_timezone" name="default_timezone" class="form-select<?= field_error('default_timezone') ? ' is-invalid' : '' ?>" required>
                            <?php foreach ($timezones as $zone): ?>
                                <option value="<?= e($zone) ?>"<?= $zone === $selectedZone ? ' selected' : '' ?>><?= e(str_replace('_', ' ', $zone)) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (field_error('default_timezone')): ?><div class="invalid-feedback"><?= e(field_error('default_timezone')) ?></div><?php endif; ?>
                        <div class="form-text">Stored data stays in UTC; this is only the display default.</div>
                    </div>
                </div>
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">Save settings</button>
                </div>
            </form>
        </section>
    </div>
</div>
