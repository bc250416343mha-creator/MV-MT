<?php
declare(strict_types=1);

$me = AuthHelper::user() ?? ['name' => '', 'email' => '', 'role' => ''];
$current = Request::current()->path();
$appName = (string) Config::get('app.name', 'TimeTrack');

$groups = [
    'TRACK' => [
        ['label' => 'Dashboard', 'icon' => 'fa-gauge-high', 'path' => '/dashboard', 'permission' => 'dashboard.view'],
        ['label' => 'Time Tracker', 'icon' => 'fa-clock', 'path' => '/time', 'permission' => 'time.view_own', 'controller' => 'TimerController'],
        ['label' => 'Timesheet', 'icon' => 'fa-file-lines', 'path' => '/timesheets', 'permission' => 'time.view_own', 'controller' => 'TimesheetController'],
        ['label' => 'Calendar', 'icon' => 'fa-calendar-days', 'path' => '/schedule/my', 'permission' => 'schedule.view', 'controller' => 'ScheduleController'],
    ],
    'MANAGE' => [
        ['label' => 'Approvals', 'icon' => 'fa-circle-check', 'path' => '/timesheets/team', 'permission' => 'time.approve', 'controller' => 'TimesheetController', 'badge' => true],
        ['label' => 'Projects', 'icon' => 'fa-diagram-project', 'path' => '/projects', 'permission' => 'projects.view', 'controller' => 'ProjectController'],
        ['label' => 'Team', 'icon' => 'fa-users', 'path' => '/projects', 'permission' => 'projects.view', 'controller' => 'ProjectController'],
        ['label' => 'Clients', 'icon' => 'fa-building', 'path' => '/clients', 'permission' => 'clients.view', 'controller' => 'ClientController'],
        ['label' => 'Schedule', 'icon' => 'fa-calendar-week', 'path' => '/schedule', 'permission' => 'schedule.view', 'controller' => 'ScheduleController'],
    ],
    'SYSTEM' => [
        ['label' => 'Users', 'icon' => 'fa-user-gear', 'path' => '/users', 'permission' => 'users.view', 'controller' => 'UserController'],
        ['label' => 'Activity log', 'icon' => 'fa-clipboard-list', 'path' => '/settings/audit-logs', 'permission' => 'activity.view', 'controller' => 'SettingsController'],
        ['label' => 'Settings', 'icon' => 'fa-sliders', 'path' => '/settings', 'permission' => 'settings.manage', 'controller' => 'SettingsController'],
    ],
];

$isActive = static fn (string $path): bool => $current === $path || str_starts_with($current, $path . '/');
$initials = '';
foreach (array_slice(preg_split('/\s+/', trim((string) $me['name'])) ?: [], 0, 2) as $part) {
    $initials .= mb_strtoupper(mb_substr($part, 0, 1, 'UTF-8'), 'UTF-8');
}
$initials = $initials !== '' ? $initials : '?';
try {
    $unreadCount = (int) Database::fetchValue('SELECT COUNT(*) FROM notifications WHERE user_id = :id AND is_read = 0', ['id' => (int) AuthHelper::id()]);
} catch (Throwable) { $unreadCount = 0; }
try {
    $recentNotifications = (new Notification())->recent((int) AuthHelper::id(), 6);
} catch (Throwable) { $recentNotifications = []; }
try {
    $pendingCount = PermissionHelper::has('time.approve') ? (int) Database::fetchValue("SELECT COUNT(*) FROM timesheets WHERE status = 'Submitted'") : 0;
} catch (Throwable) { $pendingCount = 0; }
?>
<aside class="app-sidebar offcanvas-lg offcanvas-start" tabindex="-1" id="appSidebar" aria-label="Main navigation">
    <div class="sidebar-brand">
        <a href="<?= e(url('/dashboard')) ?>" class="brand-link">
            <span class="brand-mark" aria-hidden="true"><i class="fa-solid fa-stopwatch"></i></span>
            <span class="brand-name"><?= e($appName) ?></span>
        </a>
        <button type="button" class="btn-close d-lg-none" data-bs-dismiss="offcanvas" data-bs-target="#appSidebar" aria-label="Close menu"></button>
    </div>
    <div class="workspace-switcher"><span class="workspace-dot"></span><span class="workspace-name">My Workspace</span><i class="fa-solid fa-ellipsis ms-auto" aria-hidden="true"></i></div>
    <nav class="sidebar-nav">
        <?php foreach ($groups as $heading => $items): ?>
            <div class="sidebar-heading"><?= e($heading) ?></div>
            <ul class="nav flex-column">
            <?php foreach ($items as $item): ?>
                <?php if (isset($item['controller']) && !is_file(APP_PATH . '/Controllers/' . $item['controller'] . '.php')) continue; if (!PermissionHelper::has($item['permission'])) continue; $active = $isActive($item['path']); ?>
                <li class="nav-item"><a class="sidebar-link<?= $active ? ' active' : '' ?>" href="<?= e(url($item['path'])) ?>" <?= $active ? 'aria-current="page"' : '' ?>><i class="fa-solid <?= e($item['icon']) ?> fa-fw" aria-hidden="true"></i><span><?= e($item['label']) ?></span><?php if (!empty($item['badge']) && $pendingCount > 0): ?><span class="sidebar-badge">!</span><?php endif; ?></a></li>
            <?php endforeach; ?>
            </ul>
        <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
        <a class="sidebar-link<?= $isActive('/profile') ? ' active' : '' ?>" href="<?= e(url('/profile')) ?>"><i class="fa-solid fa-gear fa-fw" aria-hidden="true"></i><span>Settings</span></a>
        <div class="sidebar-user"><span class="avatar" aria-hidden="true"><?= e($initials) ?></span><span class="sidebar-user-text"><span class="sidebar-user-name"><?= e($me['name']) ?></span><span class="sidebar-user-role"><?= e(ucfirst((string) $me['role'])) ?></span></span></div>
    </div>
</aside>
<div class="app-main">
    <header class="app-topbar">
        <button class="btn btn-icon d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#appSidebar" aria-controls="appSidebar" aria-label="Open menu"><i class="fa-solid fa-bars" aria-hidden="true"></i></button>
        <div class="topbar-workspace"><strong><?= e($appName) ?></strong><span>Time &amp; project management</span></div>
        <div class="topbar-actions">
            <div class="dropdown">
                <button class="btn btn-icon position-relative" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside"
                        aria-expanded="false" aria-label="Notifications"
                        data-notification-toggle data-url="<?= e(url('/notifications/unread')) ?>">
                    <i class="fa-regular fa-bell" aria-hidden="true"></i>
                    <span class="badge-dot" data-notification-badge<?= $unreadCount > 0 ? '' : ' hidden' ?>><?= $unreadCount > 9 ? '9+' : (int) $unreadCount ?></span>
                </button>
                <div class="dropdown-menu dropdown-menu-end notification-menu" data-notification-menu>
                    <div class="notification-head">
                        <strong>Notifications</strong>
                        <button type="button" class="btn btn-link btn-sm p-0" data-notification-read-all data-url="<?= e(url('/notifications/read-all')) ?>">Mark all read</button>
                    </div>
                    <div class="notification-list" data-notification-list>
                        <?php if ($recentNotifications === []): ?>
                            <div class="notification-empty" data-notification-empty>You are all caught up.</div>
                        <?php else: ?>
                            <?php foreach ($recentNotifications as $note): ?>
                                <a class="notification-item<?= (int) $note['is_read'] === 0 ? ' is-unread' : '' ?>"
                                   href="<?= e($note['link'] ?: url('/dashboard')) ?>"
                                   data-notification-item data-id="<?= (int) $note['id'] ?>"
                                   data-read-url="<?= e(url('/notifications/' . (int) $note['id'] . '/read')) ?>">
                                    <span class="feed-icon feed-<?= e((string) $note['type']) ?>" aria-hidden="true"><i class="fa-solid <?= e($note['type'] === 'success' ? 'fa-circle-check' : ($note['type'] === 'warning' ? 'fa-triangle-exclamation' : ($note['type'] === 'danger' ? 'fa-circle-exclamation' : 'fa-circle-info'))) ?>"></i></span>
                                    <span class="notification-body">
                                        <span class="notification-title"><?= e($note['title']) ?></span>
                                        <?php if (!empty($note['message'])): ?><span class="notification-text"><?= e($note['message']) ?></span><?php endif; ?>
                                        <span class="notification-time"><?= e(FormatHelper::datetime((string) $note['created_at'], 'M j, H:i')) ?></span>
                                    </span>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <a class="notification-foot" href="<?= e(url('/dashboard')) ?>#notifications">View all notifications</a>
                </div>
            </div>
            <button class="btn btn-icon" type="button" data-theme-toggle aria-label="Toggle dark mode" title="Toggle dark mode"><i class="fa-regular fa-moon" aria-hidden="true"></i></button>
            <div class="dropdown"><button class="btn btn-user dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><span class="avatar avatar-sm" aria-hidden="true"><?= e($initials) ?></span><span class="d-none d-md-inline"><?= e($me['name']) ?></span></button><ul class="dropdown-menu dropdown-menu-end"><li class="dropdown-header"><?= e($me['email']) ?></li><li><a class="dropdown-item" href="<?= e(url('/profile')) ?>"><i class="fa-solid fa-user-gear fa-fw me-2" aria-hidden="true"></i>Settings</a></li><li><hr class="dropdown-divider"></li><li><form method="post" action="<?= e(url('/logout')) ?>" class="m-0"><?= csrf_field() ?><button type="submit" class="dropdown-item"><i class="fa-solid fa-arrow-right-from-bracket fa-fw me-2" aria-hidden="true"></i>Sign out</button></form></li></ul></div>
        </div>
    </header>
    <main class="app-content" id="main-content">
