-- =====================================================================
--  TimeTrack: database schema (Phase 1)
--  MySQL 8+ / MariaDB 10.4+, InnoDB, utf8mb4.
--
--  Import with phpMyAdmin (select your database first) or:
--      mysql -u USER -p DATABASE < database/schema.sql
--
--  Safe to re-run: every table uses CREATE TABLE IF NOT EXISTS.
--  Timestamps are stored in UTC (the app sets the session time zone to +00:00).
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- roles: admin, manager, employee, client
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `roles` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name`         VARCHAR(30)  NOT NULL,
    `display_name` VARCHAR(60)  NOT NULL,
    `description`  VARCHAR(255) NULL,
    `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_roles_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- permissions: fine-grained abilities, named "module.action"
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `permissions` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name`         VARCHAR(60)  NOT NULL,
    `display_name` VARCHAR(100) NOT NULL,
    `module`       VARCHAR(40)  NOT NULL,
    `description`  VARCHAR(255) NULL,
    `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_permissions_name` (`name`),
    KEY `idx_permissions_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- role_permissions: which role may do what
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `role_permissions` (
    `role_id`       INT UNSIGNED NOT NULL,
    `permission_id` INT UNSIGNED NOT NULL,
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`role_id`, `permission_id`),
    KEY `idx_role_permissions_permission` (`permission_id`),
    CONSTRAINT `fk_role_permissions_role`
        FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_role_permissions_permission`
        FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- users
--
-- NOTE: `role_id` is the authoritative link to the roles table (used for
-- permissions). `role` is the same role's name kept alongside it because the
-- existing AuthMiddleware reads users.role on every request. Whenever code
-- changes a user's role it must update BOTH columns together.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
    `id`                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `role_id`               INT UNSIGNED NOT NULL,
    `role`                  ENUM('admin','manager','employee','client') NOT NULL DEFAULT 'employee',
    `name`                  VARCHAR(120) NOT NULL,
    `email`                 VARCHAR(190) NOT NULL,
    `password`              VARCHAR(255) NOT NULL,
    `phone`                 VARCHAR(30)  NULL,
    `job_title`             VARCHAR(100) NULL,
    `hourly_rate`           DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `timezone`              VARCHAR(64)  NOT NULL DEFAULT 'UTC',
    `status`                ENUM('active','inactive','suspended') NOT NULL DEFAULT 'active',
    `failed_login_attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
    `locked_until`          DATETIME     NULL,
    `last_login_at`         DATETIME     NULL,
    `last_login_ip`         VARCHAR(45)  NULL,
    `password_changed_at`   DATETIME     NULL,
    `created_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_users_email` (`email`),
    KEY `idx_users_status` (`status`),
    KEY `idx_users_role_id` (`role_id`),
    KEY `idx_users_role_status` (`role`, `status`),
    CONSTRAINT `fk_users_role`
        FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- activity_logs: who did what, to which record (audit trail)
-- Column names match what LoggerHelper::audit() inserts.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `activity_logs` (
    `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`     INT UNSIGNED NULL,
    `action`      VARCHAR(100) NOT NULL,
    `module`      VARCHAR(60)  NULL,
    `entity_type` VARCHAR(60)  NULL,
    `entity_id`   INT UNSIGNED NULL,
    `record_id`   INT UNSIGNED NULL,
    `ip_address`  VARCHAR(45)  NULL,
    `user_agent`  VARCHAR(255) NULL,
    `meta`        LONGTEXT     NULL,
    `old_value`   LONGTEXT     NULL,
    `new_value`   LONGTEXT     NULL,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_activity_user` (`user_id`),
    KEY `idx_activity_action` (`action`),
    KEY `idx_activity_module` (`module`),
    KEY `idx_activity_entity` (`entity_type`, `entity_id`),
    KEY `idx_activity_created` (`created_at`),
    CONSTRAINT `fk_activity_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- notifications: in-app messages for a user
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
    `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`    INT UNSIGNED NOT NULL,
    `type`       VARCHAR(40)  NOT NULL DEFAULT 'info',
    `title`      VARCHAR(160) NOT NULL,
    `message`    VARCHAR(500) NULL,
    `link`       VARCHAR(255) NULL,
    `is_read`    TINYINT(1)   NOT NULL DEFAULT 0,
    `read_at`    DATETIME     NULL,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_notifications_user_read` (`user_id`, `is_read`, `created_at`),
    CONSTRAINT `fk_notifications_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- settings: key/value system configuration
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `setting_key`   VARCHAR(80)  NOT NULL,
    `setting_value` TEXT         NULL,
    `setting_type`  ENUM('string','int','bool','json') NOT NULL DEFAULT 'string',
    `setting_group` VARCHAR(40)  NOT NULL DEFAULT 'general',
    `description`   VARCHAR(255) NULL,
    `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_settings_key` (`setting_key`),
    KEY `idx_settings_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- audit_logs: updatable alias of activity_logs.
-- LoggerHelper::audit() writes to a table called audit_logs; this view lets
-- those inserts land in activity_logs without changing existing code.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW `audit_logs` AS
    SELECT `id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`, `record_id`,
           `ip_address`, `user_agent`, `meta`, `old_value`, `new_value`, `created_at`
    FROM `activity_logs`;

-- =====================================================================
--  Phase 2: clients, projects, project members
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- clients
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `clients` (
    `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name`       VARCHAR(160) NOT NULL,
    `email`      VARCHAR(190) NULL,
    `phone`      VARCHAR(30)  NULL,
    `company`    VARCHAR(160) NULL,
    `address`    VARCHAR(255) NULL,
    `status`     ENUM('active','inactive') NOT NULL DEFAULT 'active',
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_clients_status` (`status`),
    KEY `idx_clients_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- projects
-- Statuses: Planning, Active, On Hold, Completed, Cancelled, Archived
-- Priorities: Low, Medium, High, Urgent
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `projects` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `client_id`       INT UNSIGNED NOT NULL,
    `project_code`    VARCHAR(40)  NOT NULL,
    `name`            VARCHAR(160) NOT NULL,
    `description`     TEXT         NULL,
    `start_date`      DATE         NULL,
    `due_date`        DATE         NULL,
    `status`          ENUM('Planning','Active','On Hold','Completed','Cancelled','Archived') NOT NULL DEFAULT 'Planning',
    `priority`        ENUM('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
    `estimated_hours` DECIMAL(8,2)  NOT NULL DEFAULT 0.00,
    `budget`          DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `hourly_rate`     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `is_billable`     TINYINT(1)    NOT NULL DEFAULT 1,
    `manager_id`      INT UNSIGNED  NULL,
    `created_by`      INT UNSIGNED  NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_projects_code` (`project_code`),
    KEY `idx_projects_client` (`client_id`),
    KEY `idx_projects_status` (`status`),
    KEY `idx_projects_priority` (`priority`),
    KEY `idx_projects_manager` (`manager_id`),
    KEY `idx_projects_created_by` (`created_by`),
    KEY `idx_projects_dates` (`start_date`, `due_date`),
    CONSTRAINT `fk_projects_client`
        FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT `fk_projects_manager`
        FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_projects_created_by`
        FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- project_members: who can work on a project
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `project_members` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_id`   INT UNSIGNED NOT NULL,
    `user_id`      INT UNSIGNED NOT NULL,
    `project_role` VARCHAR(40)  NOT NULL DEFAULT 'member',
    `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_project_members` (`project_id`, `user_id`),
    KEY `idx_project_members_user` (`user_id`),
    CONSTRAINT `fk_project_members_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_project_members_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  Phase 4: planned schedules and recurrences
--  task_id is nullable and has no FK until the tasks table exists.
-- =====================================================================

-- ---------------------------------------------------------------------
-- schedules: planned work blocks for a person on a project
-- Statuses: Scheduled, In Progress, Completed, Missed, Cancelled, Rescheduled
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `schedules` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_id`      INT UNSIGNED NOT NULL,
    `task_id`         INT UNSIGNED NULL,
    `user_id`         INT UNSIGNED NOT NULL,
    `start_datetime`  DATETIME     NOT NULL,
    `end_datetime`    DATETIME     NOT NULL,
    `estimated_hours` DECIMAL(8,2) NOT NULL DEFAULT 0.00,
    `status`          ENUM('Scheduled','In Progress','Completed','Missed','Cancelled','Rescheduled') NOT NULL DEFAULT 'Scheduled',
    `notes`           TEXT         NULL,
    `created_by`      INT UNSIGNED NULL,
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_schedules_user_time` (`user_id`, `start_datetime`, `end_datetime`),
    KEY `idx_schedules_project` (`project_id`),
    KEY `idx_schedules_task` (`task_id`),
    KEY `idx_schedules_status` (`status`),
    KEY `idx_schedules_created_by` (`created_by`),
    CONSTRAINT `fk_schedules_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_schedules_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_schedules_created_by`
        FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- schedule_recurrences: how a planned block repeats
-- recurrence_type: daily, weekly, weekdays, custom
-- days_of_week: comma-separated ISO weekdays (1=Mon ... 7=Sun) for custom/weekly
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `schedule_recurrences` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `schedule_id`     INT UNSIGNED NOT NULL,
    `recurrence_type` ENUM('daily','weekly','weekdays','custom') NOT NULL DEFAULT 'weekly',
    `repeat_until`    DATE         NULL,
    `days_of_week`    VARCHAR(20)  NULL,
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_recurrence_schedule` (`schedule_id`),
    CONSTRAINT `fk_recurrence_schedule`
        FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
--  Phase 5: tasks inside projects
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- tasks: units of work inside a project
-- Statuses: Open, In Progress, Done
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tasks` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_id`      INT UNSIGNED NOT NULL,
    `name`            VARCHAR(160) NOT NULL,
    `description`     TEXT         NULL,
    `status`          ENUM('Open','In Progress','Done') NOT NULL DEFAULT 'Open',
    `estimated_hours` DECIMAL(8,2) NOT NULL DEFAULT 0.00,
    `due_date`        DATE         NULL,
    `created_by`      INT UNSIGNED NULL,
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_tasks_project_name` (`project_id`, `name`),
    KEY `idx_tasks_status` (`project_id`, `status`),
    KEY `idx_tasks_created_by` (`created_by`),
    CONSTRAINT `fk_tasks_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_tasks_created_by`
        FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- task_assignees: who a task is assigned to.
-- A task with no rows here is open to "Anyone" on the project.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `task_assignees` (
    `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `task_id`    INT UNSIGNED NOT NULL,
    `user_id`    INT UNSIGNED NOT NULL,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_task_assignees` (`task_id`, `user_id`),
    KEY `idx_task_assignees_user` (`user_id`),
    CONSTRAINT `fk_task_assignees_task`
        FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_task_assignees_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  Phase 6: server-authoritative active timer and time entries
-- =====================================================================

-- ---------------------------------------------------------------------
-- active_timers: at most one running timer per user (UNIQUE user_id)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `active_timers` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`         INT UNSIGNED NOT NULL,
    `project_id`      INT UNSIGNED NOT NULL,
    `task_id`         INT UNSIGNED NULL,
    `started_at`      DATETIME     NOT NULL,
    `last_activity_at` DATETIME    NOT NULL,
    `description`     VARCHAR(255) NULL,
    `is_billable`     TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_active_timers_user` (`user_id`),
    KEY `idx_active_timers_project` (`project_id`),
    KEY `idx_active_timers_task` (`task_id`),
    CONSTRAINT `fk_active_timers_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_active_timers_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_active_timers_task`
        FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- time_entries: completed timer runs and manual entries
-- Statuses: Pending, Approved, Rejected
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `time_entries` (
    `id`               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `user_id`          INT UNSIGNED  NOT NULL,
    `project_id`       INT UNSIGNED  NOT NULL,
    `task_id`          INT UNSIGNED  NULL,
    `schedule_id`      INT UNSIGNED  NULL,
    `start_time`       DATETIME      NOT NULL,
    `end_time`         DATETIME      NOT NULL,
    `duration_seconds` INT UNSIGNED  NOT NULL,
    `break_minutes`    INT UNSIGNED  NOT NULL DEFAULT 0,
    `description`      VARCHAR(255)  NULL,
    `is_billable`      TINYINT(1)    NOT NULL DEFAULT 1,
    `billable_rate`    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `status`           ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    `approved_by`      INT UNSIGNED  NULL,
    `approved_at`      DATETIME      NULL,
    `created_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_time_entries_user_start` (`user_id`, `start_time`),
    KEY `idx_time_entries_project` (`project_id`),
    KEY `idx_time_entries_task` (`task_id`),
    KEY `idx_time_entries_schedule` (`schedule_id`),
    KEY `idx_time_entries_status` (`status`),
    KEY `idx_time_entries_billable` (`is_billable`),
    KEY `idx_time_entries_approved_by` (`approved_by`),
    CONSTRAINT `fk_time_entries_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_time_entries_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT `fk_time_entries_task`
        FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_time_entries_schedule`
        FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_time_entries_approved_by`
        FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  Phase 7: weekly/monthly timesheets and multi-level approval
-- =====================================================================

-- ---------------------------------------------------------------------
-- timesheets: one row per user per period (week or month)
-- Statuses: Draft, Submitted, Approved, Rejected
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `timesheets` (
    `id`                INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `user_id`           INT UNSIGNED  NOT NULL,
    `start_date`        DATE          NOT NULL,
    `end_date`          DATE          NOT NULL,
    `total_seconds`     INT UNSIGNED  NOT NULL DEFAULT 0,
    `billable_seconds`  INT UNSIGNED  NOT NULL DEFAULT 0,
    `status`            ENUM('Draft','Submitted','Approved','Rejected') NOT NULL DEFAULT 'Draft',
    `submitted_at`      DATETIME      NULL,
    `approved_by`       INT UNSIGNED  NULL,
    `approved_at`       DATETIME      NULL,
    `rejection_reason`  VARCHAR(500)  NULL,
    `created_at`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_timesheets_user_period` (`user_id`, `start_date`, `end_date`),
    KEY `idx_timesheets_status` (`status`),
    KEY `idx_timesheets_submitted` (`submitted_at`),
    KEY `idx_timesheets_approved_by` (`approved_by`),
    CONSTRAINT `fk_timesheets_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_timesheets_approved_by`
        FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- timesheet_entries: which time entries are locked into a timesheet
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `timesheet_entries` (
    `timesheet_id`   INT UNSIGNED NOT NULL,
    `time_entry_id`  INT UNSIGNED NOT NULL,
    `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`timesheet_id`, `time_entry_id`),
    UNIQUE KEY `uq_timesheet_entries_entry` (`time_entry_id`),
    KEY `idx_timesheet_entries_timesheet` (`timesheet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
