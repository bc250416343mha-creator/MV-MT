<?php
/**
 * Route table. Each later phase appends its routes here.
 *
 * Conventions:
 *  - Handlers are [ControllerClass::class, 'method'] and receive (Request $request, array $params).
 *  - State-changing routes (post/put/patch/delete) get automatic CSRF verification.
 *  - Authorization is NOT declared here; it lives in each controller's constructor
 *    so it cannot be forgotten when a route is added.
 */

declare(strict_types=1);

return static function (Router $router): void {
    $router->get('/', [HomeController::class, 'index']);
    $router->get('/health', [HealthController::class, 'index']);
    $router->get('/admin/health', [HealthController::class, 'admin']);

    /* ---- Phase 1: authentication, profile, dashboard ---- */
    $router->get('/login', [AuthController::class, 'login']);
    $router->post('/login', [AuthController::class, 'authenticate']);
    $router->post('/logout', [AuthController::class, 'logout']);

    $router->get('/accept-invitation', [AuthController::class, 'acceptInvitation']);
    $router->post('/accept-invitation', [AuthController::class, 'completeInvitation']);
    $router->get('/forgot-password', [AuthController::class, 'forgotPassword']);
    $router->post('/forgot-password', [AuthController::class, 'sendPasswordReset']);
    $router->get('/reset-password', [AuthController::class, 'resetPasswordForm']);
    $router->post('/reset-password', [AuthController::class, 'resetPassword']);

    $router->get('/profile', [AuthController::class, 'profile']);
    $router->post('/profile', [AuthController::class, 'updateProfile']);
    $router->post('/profile/password', [AuthController::class, 'updatePassword']);

    $router->get('/dashboard', [DashboardController::class, 'index']);
    $router->post('/notifications/read', [DashboardController::class, 'markNotificationsRead']);
    $router->get('/notifications/unread', [NotificationController::class, 'getUnread']);
    $router->post('/notifications/read-all', [NotificationController::class, 'markAllAsRead']);
    $router->post('/notifications/{id:\d+}/read', [NotificationController::class, 'markAsRead']);

    /* ---- Phase 2: clients, projects, members ---- */
    $router->get('/clients', [ClientController::class, 'index']);
    $router->post('/clients', [ClientController::class, 'store']);
    $router->post('/clients/{id:\d+}', [ClientController::class, 'update']);
    $router->post('/clients/{id:\d+}/delete', [ClientController::class, 'destroy']);

    $router->get('/projects', [ProjectController::class, 'index']);
    $router->get('/projects/create', [ProjectController::class, 'create']);
    $router->post('/projects', [ProjectController::class, 'store']);
    $router->get('/projects/{id:\d+}', [ProjectController::class, 'show']);
    $router->get('/projects/{id:\d+}/dashboard', [ProjectController::class, 'dashboard']);
    $router->get('/projects/{id:\d+}/edit', [ProjectController::class, 'edit']);
    $router->post('/projects/{id:\d+}', [ProjectController::class, 'update']);
    $router->post('/projects/{id:\d+}/archive', [ProjectController::class, 'archive']);
    $router->post('/projects/{id:\d+}/delete', [ProjectController::class, 'destroy']);
    $router->post('/projects/{id:\d+}/members', [ProjectController::class, 'syncMembers']);

    /* ---- Phase 10: Clockify-style project page (Access, Note, Settings, favourite) ---- */
    $router->post('/projects/{id:\d+}/settings', [ProjectController::class, 'updateSettings']);
    $router->post('/projects/{id:\d+}/visibility', [ProjectController::class, 'visibility']);
    $router->post('/projects/{id:\d+}/note', [ProjectController::class, 'saveNote']);
    $router->post('/projects/{id:\d+}/favorite', [ProjectController::class, 'favorite']);
    $router->post('/projects/{id:\d+}/members/add', [ProjectController::class, 'addMembers']);
    $router->post('/projects/{id:\d+}/members/{uid:\d+}/role', [ProjectController::class, 'memberRole']);
    $router->post('/projects/{id:\d+}/members/{uid:\d+}/remove', [ProjectController::class, 'memberRemove']);

    /* ---- Phase 4: planned schedule and conflict detection ---- */
    $router->get('/schedule', [ScheduleController::class, 'calendar']);
    $router->get('/schedule/events', [ScheduleController::class, 'eventsJson']);
    $router->get('/schedule/my', [ScheduleController::class, 'mySchedule']);
    $router->get('/schedule/team', [ScheduleController::class, 'teamSchedule']);
    $router->get('/schedule/tasks', [ScheduleController::class, 'tasksJson']);
    $router->get('/schedule/assignees', [ScheduleController::class, 'assigneesJson']);
    $router->post('/schedule', [ScheduleController::class, 'store']);
    $router->post('/schedule/{id:\d+}', [ScheduleController::class, 'update']);
    $router->post('/schedule/{id:\d+}/time', [ScheduleController::class, 'updateEventTime']);
    $router->post('/schedule/{id:\d+}/delete', [ScheduleController::class, 'destroy']);

    /* ---- Phase 5: tasks inside projects (listed on the project page, "Tasks" tab) ---- */
    $router->post('/projects/{id:\d+}/tasks', [TaskController::class, 'store']);
    $router->post('/tasks/{id:\d+}', [TaskController::class, 'update']);
    $router->post('/tasks/{id:\d+}/status', [TaskController::class, 'status']);
    $router->post('/tasks/{id:\d+}/rename', [TaskController::class, 'rename']);
    $router->post('/tasks/{id:\d+}/assignees', [TaskController::class, 'assignees']);
    $router->post('/tasks/{id:\d+}/delete', [TaskController::class, 'destroy']);

    /* ---- Phase 6: server-authoritative timer and time entries ---- */
    $router->get('/time', [TimerController::class, 'index']);
    $router->get('/time/status', [TimerController::class, 'status']);
    $router->get('/time/active', [TimerController::class, 'active']);
    $router->get('/time/tasks', [TimerController::class, 'tasksJson']);
    $router->post('/time/start', [TimerController::class, 'start']);
    $router->post('/time/stop', [TimerController::class, 'stop']);
    $router->post('/time/pause', [TimerController::class, 'pause']);
    $router->post('/time/resume', [TimerController::class, 'resume']);
    $router->post('/time/ping', [TimerController::class, 'ping']);
    $router->post('/time/idle-response', [TimerController::class, 'idleResponse']);
    $router->post('/time/manual', [TimerController::class, 'manualStore']);
    $router->post('/time/{id:\d+}', [TimerController::class, 'updateEntry']);
    $router->post('/time/{id:\d+}/delete', [TimerController::class, 'deleteEntry']);
    $router->post('/time/{id:\d+}/description', [TimerController::class, 'updateDescription']);

    // Legacy /timer/* aliases. GET 301s to /time; POST still works but is deprecated.
    // CSRF still runs on POST before this handler (Router), so a 301 is never used for POST.
    $permanentTimerRedirect = static function (Request $request, array $params): void {
        $action = (string) ($params['action'] ?? '');
        $target = '/time' . ($action !== '' ? '/' . $action : '');
        $query  = $request->query();
        if ($query !== []) {
            $target .= '?' . http_build_query($query);
        }
        Response::redirect($target, 301);
    };
    $router->get('/timer', $permanentTimerRedirect);
    $router->get('/timer/{action:status|active|tasks}', $permanentTimerRedirect);

    $legacyTimerPost = static function (string $action): callable {
        return static function (Request $request, array $params) use ($action): void {
            header('Deprecation: true');
            header('Link: <' . FormatHelper::url('/time/' . $action) . '>; rel="successor-version"');
            LoggerHelper::warning('Deprecated route used', [
                'path'      => $request->path(),
                'canonical' => '/time/' . $action,
            ]);
            (new TimerController())->$action($request, $params);
        };
    };
    $router->post('/timer/start', $legacyTimerPost('start'));
    $router->post('/timer/stop', $legacyTimerPost('stop'));
    $router->post('/timer/pause', $legacyTimerPost('pause'));
    $router->post('/timer/resume', $legacyTimerPost('resume'));
    $router->post('/timer/ping', $legacyTimerPost('ping'));

    /* ---- Phase 7: weekly timesheet matrix and approval ---- */
    $router->get('/timesheets', [TimesheetController::class, 'myTimesheet']);
    $router->get('/timesheets/month', [TimesheetController::class, 'myMonth']);
    $router->post('/timesheets/submit', [TimesheetController::class, 'submit']);
    $router->post('/timesheets/submit-selected', [TimesheetController::class, 'submitSelected']);
    $router->get('/timesheets/team', [TimesheetController::class, 'teamTimesheets']);
    $router->post('/timesheets/batch-approve', [TimesheetController::class, 'batchApprove']);
    $router->get('/timesheets/{id:\d+}', [TimesheetController::class, 'show']);
    $router->post('/timesheets/{id:\d+}/approve', [TimesheetController::class, 'approveAction']);
    $router->post('/timesheets/{id:\d+}/reject', [TimesheetController::class, 'rejectAction']);

    /* ---- Phase 9: users, system settings and the audit trail ---- */
    $router->get('/users', [UserController::class, 'index']);
    $router->get('/users/create', [UserController::class, 'create']);
    $router->get('/users/invite', [InvitationController::class, 'create']);
    $router->post('/users/invite', [InvitationController::class, 'store']);
    $router->get('/users/invitations', [InvitationController::class, 'index']);
    $router->get('/users/invitations/{id:\d+}', [InvitationController::class, 'show']);
    $router->post('/users/invitations/{id:\d+}/resend', [InvitationController::class, 'resend']);
    $router->post('/users/invitations/{id:\d+}/cancel', [InvitationController::class, 'cancel']);
    $router->post('/users', [UserController::class, 'store']);
    $router->get('/users/{id:\d+}/edit', [UserController::class, 'edit']);
    $router->post('/users/{id:\d+}', [UserController::class, 'update']);
    $router->post('/users/{id:\d+}/delete', [UserController::class, 'destroy']);

    $router->get('/settings', [SettingsController::class, 'index']);
    $router->post('/settings', [SettingsController::class, 'update']);
    $router->post('/settings/branding', [SettingsController::class, 'updateBranding']);
    $router->post('/settings/branding/reset', [SettingsController::class, 'resetBranding']);
    $router->post('/settings/smtp', [SettingsController::class, 'updateSmtp']);
    $router->post('/settings/smtp/test', [SettingsController::class, 'testSmtp']);
    $router->get('/settings/audit-logs', [SettingsController::class, 'auditLogs']);

    /* ---- Phase 11: workspace identity, policies and permissions ---- */
    $router->get('/workspace', [WorkspaceController::class, 'index']);
    $router->post('/workspace/general', [WorkspaceController::class, 'updateGeneral']);
    $router->post('/workspace/features', [WorkspaceController::class, 'updateFeatures']);
    $router->post('/workspace/permissions', [WorkspaceController::class, 'updatePermissions']);

    /* ---- Fresh start: bulk data reset (admin only, password + typed confirmation) ---- */
    $router->get('/workspace/data-reset', [DataResetController::class, 'index']);
    $router->post('/workspace/data-reset/backup', [DataResetController::class, 'backup']);
    $router->post('/workspace/data-reset', [DataResetController::class, 'reset']);

    /* ---- Windows desktop activity agent ---- */
    $router->get('/agent', [DesktopAgentController::class, 'index']);
    $router->post('/agent/pairing-code', [DesktopAgentController::class, 'pairingCode']);
    $router->post('/agent/{id:\d+}/revoke', [DesktopAgentController::class, 'revoke']);
    $router->post('/api/agent/pair', [DesktopAgentController::class, 'pair'], ['csrf' => false]);
    $router->post('/api/agent/heartbeat', [DesktopAgentController::class, 'heartbeat'], ['csrf' => false]);

    /* ---- Data import ---- */
    $router->get('/import', [ImportController::class, 'index']);
    $router->post('/import', [ImportController::class, 'import']);

    /* ---- Step 19: Reports ---- */
    $router->get('/reports', [ReportController::class, 'index']);
    $router->get('/reports/summary', [ReportController::class, 'summary']);
    $router->get('/reports/detailed', [ReportController::class, 'detailed']);
    $router->get('/reports/weekly', [ReportController::class, 'weekly']);
    $router->get('/reports/attendance', [ReportController::class, 'attendance']);
    $router->get('/reports/assignments', [ReportController::class, 'assignments']);
    $router->get('/reports/export.csv', [ReportController::class, 'exportCsv']);
    $router->get('/reports/access', [ReportController::class, 'access']);
    $router->post('/reports/access', [ReportController::class, 'saveAccess']);

    /* ---- Phase 14: Team page (members, roles, projects, weekly workload) ---- */
    $router->get('/team', [TeamController::class, 'index']);
    $router->get('/team/{id:\d+}', [TeamController::class, 'show']);

    /* ---- Approval hierarchy: teams (admin) — Admin > Project > Project Manager > Team Manager > Team > Lead + Members ---- */
    $router->get('/teams', [TeamGroupController::class, 'index']);
    $router->get('/teams/create', [TeamGroupController::class, 'create']);
    $router->post('/teams', [TeamGroupController::class, 'store']);
    $router->get('/teams/{id:\d+}/edit', [TeamGroupController::class, 'edit']);
    $router->post('/teams/{id:\d+}', [TeamGroupController::class, 'update']);
    $router->post('/teams/{id:\d+}/delete', [TeamGroupController::class, 'destroy']);
};
