/**
 * Team setup form: live filter for the member list, and hide the people already chosen
 * as team lead or team manager from the member list (they are positions above the members).
 */
(function () {
    'use strict';

    var filter = document.querySelector('[data-team-filter]');
    var rows = Array.prototype.slice.call(document.querySelectorAll('[data-team-person]'));
    var manager = document.getElementById('team-manager');
    var lead = document.getElementById('team-lead');

    function apply() {
        var term = filter ? filter.value.trim().toLowerCase() : '';
        var skip = {};
        if (manager && manager.value !== '0') { skip[manager.value] = true; }
        if (lead && lead.value !== '0') { skip[lead.value] = true; }

        rows.forEach(function (row) {
            var matches = term === '' || (row.getAttribute('data-name') || '').indexOf(term) !== -1;
            var hidden = !!skip[row.getAttribute('data-user-id')];
            var box = row.querySelector('input[type="checkbox"]');
            if (hidden && box) { box.checked = false; }
            row.style.display = (matches && !hidden) ? '' : 'none';
        });
    }

    if (filter) { filter.addEventListener('input', apply); }
    if (manager) { manager.addEventListener('change', apply); }
    if (lead) { lead.addEventListener('change', apply); }
    apply();
})();
