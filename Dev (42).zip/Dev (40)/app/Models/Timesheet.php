<?php
/**
 * Weekly (and monthly) timesheets: matrix, submit, approve, reject.
 *
 * A timesheet is one user + one period. Submitting locks the week's time entries
 * into timesheet_entries. Approval locks them from employee edits; rejection
 * unlocks them and stores a feedback note.
 */

declare(strict_types=1);

final class Timesheet extends Model
{
    public const STATUS_DRAFT     = 'Draft';
    public const STATUS_SUBMITTED = 'Submitted';
    public const STATUS_APPROVED  = 'Approved';
    public const STATUS_REJECTED  = 'Rejected';

    public const STATUSES = [
        self::STATUS_DRAFT,
        self::STATUS_SUBMITTED,
        self::STATUS_APPROVED,
        self::STATUS_REJECTED,
    ];

    public const DAY_KEYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

    public const DAY_LABELS = [
        'mon' => 'Mon',
        'tue' => 'Tue',
        'wed' => 'Wed',
        'thu' => 'Thu',
        'fri' => 'Fri',
        'sat' => 'Sat',
        'sun' => 'Sun',
    ];

    protected string $table = 'timesheets';

    protected array $columns = [
        'id', 'user_id', 'start_date', 'end_date', 'submission_token',
        'total_seconds', 'billable_seconds', 'status',
        'submitted_at', 'approved_by', 'approved_at', 'rejection_reason',
        'created_at', 'updated_at',
    ];

    protected array $fillable = [
        'user_id', 'start_date', 'end_date', 'submission_token',
        'total_seconds', 'billable_seconds', 'status',
        'submitted_at', 'approved_by', 'approved_at', 'rejection_reason',
    ];

    /** True when the timesheets table has been installed. */
    public static function installed(): bool
    {
        return SchemaHelper::tableExists('timesheets');
    }

    /**
     * Pivot time entries by Project/Task across the workspace week with daily and row totals.
     *
     * @return array{
     *     week_start: string,
     *     week_end: string,
     *     days: list<array{key: string, date: string, label: string, short: string, is_today: bool, is_weekend: bool}>,
     *     rows: list<array<string, mixed>>,
     *     column_totals: array<string, int>,
     *     column_billable: array<string, int>,
     *     grand_total: int,
     *     billable_total: int,
     *     entry_count: int,
     *     timesheet: array<string, mixed>|null
     * }
     */
    public function getWeeklyMatrix(int $userId, string $weekStartDate): array
    {
        $bounds = self::weekBounds($weekStartDate);
        $days   = $this->dayMeta($bounds['start_local']);

        $emptyDays = [];
        $columnTotals = [];
        $columnBillable = [];
        foreach ($days as $day) {
            $emptyDays[$day['key']] = 0;
            $columnTotals[$day['key']] = 0;
            $columnBillable[$day['key']] = 0;
        }

        $entries = $this->entriesInRange($userId, $bounds['start_utc'], $bounds['end_utc']);

        $grouped = [];
        $entryCount = 0;
        $grandTotal = 0;
        $billableTotal = 0;

        foreach ($entries as $entry) {
            $localDate = FormatHelper::datetime((string) $entry['start_time'], 'Y-m-d');
            $dayKey    = $this->dayKeyForDate($localDate, $days);
            if ($dayKey === null) {
                continue;
            }

            $seconds  = (int) $entry['duration_seconds'];
            $billable = (int) $entry['is_billable'] === 1 ? $seconds : 0;
            $projectId = (int) $entry['project_id'];
            $taskId    = (int) ($entry['task_id'] ?? 0);
            $rowKey    = $projectId . ':' . $taskId;

            if (!isset($grouped[$rowKey])) {
                $grouped[$rowKey] = [
                    'project_id'       => $projectId,
                    'project_name'     => (string) ($entry['project_name'] ?? ''),
                    'project_code'     => (string) ($entry['project_code'] ?? ''),
                    'task_id'          => $taskId > 0 ? $taskId : null,
                    'task_name'        => (string) ($entry['task_name'] ?? ''),
                    'days'             => $emptyDays,
                    'billable_days'    => $emptyDays,
                    'total_seconds'    => 0,
                    'billable_seconds' => 0,
                    'entry_count'      => 0,
                ];
            }

            $grouped[$rowKey]['days'][$dayKey]          += $seconds;
            $grouped[$rowKey]['billable_days'][$dayKey] += $billable;
            $grouped[$rowKey]['total_seconds']          += $seconds;
            $grouped[$rowKey]['billable_seconds']       += $billable;
            $grouped[$rowKey]['entry_count']++;

            $columnTotals[$dayKey]   += $seconds;
            $columnBillable[$dayKey] += $billable;
            $grandTotal              += $seconds;
            $billableTotal           += $billable;
            $entryCount++;
        }

        uasort($grouped, static function (array $a, array $b): int {
            $byProject = strcasecmp((string) $a['project_name'], (string) $b['project_name']);
            if ($byProject !== 0) {
                return $byProject;
            }

            return strcasecmp((string) $a['task_name'], (string) $b['task_name']);
        });

        return [
            'week_start'      => $bounds['start_local']->format('Y-m-d'),
            'week_end'        => $bounds['end_local']->format('Y-m-d'),
            'days'            => $days,
            'rows'            => array_values($grouped),
            'column_totals'   => $columnTotals,
            'column_billable' => $columnBillable,
            'grand_total'     => $grandTotal,
            'billable_total'  => $billableTotal,
            'entry_count'     => $entryCount,
            'timesheet'       => $this->findForDate($userId, $bounds['start_local']->format('Y-m-d')),
            'approval_period' => $this->approvalSettings(),
        ];
    }

    /**
     * Month overview: one row per week that overlaps the month.
     *
     * @return array{
     *     month_start: string,
     *     month_end: string,
     *     month_label: string,
     *     weeks: list<array<string, mixed>>,
     *     grand_total: int,
     *     billable_total: int
     * }
     */
    public function getMonthlyOverview(int $userId, string $monthStartDate): array
    {
        $zone  = new DateTimeZone(FormatHelper::displayTimezone());
        $month = DateTimeImmutable::createFromFormat('!Y-m-d', $monthStartDate, $zone);
        if ($month === false) {
            $month = new DateTimeImmutable('first day of this month', $zone);
        }
        $month = $month->modify('first day of this month')->setTime(0, 0, 0);
        $monthEnd = $month->modify('last day of this month')->setTime(23, 59, 59);

        $cursor = self::weekBounds($month->format('Y-m-d'))['start_local'];
        $weeks  = [];
        $grand  = 0;
        $billable = 0;

        while ($cursor <= $monthEnd) {
            $matrix = $this->getWeeklyMatrix($userId, $cursor->format('Y-m-d'));
            $status = (string) (($matrix['timesheet']['status'] ?? '') ?: self::STATUS_DRAFT);
            $weeks[] = [
                'week_start'      => $matrix['week_start'],
                'week_end'        => $matrix['week_end'],
                'total_seconds'   => $matrix['grand_total'],
                'billable_seconds'=> $matrix['billable_total'],
                'entry_count'     => $matrix['entry_count'],
                'status'          => $status,
                'timesheet_id'    => isset($matrix['timesheet']['id']) ? (int) $matrix['timesheet']['id'] : 0,
                'in_month'        => $cursor->format('Y-m') === $month->format('Y-m')
                    || (new DateTimeImmutable($matrix['week_end'], $zone))->format('Y-m') === $month->format('Y-m'),
            ];
            $grand    += $matrix['grand_total'];
            $billable += $matrix['billable_total'];
            $cursor = $cursor->modify('+7 days');
        }

        return [
            'month_start'    => $month->format('Y-m-d'),
            'month_end'      => $monthEnd->format('Y-m-d'),
            'month_label'    => $month->format('F Y'),
            'weeks'          => $weeks,
            'grand_total'    => $grand,
            'billable_total' => $billable,
        ];
    }

    /**
     * Return completed entries that are not currently submitted/approved.
     * Rejected entries become available again for a fresh submission.
     *
     * @return list<array<string, mixed>>
     */
    public function submittableEntries(int $userId, ?string $startDate = null, ?string $endDate = null): array
    {
        if (!TimeEntry::installed()) {
            return [];
        }

        $startCol = TimeEntry::column('start_time') ?? 'id';
        $endCol = TimeEntry::column('end_time');
        $durationCol = TimeEntry::column('duration_seconds');
        $billableCol = TimeEntry::column('is_billable');
        $descCol = TimeEntry::column('description');
        $statusCol = TimeEntry::column('status');

        $endSelect = $endCol !== null ? "te.`{$endCol}` AS end_time" : 'NULL AS end_time';
        $durationSelect = $durationCol !== null ? "te.`{$durationCol}` AS duration_seconds" : '0 AS duration_seconds';
        $billableSelect = $billableCol !== null ? "te.`{$billableCol}` AS is_billable" : '0 AS is_billable';
        $descSelect = $descCol !== null ? "te.`{$descCol}` AS description" : 'NULL AS description';
        $statusSelect = $statusCol !== null ? "te.`{$statusCol}` AS entry_status" : "'Pending' AS entry_status";
        $taskSelect = Task::installed() ? 'tk.name AS task_name' : 'NULL AS task_name';
        $taskJoin = Task::installed() ? 'LEFT JOIN tasks tk ON tk.id = te.task_id' : '';

        $where = ['te.user_id = :user_id'];
        $params = ['user_id' => $userId];
        if ($startDate !== null && $endDate !== null && $startCol !== 'id') {
            $zone = new DateTimeZone(FormatHelper::displayTimezone());
            $from = new DateTimeImmutable($startDate . ' 00:00:00', $zone);
            $to = new DateTimeImmutable($endDate . ' 23:59:59', $zone);
            $where[] = "te.`{$startCol}` >= :start_utc AND te.`{$startCol}` <= :end_utc";
            $params['start_utc'] = $from->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
            $params['end_utc'] = $to->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        }

        // A rejected timesheet removes its links, so those entries naturally return here.
        $where[] = "NOT EXISTS (
            SELECT 1 FROM timesheet_entries tse
            INNER JOIN timesheets ts ON ts.id = tse.timesheet_id
            WHERE tse.time_entry_id = te.id
              AND ts.status IN ('Submitted','Approved')
        )";

        return Database::fetchAll(
            "SELECT te.id, te.user_id, te.project_id, te.task_id,
                    te.`{$startCol}` AS start_time, {$endSelect}, {$durationSelect},
                    {$billableSelect}, {$descSelect}, {$statusSelect},
                    p.name AS project_name, p.project_code, {$taskSelect}
             FROM time_entries te
             INNER JOIN projects p ON p.id = te.project_id
             {$taskJoin}
             WHERE " . implode(' AND ', $where) . "
             ORDER BY te.`{$startCol}` DESC, te.id DESC",
            $params
        );
    }

    /**
     * Submit exactly the selected completed entries. Project/task selection is not
     * inferred from the UI; every entry is verified as belonging to the user and
     * not already locked by another submitted/approved timesheet.
     *
     * @param list<int> $entryIds
     * @return array<string, mixed>
     */
    public function submitEntries(int $userId, array $entryIds): array
    {
        if (!self::installed() || !TimeEntry::installed()) {
            throw new RuntimeException('Timesheets are not installed yet.');
        }

        $entryIds = array_values(array_unique(array_filter(array_map('intval', $entryIds), static fn (int $id): bool => $id > 0)));
        if ($entryIds === []) {
            throw new RuntimeException('Select at least one work entry to submit.');
        }

        if (class_exists('Timer') && Timer::installed()) {
            $running = Database::fetchOne('SELECT id FROM active_timers WHERE user_id = :user_id LIMIT 1', ['user_id' => $userId]);
            if ($running !== null) {
                throw new RuntimeException('Stop your running timer before submitting work for approval.');
            }
        }

        return Database::transaction(function () use ($userId, $entryIds): array {
            $placeholders = [];
            $params = ['user_id' => $userId];
            foreach ($entryIds as $i => $entryId) {
                $key = 'entry_' . $i;
                $placeholders[] = ':' . $key;
                $params[$key] = $entryId;
            }

            // Resolve the physical column names (older/live installs use started_at / ended_at).
            $startCol    = TimeEntry::column('start_time') ?? 'id';
            $durationCol = TimeEntry::column('duration_seconds');
            $billableCol = TimeEntry::column('is_billable');
            $durationSel = $durationCol !== null ? "te.`{$durationCol}` AS duration_seconds" : '0 AS duration_seconds';
            $billableSel = $billableCol !== null ? "te.`{$billableCol}` AS is_billable" : '0 AS is_billable';

            $sql = "SELECT te.id, te.user_id, te.project_id, te.task_id, te.`{$startCol}` AS start_time,
                           {$durationSel}, {$billableSel}
                    FROM time_entries te
                    WHERE te.user_id = :user_id
                      AND te.id IN (" . implode(',', $placeholders) . ")
                      AND NOT EXISTS (
                          SELECT 1 FROM timesheet_entries tse
                          INNER JOIN timesheets ts ON ts.id = tse.timesheet_id
                          WHERE tse.time_entry_id = te.id
                            AND ts.status IN ('Submitted','Approved')
                      )
                    FOR UPDATE";

            $rows = Database::fetchAll($sql, $params);

            if (count($rows) !== count($entryIds)) {
                throw new RuntimeException('One or more selected work entries are already submitted or are not yours. Refresh the page and try again.');
            }

            $period = null;
            $total = 0;
            $billable = 0;
            foreach ($rows as $row) {
                $entryPeriod = $this->periodBoundsForUtc((string) $row['start_time']);
                if ($period === null) {
                    $period = $entryPeriod;
                } elseif ($period['start_local']->format('Y-m-d') !== $entryPeriod['start_local']->format('Y-m-d')
                    || $period['end_local']->format('Y-m-d') !== $entryPeriod['end_local']->format('Y-m-d')) {
                    throw new RuntimeException('Selected work entries belong to different approval periods. Submit one approval period at a time.');
                }
                $total += (int) $row['duration_seconds'];
                if ((int) $row['is_billable'] === 1) {
                    $billable += (int) $row['duration_seconds'];
                }
            }
            if ($period === null) {
                throw new RuntimeException('There is no valid approval period for the selected work.');
            }
            $periodStart = $period['start_local']->format('Y-m-d');
            $periodEnd = $period['end_local']->format('Y-m-d');

            // Every submission is its own batch (timesheet row), even inside the same approval period.
            // Work is never blocked: a Submitted batch stays locked until it is rejected, an Approved
            // batch stays locked for good, and a Rejected batch releases its entries (links are deleted
            // in reject()), so they come back as ordinary unsubmitted work.
            $token = bin2hex(random_bytes(16));
            $id = $this->create([
                'user_id'          => $userId,
                'start_date'       => $periodStart,
                'end_date'         => $periodEnd,
                'submission_token' => $token,
                'total_seconds'    => $total,
                'billable_seconds' => $billable,
                'status'           => self::STATUS_SUBMITTED,
                'submitted_at'     => gmdate('Y-m-d H:i:s'),
                'approved_by'      => null,
                'approved_at'      => null,
                'rejection_reason' => null,
            ]);

            foreach ($entryIds as $entryId) {
                Database::execute(
                    'INSERT INTO timesheet_entries (timesheet_id, time_entry_id, created_at) VALUES (:timesheet_id, :time_entry_id, UTC_TIMESTAMP())',
                    ['timesheet_id' => $id, 'time_entry_id' => $entryId]
                );
            }

            $row = $this->findWithRelations($id);
            if ($row === null) {
                throw new RuntimeException('Work submission could not be created.');
            }
            return $row;
        });
    }

    /**
     * Aggregate every time entry for the week, lock them into a timesheet, set Submitted.
     *
     * @return array<string, mixed>
     */
    public function submitPeriod(int $userId, string $periodAnchorDate): array
    {
        if (!self::installed() || !TimeEntry::installed()) {
            throw new RuntimeException('Timesheets are not installed yet.');
        }

        $bounds = $this->periodBounds($periodAnchorDate);
        $entries = $this->submittableEntries(
            $userId,
            $bounds['start_local']->format('Y-m-d'),
            $bounds['end_local']->format('Y-m-d')
        );
        $ids = array_values(array_filter(
            array_map(static fn(array $row): int => (int) ($row['id'] ?? 0), $entries),
            static fn(int $id): bool => $id > 0
        ));
        if ($ids === []) {
            throw new RuntimeException('There is no unsubmitted work for this approval period.');
        }
        return $this->submitEntries($userId, $ids);
    }

    /** Backward-compatible wrapper; the date is resolved to the configured approval period. */
    public function submitWeek(int $userId, string $date): array
    {
        return $this->submitPeriod($userId, $date);
    }

    /**
     * Approve a submitted timesheet and lock the underlying time entries.
     *
     * @return array<string, mixed>
     */
    public function approve(int $timesheetId, int $approverId): array
    {
        if (!self::installed()) {
            throw new RuntimeException('Timesheets are not installed yet.');
        }

        return Database::transaction(function () use ($timesheetId, $approverId): array {
            $row = $this->lockRow($timesheetId);
            if ($row === null) {
                throw new RuntimeException('Timesheet was not found.');
            }

            if ((int) $row['user_id'] === $approverId) {
                throw new RuntimeException('You cannot approve your own timesheet.');
            }

            $status = (string) $row['status'];
            if ($status === self::STATUS_APPROVED) {
                throw new RuntimeException('This timesheet is already approved.');
            }
            if ($status !== self::STATUS_SUBMITTED) {
                throw new RuntimeException('Only submitted timesheets can be approved.');
            }

            Database::execute(
                'UPDATE timesheets
                 SET status = :status,
                     approved_by = :approved_by,
                     approved_at = UTC_TIMESTAMP(),
                     rejection_reason = NULL,
                     updated_at = UTC_TIMESTAMP()
                 WHERE id = :id',
                [
                    'status'      => self::STATUS_APPROVED,
                    'approved_by' => $approverId,
                    'id'          => $timesheetId,
                ]
            );

            $updated = $this->findWithRelations($timesheetId);
            if ($updated === null) {
                throw new RuntimeException('Timesheet could not be approved.');
            }

            return $updated;
        });
    }

    /**
     * Reject a submitted timesheet with feedback and unlock entries for editing.
     *
     * @return array<string, mixed>
     */
    public function reject(int $timesheetId, int $approverId, string $reason): array
    {
        if (!self::installed()) {
            throw new RuntimeException('Timesheets are not installed yet.');
        }

        $reason = trim($reason);
        if ($reason === '') {
            throw new InvalidArgumentException('A rejection reason is required.');
        }
        $reason = mb_substr($reason, 0, 500, 'UTF-8');

        return Database::transaction(function () use ($timesheetId, $approverId, $reason): array {
            $row = $this->lockRow($timesheetId);
            if ($row === null) {
                throw new RuntimeException('Timesheet was not found.');
            }

            if ((int) $row['user_id'] === $approverId) {
                throw new RuntimeException('You cannot reject your own timesheet.');
            }

            $status = (string) $row['status'];
            if ($status === self::STATUS_APPROVED) {
                throw new RuntimeException('An approved timesheet cannot be rejected.');
            }
            if ($status !== self::STATUS_SUBMITTED) {
                throw new RuntimeException('Only submitted timesheets can be rejected.');
            }

            Database::execute(
                'UPDATE timesheets
                 SET status = :status,
                     approved_by = :approved_by,
                     approved_at = UTC_TIMESTAMP(),
                     rejection_reason = :reason,
                     updated_at = UTC_TIMESTAMP()
                 WHERE id = :id',
                [
                    'status'      => self::STATUS_REJECTED,
                    'approved_by' => $approverId,
                    'reason'      => $reason,
                    'id'          => $timesheetId,
                ]
            );

            Database::execute(
                'DELETE FROM timesheet_entries WHERE timesheet_id = :id',
                ['id' => $timesheetId]
            );

            $updated = $this->findWithRelations($timesheetId);
            if ($updated === null) {
                throw new RuntimeException('Timesheet could not be rejected.');
            }

            return $updated;
        });
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findWithRelations(int $id): ?array
    {
        if ($id < 1 || !self::installed()) {
            return null;
        }

        return Database::fetchOne(
            $this->selectSql() . ' WHERE t.id = :id LIMIT 1',
            ['id' => $id]
        );
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findForPeriod(int $userId, string $startDate, string $endDate, bool $forUpdate = false): ?array
    {
        if (!self::installed()) {
            return null;
        }

        $sql = $this->selectSql() . ' WHERE t.user_id = :user_id AND t.start_date = :start_date AND t.end_date = :end_date ORDER BY t.id DESC LIMIT 1';
        if ($forUpdate) {
            $sql = 'SELECT t.* FROM timesheets t
                    WHERE t.user_id = :user_id AND t.start_date = :start_date AND t.end_date = :end_date
                    ORDER BY t.id DESC LIMIT 1 FOR UPDATE';
        }

        return Database::fetchOne($sql, [
            'user_id'    => $userId,
            'start_date' => $startDate,
            'end_date'   => $endDate,
        ]);
    }


    /** Return the canonical approval period containing a local calendar date. */
    public function periodBounds(string $anchorDate): array
    {
        $zone = new DateTimeZone(FormatHelper::displayTimezone());
        $anchor = DateTimeImmutable::createFromFormat('!Y-m-d', $anchorDate, $zone);
        $errors = DateTimeImmutable::getLastErrors();
        if ($anchor === false || ($errors !== false && ($errors['warning_count'] > 0 || $errors['error_count'] > 0))) {
            throw new InvalidArgumentException('The approval period date is invalid.');
        }
        $anchor = $anchor->setTime(0, 0, 0);
        $settings = $this->approvalSettings();
        if ($settings['approval_period'] === 'monthly') {
            $startLocal = $anchor->modify('first day of this month')->setTime(0, 0, 0);
            $endLocal = $startLocal->modify('last day of this month')->setTime(23, 59, 59);
        } elseif ($settings['approval_period'] === 'semi-monthly') {
            $startLocal = ((int) $anchor->format('d') <= 15)
                ? $anchor->modify('first day of this month')->setTime(0, 0, 0)
                : $anchor->modify('first day of this month')->setTime(0, 0, 0)->modify('+15 days')->setTime(0, 0, 0);
            $endLocal = ((int) $anchor->format('d') <= 15)
                ? $startLocal->modify('+14 days')->setTime(23, 59, 59)
                : $startLocal->modify('last day of this month')->setTime(23, 59, 59);
        } else {
            $startLocal = $anchor->modify(WorkspacePolicy::weekModifier())->setTime(0, 0, 0);
            $endLocal = $startLocal->modify('+6 days')->setTime(23, 59, 59);
        }
        return [
            'start_local' => $startLocal,
            'end_local' => $endLocal,
            'start_utc' => $startLocal->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
            'end_utc' => $endLocal->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
            'approval_period' => $settings['approval_period'],
            'week_start' => $settings['week_start'],
        ];
    }

    /** @return array{approval_period:string,week_start:string} */
    public function approvalSettings(): array
    {
        return [
            'approval_period' => WorkspacePolicy::approvalPeriod(),
            'week_start'      => WorkspacePolicy::weekStart(),
        ];
    }

    private function periodBoundsForUtc(string $utcDatetime): array
    {
        $moment = new DateTimeImmutable($utcDatetime, new DateTimeZone('UTC'));
        $local = $moment->setTimezone(new DateTimeZone(FormatHelper::displayTimezone()));
        return $this->periodBounds($local->format('Y-m-d'));
    }

    /** @return array<string,mixed>|null */
    public function findForDate(int $userId, string $localDate, bool $forUpdate = false): ?array
    {
        $bounds = $this->periodBounds($localDate);
        return $this->findForPeriod($userId, $bounds['start_local']->format('Y-m-d'), $bounds['end_local']->format('Y-m-d'), $forUpdate);
    }

    /** @return list<array<string,mixed>> */
    public function unsubmittedPeriods(int $userId, string $beforeLocalDate, int $limit = 5): array
    {
        if ($userId < 1 || !self::installed() || !TimeEntry::installed()) return [];
        $limit = min(12, max(1, $limit));
        $before = $this->periodBounds($beforeLocalDate)['start_utc'];
        $startCol = TimeEntry::column('start_time');
        $durationCol = TimeEntry::column('duration_seconds');
        if ($startCol === null) return [];
        $duration = $durationCol !== null ? "te.`{$durationCol}`" : '0';
        $rows = Database::fetchAll(
            "SELECT te.id, te.`{$startCol}` AS start_time, {$duration} AS duration_seconds
             FROM time_entries te
             WHERE te.user_id = :user_id AND te.`{$startCol}` < :before_utc
               AND NOT EXISTS (
                   SELECT 1 FROM timesheet_entries tse INNER JOIN timesheets ts ON ts.id = tse.timesheet_id
                   WHERE tse.time_entry_id = te.id AND ts.status IN ('Submitted','Approved')
               )
             ORDER BY te.`{$startCol}` DESC, te.id DESC LIMIT 500",
            ['user_id' => $userId, 'before_utc' => $before]
        );
        $groups = [];
        foreach ($rows as $row) {
            $period = $this->periodBoundsForUtc((string) $row['start_time']);
            $key = $period['start_local']->format('Y-m-d') . '|' . $period['end_local']->format('Y-m-d');
            if (!isset($groups[$key])) $groups[$key] = ['start_date'=>$period['start_local']->format('Y-m-d'),'end_date'=>$period['end_local']->format('Y-m-d'),'entry_count'=>0,'total_seconds'=>0];
            $groups[$key]['entry_count']++;
            $groups[$key]['total_seconds'] += (int) $row['duration_seconds'];
        }
        usort($groups, static fn(array $a,array $b): int => strcmp($b['end_date'],$a['end_date']));
        return array_slice($groups, 0, $limit);
    }

    /**
     * Submitted timesheets waiting for (or filtered by) approval.
     *
     * @param array{status?: string, user_id?: int, q?: string} $filters
     * @return array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int, counts: array<string, int>}
     */
    public function queueForApprover(int $approverId, bool $isAdmin, array $filters, int $page = 1, int $perPage = 25): array
    {
        $perPage = min(100, max(1, $perPage));
        [$whereSql, $params] = $this->queueWhere($approverId, $isAdmin, $filters);

        $total = (int) Database::fetchValue(
            'SELECT COUNT(*) FROM timesheets t
             INNER JOIN users u ON u.id = t.user_id' . $whereSql,
            $params
        );

        $pages = max(1, (int) ceil($total / $perPage));
        $page  = min(max(1, $page), $pages);

        $params['limit']  = $perPage;
        $params['offset'] = ($page - 1) * $perPage;

        $items = Database::fetchAll(
            $this->selectSql() . $whereSql . '
             ORDER BY t.submitted_at DESC, t.id DESC
             LIMIT :limit OFFSET :offset',
            $params
        );

        return [
            'items'    => $items,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $perPage,
            'pages'    => $pages,
            'counts'   => $this->queueCounts($approverId, $isAdmin),
        ];
    }

    /**
     * @return array<string, int>
     */
    public function queueCounts(int $approverId, bool $isAdmin): array
    {
        [$scopeSql, $scopeParams] = $this->approverScope($approverId, $isAdmin);

        $rows = Database::fetchAll(
            'SELECT t.status, COUNT(*) AS total
             FROM timesheets t
             INNER JOIN users u ON u.id = t.user_id
             WHERE ' . $scopeSql . '
             GROUP BY t.status',
            $scopeParams
        );

        $counts = [
            'Submitted' => 0,
            'Approved'  => 0,
            'Rejected'  => 0,
            'Draft'     => 0,
            'all'       => 0,
        ];
        foreach ($rows as $row) {
            $status = (string) $row['status'];
            $total  = (int) $row['total'];
            $counts[$status] = $total;
            $counts['all']  += $total;
        }

        return $counts;
    }

    /**
     * Time entries locked into a timesheet, with relations.
     *
     * @return list<array<string, mixed>>
     */
    public function entriesFor(int $timesheetId): array
    {
        if (!self::installed() || !TimeEntry::installed()) {
            return [];
        }

        $startCol   = TimeEntry::column('start_time') ?? 'id';
        $endCol     = TimeEntry::column('end_time');
        $durationCol = TimeEntry::column('duration_seconds');
        $breakCol   = TimeEntry::column('break_minutes');
        $descCol    = TimeEntry::column('description');
        $billableCol = TimeEntry::column('is_billable');
        $rateCol    = TimeEntry::column('billable_rate');
        $statusCol  = TimeEntry::column('status');
        $useTasks   = Task::installed();
        $taskSelect = $useTasks ? 'tk.name AS task_name' : 'NULL AS task_name';
        $taskJoin   = $useTasks ? 'LEFT JOIN tasks tk ON tk.id = te.task_id' : '';

        $endSelect      = $endCol !== null ? "te.`{$endCol}` AS end_time" : 'NULL AS end_time';
        $durationSelect = $durationCol !== null ? "te.`{$durationCol}` AS duration_seconds" : '0 AS duration_seconds';
        $breakSelect    = $breakCol !== null ? "te.`{$breakCol}` AS break_minutes" : '0 AS break_minutes';
        $descSelect     = $descCol !== null ? "te.`{$descCol}` AS description" : 'NULL AS description';
        $billableSelect = $billableCol !== null ? "te.`{$billableCol}` AS is_billable" : '0 AS is_billable';
        $rateSelect     = $rateCol !== null ? "te.`{$rateCol}` AS billable_rate" : '0 AS billable_rate';
        $statusSelect   = $statusCol !== null ? "te.`{$statusCol}` AS status" : 'NULL AS status';

        return Database::fetchAll(
            "SELECT te.id, te.user_id, te.project_id, te.task_id,
                    te.`{$startCol}` AS start_time, {$endSelect}, {$durationSelect}, {$breakSelect},
                    {$descSelect}, {$billableSelect}, {$rateSelect}, {$statusSelect},
                    p.name AS project_name, p.project_code,
                    {$taskSelect}
             FROM timesheet_entries tse
             INNER JOIN time_entries te ON te.id = tse.time_entry_id
             INNER JOIN projects p ON p.id = te.project_id
             {$taskJoin}
             WHERE tse.timesheet_id = :id
             ORDER BY te.`{$startCol}` ASC, te.id ASC",
            ['id' => $timesheetId]
        );
    }

    /**
     * True when this viewer may open the timesheet (owner, admin, or an approver above the owner).
     *
     * @param array<string, mixed> $timesheet
     */
    public function userCanView(array $timesheet, int $userId, bool $isAdmin, bool $canApprove): bool
    {
        if ((int) $timesheet['user_id'] === $userId) {
            return true;
        }

        if ($isAdmin) {
            return true;
        }

        if (!$canApprove) {
            return false;
        }

        return $this->isInApproverScope($timesheet, $userId);
    }

    /**
     * True when this viewer may approve/reject the timesheet.
     *
     * @param array<string, mixed> $timesheet
     */
    public function userCanDecide(array $timesheet, int $userId, bool $isAdmin, bool $canApprove): bool
    {
        if (!$canApprove) {
            return false;
        }

        if ((int) $timesheet['user_id'] === $userId) {
            return false;
        }

        if ($isAdmin) {
            return true;
        }

        return $this->isInApproverScope($timesheet, $userId);
    }

    /**
     * Notify a user in-app. Failures are swallowed so the action still completes.
     * Delegates to the Phase 9 engine so the "notifications_enabled" switch and
     * length limits are always applied.
     */
    public function notify(int $userId, string $type, string $title, string $message, string $link): void
    {
        NotificationHelper::push($userId, $type, $title, $message, $link);
    }

    /**
     * In-app + email notice to every person above the submitter (team lead, team/project
     * manager, admins). Email failures never block the submission.
     */
    public function notifyApproversOfSubmission(
        array $timesheet,
        int $submitterId,
        string $title,
        string $message,
        string $periodLabel
    ): void {
        $submitter = AuthHelper::user();
        $submitterName = is_array($submitter) ? (string) ($submitter['name'] ?? 'An employee') : 'An employee';
        $timesheetId = (int) ($timesheet['id'] ?? 0);
        $link = '/timesheets/' . $timesheetId;
        $totalTime = FormatHelper::durationShort((int) ($timesheet['total_seconds'] ?? 0));
        $reviewUrl = FormatHelper::absoluteUrl($link);

        $rolesById = [];
        try {
            foreach (ApprovalChainHelper::describe($submitterId, $this->projectIdsFor($timesheetId)) as $row) {
                $id = (int) ($row['id'] ?? 0);
                if ($id > 0) {
                    $rolesById[$id] = implode(', ', $row['labels'] ?? []);
                }
            }
        } catch (Throwable $e) {
            LoggerHelper::debug('Timesheet approval chain describe failed', ['error' => $e->getMessage()]);
        }

        $ids = array_keys($rolesById);
        if ($ids === []) {
            $ids = $this->approverIdsFor($timesheet, $submitterId);
        }

        $people = $this->activePeopleById($ids);
        foreach ($ids as $approverId) {
            $this->notify($approverId, 'info', $title, $message, $link);

            $person = $people[$approverId] ?? null;
            $email = is_array($person) ? trim((string) ($person['email'] ?? '')) : '';
            if ($email === '') {
                continue;
            }

            try {
                Mailer::sendTemplate($email, MailTemplate::TIMESHEET_SUBMITTED, [
                    'user_name' => (string) ($person['name'] ?? ''),
                    'submitter_name' => $submitterName,
                    'period' => $periodLabel,
                    'total_time' => $totalTime,
                    'approver_role' => ($rolesById[$approverId] ?? '') !== '' ? $rolesById[$approverId] : 'Approver',
                    'review_url' => $reviewUrl,
                ]);
            } catch (Throwable $e) {
                LoggerHelper::debug('Timesheet submission email skipped', ['error' => $e->getMessage()]);
            }
        }
    }

    /**
     * @param list<int> $ids
     * @return array<int, array{name: string, email: string}>
     */
    private function activePeopleById(array $ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn (int $id): bool => $id > 0)));
        if ($ids === []) {
            return [];
        }

        $in = implode(',', $ids);
        $rows = Database::fetchAll(
            "SELECT id, name, email FROM users WHERE id IN ({$in}) AND status = 'active'"
        );
        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row['id']] = [
                'name' => (string) $row['name'],
                'email' => (string) $row['email'],
            ];
        }

        return $out;
    }

    /**
     * People who should hear about a submission: the submitter's team lead, team manager,
     * project manager and admins of the PROJECTS the submitted work belongs to
     * (see ApprovalChainHelper). Never the submitter.
     *
     * @return list<int>
     */
    public function approverIdsFor(array $timesheet, int $submitterId): array
    {
        $ownerId = (int) ($timesheet['user_id'] ?? $submitterId);

        try {
            // Only the chains of the projects this work was logged against.
            return ApprovalChainHelper::approversFor($ownerId, $this->projectIdsFor((int) ($timesheet['id'] ?? 0)));
        } catch (Throwable $e) {
            LoggerHelper::debug('Timesheet approver lookup failed', ['error' => $e->getMessage()]);

            return [];
        }
    }

    /** True when the configured approval period containing $utcDatetime is Submitted or Approved. */
    public function isPeriodLocked(int $userId, string $utcDatetime): bool
    {
        if ($userId < 1 || $utcDatetime === '' || !self::installed()) return false;
        try {
            $bounds = $this->periodBoundsForUtc($utcDatetime);
            return (int) Database::fetchValue(
                "SELECT COUNT(*) FROM timesheets
                 WHERE user_id = :user_id
                   AND start_date = :start_date
                   AND end_date = :end_date
                   AND status IN ('Submitted','Approved')",
                [
                    'user_id'    => $userId,
                    'start_date' => $bounds['start_local']->format('Y-m-d'),
                    'end_date'   => $bounds['end_local']->format('Y-m-d'),
                ]
            ) > 0;
        } catch (Throwable $e) {
            LoggerHelper::debug('Timesheet isPeriodLocked failed', ['error' => $e->getMessage()]);
            return false;
        }
    }

    /**
     * Workspace week start 00:00 through +6 days 23:59:59 in the viewer's timezone, plus UTC bounds.
     *
     * @return array{start_local: DateTimeImmutable, end_local: DateTimeImmutable, start_utc: string, end_utc: string}
     */
    public static function weekBounds(string $weekStartDate): array
    {
        $zone   = new DateTimeZone(FormatHelper::displayTimezone());
        $anchor = DateTimeImmutable::createFromFormat('!Y-m-d', $weekStartDate, $zone);
        if ($anchor === false) {
            $anchor = new DateTimeImmutable('today', $zone);
        }

        $startLocal = $anchor->modify(WorkspacePolicy::weekModifier())->setTime(0, 0, 0);
        $endLocal   = $startLocal->modify('+6 days')->setTime(23, 59, 59);

        return [
            'start_local' => $startLocal,
            'end_local'   => $endLocal,
            'start_utc'   => $startLocal->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
            'end_utc'     => $endLocal->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function entriesInRange(int $userId, string $startUtc, string $endUtc, bool $forUpdate = false): array
    {
        if (!TimeEntry::installed()) {
            return [];
        }

        $lock       = $forUpdate ? ' FOR UPDATE' : '';
        $useTasks   = Task::installed();
        $taskJoin   = $useTasks ? 'LEFT JOIN tasks tk ON tk.id = te.task_id' : '';
        $taskSelect = $useTasks ? 'tk.name AS task_name' : 'NULL AS task_name';
        $taskOrder  = $useTasks ? 'tk.name ASC,' : '';

        $startCol     = TimeEntry::column('start_time') ?? 'id';
        $endCol       = TimeEntry::column('end_time');
        $durationCol  = TimeEntry::column('duration_seconds');
        $billableCol  = TimeEntry::column('is_billable');
        $statusCol    = TimeEntry::column('status');
        $descCol      = TimeEntry::column('description');

        $endSelect      = $endCol !== null ? "te.`{$endCol}` AS end_time" : 'NULL AS end_time';
        $durationSelect = $durationCol !== null ? "te.`{$durationCol}` AS duration_seconds" : '0 AS duration_seconds';
        $billableSelect = $billableCol !== null ? "te.`{$billableCol}` AS is_billable" : '0 AS is_billable';
        $statusSelect   = $statusCol !== null ? "te.`{$statusCol}` AS status" : 'NULL AS status';
        $descSelect     = $descCol !== null ? "te.`{$descCol}` AS description" : 'NULL AS description';
        $rangeFilter    = $startCol === 'id'
            ? '1 = 1'
            : "te.`{$startCol}` >= :start_utc AND te.`{$startCol}` <= :end_utc";

        return Database::fetchAll(
            "SELECT te.id, te.user_id, te.project_id, te.task_id,
                    te.`{$startCol}` AS start_time, {$endSelect}, {$durationSelect},
                    {$billableSelect}, {$statusSelect}, {$descSelect},
                    p.name AS project_name, p.project_code,
                    {$taskSelect}
             FROM time_entries te
             INNER JOIN projects p ON p.id = te.project_id
             {$taskJoin}
             WHERE te.user_id = :user_id
               AND {$rangeFilter}
             ORDER BY p.name ASC, {$taskOrder} te.`{$startCol}` ASC" . $lock,
            [
                'user_id'   => $userId,
                'start_utc' => $startUtc,
                'end_utc'   => $endUtc,
            ]
        );
    }

    /**
     * @return list<array{key: string, date: string, label: string, short: string, is_today: bool, is_weekend: bool}>
     */
    private function dayMeta(DateTimeImmutable $startLocal): array
    {
        $today = (new DateTimeImmutable('today', $startLocal->getTimezone()))->format('Y-m-d');
        $days  = [];

        $keys = WorkspacePolicy::weekStart() === 'sunday'
            ? ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat']
            : self::DAY_KEYS;

        for ($i = 0; $i < 7; $i++) {
            $day = $startLocal->modify('+' . $i . ' day');
            $key = $keys[$i];
            $date = $day->format('Y-m-d');
            $dow  = (int) $day->format('N');
            $days[] = [
                'key'        => $key,
                'date'       => $date,
                'label'      => self::DAY_LABELS[$key] ?? $day->format('D'),
                'short'      => $day->format('M j'),
                'is_today'   => $date === $today,
                'is_weekend' => $dow >= 6,
            ];
        }

        return $days;
    }

    /**
     * @param list<array{key: string, date: string}> $days
     */
    private function dayKeyForDate(string $localDate, array $days): ?string
    {
        foreach ($days as $day) {
            if ($day['date'] === $localDate) {
                return $day['key'];
            }
        }

        return null;
    }

    /** @return array<string, mixed>|null */
    private function lockRow(int $id): ?array
    {
        return Database::fetchOne(
            'SELECT * FROM timesheets WHERE id = :id LIMIT 1 FOR UPDATE',
            ['id' => $id]
        );
    }

    /**
     * @param array<string, mixed> $timesheet
     */
    private function isInApproverScope(array $timesheet, int $approverId): bool
    {
        return ApprovalChainHelper::canDecide(
            $approverId,
            (int) $timesheet['user_id'],
            $this->projectIdsFor((int) ($timesheet['id'] ?? 0))
        );
    }

    /**
     * Distinct projects of the work locked into a timesheet.
     * Returns null when the timesheet has no linked entries (e.g. a rejected one, whose links are
     * released), so callers fall back to the submitter's full chain.
     *
     * @return list<int>|null
     */
    public function projectIdsFor(int $timesheetId): ?array
    {
        if ($timesheetId < 1) {
            return null;
        }

        $rows = Database::fetchAll(
            'SELECT DISTINCT te.project_id
             FROM timesheet_entries tse
             INNER JOIN time_entries te ON te.id = tse.time_entry_id
             WHERE tse.timesheet_id = :id',
            ['id' => $timesheetId]
        );

        $ids = array_values(array_filter(array_map(static fn (array $r): int => (int) $r['project_id'], $rows), static fn (int $id): bool => $id > 0));

        return $ids === [] ? null : $ids;
    }

    /**
     * @param array{status?: string, user_id?: int, q?: string} $filters
     * @return array{0: string, 1: array<string, mixed>}
     */
    private function queueWhere(int $approverId, bool $isAdmin, array $filters): array
    {
        [$scopeSql, $params] = $this->approverScope($approverId, $isAdmin);
        $where = [$scopeSql];

        $status = (string) ($filters['status'] ?? self::STATUS_SUBMITTED);
        if ($status !== '' && $status !== 'all' && in_array($status, self::STATUSES, true)) {
            $where[] = 't.status = :status';
            $params['status'] = $status;
        } elseif ($status === '' || $status === self::STATUS_SUBMITTED) {
            $where[] = 't.status = :status';
            $params['status'] = self::STATUS_SUBMITTED;
        }

        $userId = (int) ($filters['user_id'] ?? 0);
        if ($userId > 0) {
            $where[] = 't.user_id = :filter_user';
            $params['filter_user'] = $userId;
        }

        $q = trim((string) ($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = 'u.name LIKE :q';
            $params['q'] = '%' . $q . '%';
        }

        return [' WHERE ' . implode(' AND ', $where), $params];
    }

    /**
     * @return array{0: string, 1: array<string, mixed>}
     */
    private function approverScope(int $approverId, bool $isAdmin): array
    {
        // Admins may review the complete queue, but never their own submission.
        if ($isAdmin) {
            return ['t.user_id <> :approver_id', ['approver_id' => $approverId]];
        }

        // Everybody else sees a timesheet only when they sit above the submitter for at least one of
        // the PROJECTS the timesheet's work was logged against (lead / team manager / project manager).
        // A manager role alone never makes a timesheet visible.
        $clauses = [];
        foreach (ApprovalChainHelper::coverageFor($approverId) as $projectId => $submitterIds) {
            $clauses[] = '(te.project_id = ' . (int) $projectId
                . ' AND t.user_id IN (' . implode(',', array_map('intval', $submitterIds)) . '))';
        }

        $legacyIds = ApprovalChainHelper::subordinateIds($approverId);
        $parts     = [];
        if ($clauses !== []) {
            $parts[] = 'EXISTS (SELECT 1 FROM timesheet_entries tse
                        INNER JOIN time_entries te ON te.id = tse.time_entry_id
                        WHERE tse.timesheet_id = t.id AND (' . implode(' OR ', $clauses) . '))';
        }
        if ($legacyIds !== []) {
            // Timesheets without linked entries (rejected ones) fall back to the submitter's full chain.
            $parts[] = '(NOT EXISTS (SELECT 1 FROM timesheet_entries tse0 WHERE tse0.timesheet_id = t.id)
                        AND t.user_id IN (' . implode(',', array_map('intval', $legacyIds)) . '))';
        }

        if ($parts === []) {
            return ['1 = 0', []];
        }

        return ['t.user_id <> :approver_id AND (' . implode(' OR ', $parts) . ')', ['approver_id' => $approverId]];
    }

    private function selectSql(): string
    {
        return 'SELECT t.id, t.user_id, t.start_date, t.end_date,
                       t.total_seconds, t.billable_seconds, t.status,
                       t.submitted_at, t.approved_by, t.approved_at, t.rejection_reason,
                       t.created_at, t.updated_at,
                       u.name AS user_name, u.email AS user_email, r.name AS user_role, u.job_title AS user_job_title,
                       approver.name AS approved_by_name
                FROM timesheets t
                INNER JOIN users u ON u.id = t.user_id
                INNER JOIN roles r ON r.id = u.role_id
                LEFT JOIN users approver ON approver.id = t.approved_by';
    }
}