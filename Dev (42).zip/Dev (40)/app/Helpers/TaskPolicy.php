<?php
/**
 * Project / team / task positions and the strict-mode permission matrix.
 *
 * Global role (admin / manager / employee / client) says which modules a person
 * may use. Position on a specific project and team says what they may do there.
 *
 * Positions (highest first): admin, pm, team_manager, team_lead, team_member,
 * project_member, viewer, none.
 *
 * Strict vs legacy: task_scope_mode = legacy keeps current behaviour.
 * Controllers must still call can()/require() after loading the task/project.
 */

declare(strict_types=1);

final class TaskPolicy
{
    public const POS_ADMIN          = 'admin';
    public const POS_PM             = 'pm';
    public const POS_TEAM_MANAGER   = 'team_manager';
    public const POS_TEAM_LEAD      = 'team_lead';
    public const POS_TEAM_MEMBER    = 'team_member';
    public const POS_PROJECT_MEMBER = 'project_member';
    public const POS_VIEWER         = 'viewer';
    public const POS_NONE           = 'none';

    public const MODE_LEGACY = 'legacy';
    public const MODE_STRICT = 'strict';

    private const RANK = [
        self::POS_ADMIN          => 80,
        self::POS_PM             => 70,
        self::POS_TEAM_MANAGER   => 60,
        self::POS_TEAM_LEAD      => 50,
        self::POS_TEAM_MEMBER    => 40,
        self::POS_PROJECT_MEMBER => 30,
        self::POS_VIEWER         => 10,
        self::POS_NONE           => 0,
    ];

    public static function isStrict(): bool
    {
        return WorkspacePolicy::taskScopeMode() === self::MODE_STRICT;
    }

    public static function isLegacy(): bool
    {
        return !self::isStrict();
    }

    /**
     * Position of $userId on $projectId, optionally for a specific team.
     * When $teamId is null, team ranks are not applied (project-level task).
     */
    public static function positionFor(int $userId, int $projectId, ?int $teamId = null): string
    {
        if ($userId < 1 || $projectId < 1) {
            return self::POS_NONE;
        }

        $snap = ApprovalChainHelper::snapshot();
        if (!isset($snap['active'][$userId]) || !isset($snap['projects'][$projectId])) {
            return self::POS_NONE;
        }

        if (isset($snap['adminSet'][$userId])) {
            return self::POS_ADMIN;
        }

        if ((int) ($snap['projectManager'][$projectId] ?? 0) === $userId) {
            return self::POS_PM;
        }

        $memberRole = strtolower((string) ($snap['projectMemberRoles'][$userId][$projectId] ?? ''));
        if ($memberRole === 'viewer') {
            return self::POS_VIEWER;
        }

        if ($teamId !== null && $teamId > 0) {
            $team = $snap['teams'][$teamId] ?? null;
            if ($team === null || (int) $team['project_id'] !== $projectId) {
                return self::POS_NONE;
            }
            $rank = (string) ($snap['teamRoles'][$userId][$teamId] ?? '');
            if ($rank === 'manager') {
                return self::POS_TEAM_MANAGER;
            }
            if ($rank === 'lead') {
                return self::POS_TEAM_LEAD;
            }
            if ($rank === 'member') {
                return self::POS_TEAM_MEMBER;
            }
        }

        $onProject = isset($snap['projectMemberSet'][$userId][$projectId])
            || (int) ($snap['projectManager'][$projectId] ?? 0) === $userId;
        if ($onProject) {
            return self::POS_PROJECT_MEMBER;
        }

        return self::POS_NONE;
    }

    public static function highestPositionInProject(int $userId, int $projectId): string
    {
        $best = self::positionFor($userId, $projectId, null);
        foreach (self::teamsOf($userId, $projectId) as $teamId) {
            $pos = self::positionFor($userId, $projectId, $teamId);
            if ((self::RANK[$pos] ?? 0) > (self::RANK[$best] ?? 0)) {
                $best = $pos;
            }
        }

        return $best;
    }

    /**
     * Active team ids in this project where the user is manager, lead or member.
     *
     * @return list<int>
     */
    public static function teamsOf(int $userId, int $projectId): array
    {
        if ($userId < 1 || $projectId < 1) {
            return [];
        }

        $snap = ApprovalChainHelper::snapshot();
        $out  = [];
        foreach ($snap['teamRoles'][$userId] ?? [] as $teamId => $rank) {
            $teamId = (int) $teamId;
            $team   = $snap['teams'][$teamId] ?? null;
            if ($team === null || (int) $team['project_id'] !== $projectId) {
                continue;
            }
            if (in_array($rank, ['manager', 'lead', 'member'], true)) {
                $out[] = $teamId;
            }
        }

        return array_values(array_unique($out));
    }

    /** Team lead / team manager / PM of any project (admins handled by role). */
    public static function isApprovingPosition(int $userId): bool
    {
        return ApprovalChainHelper::isApprover($userId);
    }

    /**
     * Gate 1: capability. Permission OR an approving position (lead / TM / PM).
     * Lets employee-role team leads create tasks without changing role_permissions.
     */
    public static function hasCapability(string $permission): bool
    {
        if (PermissionHelper::has($permission)) {
            return true;
        }

        $userId = (int) AuthHelper::id();
        if ($userId < 1) {
            return false;
        }

        return match ($permission) {
            'tasks.create', 'tasks.edit', 'tasks.assign', 'tasks.delete', 'tasks.view' => self::isApprovingPosition($userId),
            default => false,
        };
    }

    public static function requireCapability(string $permission): void
    {
        if (self::isLegacy()) {
            PermissionHelper::require($permission);

            return;
        }

        if (!self::hasCapability($permission)) {
            self::deny('You do not have permission to do that.');
        }
    }

    /**
     * Gate 2: scope. Fail closed. $task may be null for create.
     *
     * @param array<string, mixed>|null $task
     * @param array<string, mixed>      $project
     */
    public static function can(string $action, ?array $task, array $project, ?int $teamId = null): bool
    {
        return self::denyReason($action, $task, $project, $teamId) === null;
    }

    /**
     * @param array<string, mixed>|null $task
     * @param array<string, mixed>      $project
     */
    public static function require(string $action, ?array $task, array $project, ?int $teamId = null): void
    {
        if (self::isLegacy()) {
            return;
        }

        $reason = self::denyReason($action, $task, $project, $teamId);
        if ($reason !== null) {
            self::deny($reason);
        }
    }

    /**
     * Human reason, or null when allowed. Always fail closed.
     *
     * @param array<string, mixed>|null $task
     * @param array<string, mixed>      $project
     */
    public static function denyReason(string $action, ?array $task, array $project, ?int $teamId = null): ?string
    {
        $userId = (int) AuthHelper::id();
        if ($userId < 1) {
            return 'You do not have permission to do that.';
        }

        if (ClientScope::isClient()) {
            return 'Client accounts are read-only.';
        }

        $projectId = (int) ($project['id'] ?? 0);
        if ($projectId < 1) {
            return 'You do not have permission to do that.';
        }

        if ($task !== null) {
            if ((int) ($task['project_id'] ?? 0) !== $projectId) {
                return 'That task does not belong to this project.';
            }
            $teamId = self::taskTeamId($task, $teamId);
        }

        if ($teamId !== null && $teamId > 0 && !self::teamBelongsToProject($teamId, $projectId)) {
            return 'That team does not belong to this project.';
        }

        $pos  = self::positionFor($userId, $projectId, $teamId);
        $rank = self::RANK[$pos] ?? 0;

        if ($rank < self::RANK[self::POS_VIEWER]) {
            return 'You do not have a position on this project.';
        }

        $teamName = self::teamName($teamId);

        return match ($action) {
            'view'     => null,
            'create'   => self::reasonCreate($pos, $teamId, $projectId, $teamName),
            'edit', 'rename', 'delete' => self::reasonMutate($pos, $rank, $teamName),
            'assign'   => self::reasonAssign($pos, $rank, $teamName),
            'status'   => self::reasonStatus($pos, $rank, $task, $userId, $teamName),
            'review'   => self::reasonReview($pos, $rank, $task, $userId, $teamName),
            'cancel', 'reopen' => self::reasonMutate($pos, $rank, $teamName),
            default    => 'You do not have permission to do that.',
        };
    }

    /**
     * People the actor may assign on this project/team.
     *
     * @param array<string, mixed> $project
     * @return list<int>
     */
    public static function assignableIdsFor(int $actorId, array $project, ?int $teamId = null): array
    {
        $projectId = (int) ($project['id'] ?? 0);
        if ($actorId < 1 || $projectId < 1) {
            return [];
        }

        if (self::isLegacy()) {
            return TimeTrackingRules::assignableUserIds($project);
        }

        $pos  = self::positionFor($actorId, $projectId, $teamId);
        $rank = self::RANK[$pos] ?? 0;
        if ($rank < self::RANK[self::POS_TEAM_LEAD]) {
            return [];
        }

        if ($rank >= self::RANK[self::POS_PM] || $teamId === null || $teamId < 1) {
            return TimeTrackingRules::assignableUserIds($project);
        }

        return self::teamAssignableIds($projectId, $teamId);
    }

    /**
     * @param array<string, mixed> $project
     * @param list<int>            $userIds
     */
    public static function assertAssignable(int $actorId, array $project, ?int $teamId, array $userIds): void
    {
        if ($userIds === []) {
            return;
        }

        if (self::isLegacy()) {
            TimeTrackingRules::assertAssignable($project, $userIds);
            return;
        }

        $allowed = self::assignableIdsFor($actorId, $project, $teamId);
        $snap    = ApprovalChainHelper::snapshot();
        $projectId = (int) ($project['id'] ?? 0);
        $teamName  = self::teamName($teamId);

        foreach ($userIds as $uid) {
            $uid = (int) $uid;
            if ($uid < 1) {
                continue;
            }
            if (in_array($uid, $allowed, true)) {
                continue;
            }

            throw new HttpException(422, self::assignRejectMessage($uid, $projectId, $teamId, $teamName, $snap));
        }
    }

    /**
     * Per-task UI flags. Server still enforces the same rules.
     *
     * @param array<string, mixed> $task
     * @param array<string, mixed> $project
     * @return array{canEdit: bool, canAssign: bool, canStatus: bool, canReview: bool, canDelete: bool}
     */
    public static function flagsFor(array $task, array $project): array
    {
        if (self::isLegacy()) {
            return [
                'canEdit'   => PermissionHelper::has('tasks.edit'),
                'canAssign' => PermissionHelper::has('tasks.assign'),
                'canStatus' => PermissionHelper::has('tasks.edit'),
                'canReview' => PermissionHelper::has('tasks.edit'),
                'canDelete' => PermissionHelper::has('tasks.delete'),
            ];
        }

        return [
            'canEdit'   => self::can('edit', $task, $project),
            'canAssign' => self::can('assign', $task, $project),
            'canStatus' => self::can('status', $task, $project),
            'canReview' => self::can('review', $task, $project),
            'canDelete' => self::can('delete', $task, $project),
        ];
    }

    public static function canCreateTaskOn(array $project, ?int $teamId = null): bool
    {
        if (self::isLegacy()) {
            return WorkspacePolicy::canCreateTask();
        }

        if (!self::hasCapability('tasks.create')) {
            return false;
        }

        return self::can('create', null, $project, $teamId);
    }

    /** True when the actor may create a project-level or own-team task on this project. */
    public static function canCreateOnProject(array $project): bool
    {
        if (self::isLegacy()) {
            return WorkspacePolicy::canCreateTask();
        }

        if (self::canCreateTaskOn($project, null)) {
            return true;
        }

        $userId    = (int) AuthHelper::id();
        $projectId = (int) ($project['id'] ?? 0);
        foreach (self::teamsOf($userId, $projectId) as $teamId) {
            if (self::canCreateTaskOn($project, $teamId)) {
                return true;
            }
        }

        return false;
    }

    /** True when $userId is assigned to $task. */
    public static function isAssignee(array $task, int $userId): bool
    {
        if ($userId < 1) {
            return false;
        }

        $ids = $task['assignee_ids'] ?? [];
        if (!is_array($ids)) {
            return false;
        }

        foreach ($ids as $id) {
            if ((int) $id === $userId) {
                return true;
            }
        }

        return false;
    }

    public static function deny(string $message): never
    {
        LoggerHelper::warning('Workspace policy denied', [
            'user_id' => AuthHelper::id(),
            'feature' => 'task_scope',
            'status'  => 403,
            'message' => $message,
        ]);

        throw new HttpException(403, $message);
    }

    /* ------------------------------------------------------------------ internals */

    private static function reasonCreate(string $pos, ?int $teamId, int $projectId, string $teamName): ?string
    {
        $policy = WorkspacePolicy::taskCreationPolicy();
        if ($policy === 'admins' && $pos !== self::POS_ADMIN) {
            return 'Task creation is limited to administrators.';
        }

        $rank = self::RANK[$pos] ?? 0;
        if ($rank >= self::RANK[self::POS_PM]) {
            return null;
        }

        if ($teamId === null || $teamId < 1) {
            return 'Only the project manager can create a project-level task.';
        }

        if ($rank >= self::RANK[self::POS_TEAM_LEAD]) {
            return null;
        }

        unset($projectId);

        return $teamName !== ''
            ? 'Only the lead or manager of ' . $teamName . ' can create a task for that team.'
            : 'You cannot create a task for that team.';
    }

    private static function reasonMutate(string $pos, int $rank, string $teamName): ?string
    {
        if ($rank >= self::RANK[self::POS_TEAM_LEAD]) {
            return null;
        }

        unset($pos);

        return $teamName !== ''
            ? 'Only the lead or manager of ' . $teamName . ' can edit this task.'
            : 'Only the project manager can edit this task.';
    }

    private static function reasonAssign(string $pos, int $rank, string $teamName): ?string
    {
        if ($rank >= self::RANK[self::POS_TEAM_LEAD]) {
            return null;
        }

        unset($pos);

        return $teamName !== ''
            ? 'Only the lead or manager of ' . $teamName . ' can assign this task.'
            : 'Only the project manager can assign this task.';
    }

    /**
     * @param array<string, mixed>|null $task
     */
    private static function reasonStatus(string $pos, int $rank, ?array $task, int $userId, string $teamName): ?string
    {
        if ($rank >= self::RANK[self::POS_TEAM_LEAD]) {
            return null;
        }

        if ($task !== null && ($pos === self::POS_TEAM_MEMBER || $pos === self::POS_PROJECT_MEMBER)
            && self::isAssignee($task, $userId)) {
            return null;
        }

        return $teamName !== ''
            ? 'Only the lead or manager of ' . $teamName . ' can change this task, or the assignee for their own work.'
            : 'You can only change the status of tasks assigned to you.';
    }

    /**
     * @param array<string, mixed>|null $task
     */
    private static function reasonReview(string $pos, int $rank, ?array $task, int $userId, string $teamName): ?string
    {
        if ($rank < self::RANK[self::POS_TEAM_LEAD]) {
            return $teamName !== ''
                ? 'Only the lead or manager of ' . $teamName . ' can review this task.'
                : 'Only the project manager can review this task.';
        }

        if ($task !== null && self::isAssignee($task, $userId) && $pos !== self::POS_ADMIN) {
            return 'You cannot review your own work.';
        }

        return null;
    }

    /**
     * @param array<string, mixed> $task
     */
    private static function taskTeamId(array $task, ?int $override): ?int
    {
        if ($override !== null) {
            return $override > 0 ? $override : null;
        }

        if (!isset($task['team_id']) || $task['team_id'] === null || $task['team_id'] === '') {
            return null;
        }

        $id = (int) $task['team_id'];

        return $id > 0 ? $id : null;
    }

    private static function teamBelongsToProject(int $teamId, int $projectId): bool
    {
        $team = ApprovalChainHelper::snapshot()['teams'][$teamId] ?? null;

        return $team !== null && (int) $team['project_id'] === $projectId;
    }

    private static function teamName(?int $teamId): string
    {
        if ($teamId === null || $teamId < 1) {
            return '';
        }

        return (string) (ApprovalChainHelper::snapshot()['teamNames'][$teamId] ?? '');
    }

    /**
     * @return list<int>
     */
    private static function teamAssignableIds(int $projectId, int $teamId): array
    {
        $snap = ApprovalChainHelper::snapshot();
        $team = $snap['teams'][$teamId] ?? null;
        if ($team === null || (int) $team['project_id'] !== $projectId) {
            return [];
        }

        $ids = [];
        foreach ([(int) $team['manager_id'], (int) $team['lead_id']] as $uid) {
            if ($uid > 0) {
                $ids[] = $uid;
            }
        }
        foreach ($snap['teamMemberIds'][$teamId] ?? [] as $uid) {
            $ids[] = (int) $uid;
        }

        $out = [];
        foreach (array_unique($ids) as $uid) {
            $uid = (int) $uid;
            if ($uid < 1 || !isset($snap['active'][$uid])) {
                continue;
            }
            $role = strtolower((string) ($snap['projectMemberRoles'][$uid][$projectId] ?? ''));
            $isPm = (int) ($snap['projectManager'][$projectId] ?? 0) === $uid;
            if ($role === 'viewer') {
                continue;
            }
            if ($role === '' && !$isPm) {
                continue;
            }
            $out[] = $uid;
        }

        return array_values($out);
    }

    /**
     * @param array<string, mixed> $snap
     */
    private static function assignRejectMessage(int $uid, int $projectId, ?int $teamId, string $teamName, array $snap): string
    {
        $name = (string) ($snap['userNames'][$uid] ?? ('User #' . $uid));
        $role = strtolower((string) ($snap['projectMemberRoles'][$uid][$projectId] ?? ''));
        $onProject = isset($snap['projectMemberSet'][$uid][$projectId])
            || (int) ($snap['projectManager'][$projectId] ?? 0) === $uid;

        if ($role === 'viewer') {
            return $name . ' is a viewer.';
        }
        if (!$onProject) {
            return $name . ' is not on this project.';
        }
        if ($teamId !== null && $teamId > 0) {
            return $teamName !== ''
                ? $name . ' is not in team ' . $teamName
                : $name . ' is not in that team.';
        }

        return $name . ' cannot be assigned this task.';
    }
}
