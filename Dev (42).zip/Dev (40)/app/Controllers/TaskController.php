<?php
/**
 * Task actions for the project page "Tasks" tab: add, edit (modal), status,
 * inline rename, inline assignees and delete.
 *
 * There is no stand-alone /tasks page. Every action here is a POST that returns
 * to /projects/{id}?tab=tasks (or answers JSON for the inline controls).
 */

declare(strict_types=1);

final class TaskController extends Controller
{
    private Task $tasks;
    private Project $projects;
    private ProjectMember $members;

    public function __construct()
    {
        parent::__construct(true);
        FeatureFlagsHelper::requireProjects();
        $this->tasks    = new Task();
        $this->projects = new Project();
        $this->members  = new ProjectMember();
    }

    /**
     * The Tasks tab has no per-field error display, so show the first error as a flash message.
     *
     * @param array<string, string> $errors
     */
    protected function backWithErrors(string $path, array $errors): never
    {
        $first = reset($errors);
        if (is_string($first) && $first !== '') {
            $this->flash('danger', $first);
        }

        parent::backWithErrors($path, $errors);
    }

    /** POST /projects/{id}/tasks */
    public function store(Request $request, array $params): void
    {
        $this->requireTaskCapability('tasks.create', $request);
        if (TaskPolicy::isLegacy()) {
            WorkspacePolicy::requireCanCreateTask();
        }
        $this->requireInstalled();

        $projectId = (int) ($params['id'] ?? $request->input('project_id', 0));
        // Validation errors return to the project's Tasks tab (there is no stand-alone task form).
        $failPath  = $this->tasksTabPath($projectId);

        $project = $this->loadVisibleProject($projectId);
        $this->assertProjectOpen($project, $failPath);

        $teamId = $this->resolveCreateTeamId($project);
        if (TaskPolicy::isStrict()) {
            $reason = TaskPolicy::denyReason('create', null, $project, $teamId);
            if ($reason !== null) {
                $this->rejectAction($request, $reason, $failPath);
            }
        }

        $data = $this->validatedTask($failPath, $project, null, $teamId);

        if ($this->tasks->nameTaken(
            (int) $project['id'],
            $data['name'],
            null,
            $data['parent_task_id']
        )) {
            $this->backWithErrors($failPath, ['name' => 'A task with this name already exists at this level.']);
        }

        $id = $this->tasks->create([
            'project_id'         => (int) $project['id'],
            'parent_task_id'     => $data['parent_task_id'],
            'name'               => $data['name'],
            'description'        => $data['description'],
            'status'             => $data['status'],
            'priority'           => $data['priority'],
            'estimated_hours'    => $data['estimated_hours'],
            'completion_percent' => $data['completion_percent'],
            'start_date'         => $data['start_date'],
            'due_date'           => $data['due_date'],
            'is_billable'        => $data['is_billable'],
            'created_by'         => (int) AuthHelper::id(),
        ]);

        $assigneeIds = $this->resolveAssignees((int) $project['id'], $data['assigned_to'], $teamId);
        if ($assigneeIds !== []) {
            try {
                TaskPolicy::assertAssignable((int) AuthHelper::id(), $project, $teamId, $assigneeIds);
            } catch (HttpException $e) {
                $this->backWithErrors($failPath, ['assigned_to' => $e->getMessage()]);
            }
            $this->tasks->syncAssignees(
                $id,
                $assigneeIds,
                $this->assignableIds($project, $teamId)
            );
        }

        if ($data['parent_task_id'] !== null) {
            $this->tasks->recalculateAncestors($id);
        }

        LoggerHelper::audit('task.created', 'task', $id, [
            'project_id' => (int) $project['id'],
            'name'       => $data['name'],
        ]);
        $this->notifyAssignees(
            $assigneeIds,
            (string) $data['name'],
            $id,
            (int) $project['id'],
            (string) ($project['name'] ?? '')
        );

        $this->flash('success', 'Task "' . $data['name'] . '" was added.');
        $this->redirect($this->afterSavePath($request, $id, (int) $project['id']));
    }

    /** POST /tasks/{id} */
    public function update(Request $request, array $params): void
    {
        $this->requireTaskCapability('tasks.edit', $request);
        $this->requireInstalled();

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));
        $failPath = $this->tasksTabPath((int) $project['id']);
        $teamId   = $this->taskTeamId($task);

        $this->assertScope('edit', $task, $project, $teamId, $request);

        $data = $this->validatedTask($failPath, $project, (int) $task['id'], $teamId);
        $oldParentId = $this->parentId($task);

        // The edit modal only posts name, description, status, estimate, due date and assignees.
        // Anything it does not post keeps its stored value instead of being reset to a default.
        $posted = $request->all();
        if (!array_key_exists('priority', $posted)) {
            $data['priority'] = (string) $task['priority'];
        }
        if (!array_key_exists('start_date', $posted)) {
            $data['start_date'] = $task['start_date'] !== null && $task['start_date'] !== '' ? (string) $task['start_date'] : null;
        }
        if (!array_key_exists('is_billable', $posted)) {
            $data['is_billable'] = (int) $task['is_billable'] === 1 ? 1 : 0;
        }
        if (!array_key_exists('parent_task_id', $posted)) {
            $data['parent_task_id'] = $oldParentId;
        }
        if (!array_key_exists('completion_percent', $posted) && (string) $data['status'] === Task::normalizeStatus((string) $task['status'])) {
            $data['completion_percent'] = (int) $task['completion_percent'];
        }
        if ($data['start_date'] !== null && $data['due_date'] !== null && $data['due_date'] < $data['start_date']) {
            $this->backWithErrors($failPath, ['due_date' => 'Due date cannot be before the start date.']);
        }

        if (Task::isDone((string) $task['status']) && (string) $data['name'] !== (string) $task['name']) {
            $this->backWithErrors($failPath, ['name' => 'Completed tasks cannot be renamed. Mark the task active first.']);
        }

        if ($this->tasks->nameTaken(
            (int) $project['id'],
            $data['name'],
            (int) $task['id'],
            $data['parent_task_id']
        )) {
            $this->backWithErrors($failPath, ['name' => 'A task with this name already exists at this level.']);
        }

        $this->tasks->update((int) $task['id'], [
            'parent_task_id'     => $data['parent_task_id'],
            'name'               => $data['name'],
            'description'        => $data['description'],
            'status'             => $data['status'],
            'priority'           => $data['priority'],
            'estimated_hours'    => $data['estimated_hours'],
            'completion_percent' => $data['completion_percent'],
            'start_date'         => $data['start_date'],
            'due_date'           => $data['due_date'],
            'is_billable'        => $data['is_billable'],
        ]);

        $assigneeIds = $this->resolveAssignees((int) $project['id'], $data['assigned_to'], $teamId);
        if (TaskPolicy::hasCapability('tasks.assign') && TaskPolicy::can('assign', $task, $project, $teamId)) {
            try {
                TaskPolicy::assertAssignable((int) AuthHelper::id(), $project, $teamId, $assigneeIds);
            } catch (HttpException $e) {
                $this->backWithErrors($failPath, ['assigned_to' => $e->getMessage()]);
            }
            $this->tasks->syncAssignees(
                (int) $task['id'],
                $assigneeIds,
                $this->assignableIds($project, $teamId)
            );
        }

        $this->tasks->recalculateAncestors((int) $task['id']);
        if ($oldParentId !== null && $oldParentId !== $data['parent_task_id']) {
            // The task moved: its previous parent lost a child and must be recalculated too.
            $this->tasks->refreshFrom($oldParentId);
        }

        LoggerHelper::audit('task.updated', 'task', (int) $task['id'], ['name' => $data['name']]);
        $this->notifyAssignees(
            $assigneeIds,
            (string) $data['name'],
            (int) $task['id'],
            (int) $project['id'],
            (string) ($project['name'] ?? '')
        );

        $this->flash('success', 'Task "' . $data['name'] . '" was updated.');
        $this->redirect($this->afterSavePath($request, (int) $task['id'], (int) $project['id']));
    }

    /** POST /tasks/{id}/status  (AJAX from the project Tasks tab, or a plain form post with "back") */
    public function status(Request $request, array $params): void
    {
        $this->requireTaskCapability('tasks.edit', $request);
        $this->requireInstalled();

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));
        $backPath = $this->safeBack($request, $this->tasksTabPath((int) $project['id']));
        $status   = Task::normalizeStatus((string) $request->input('status', ''));
        $percent  = $request->input('completion_percent', null);
        $teamId   = $this->taskTeamId($task);

        $this->assertScope('status', $task, $project, $teamId, $request);

        if (!in_array($status, Task::STATUSES, true)) {
            if ($request->wantsJson() || $request->isAjax()) {
                $this->json(['ok' => false, 'message' => 'Choose a valid task status.'], 422);
            }
            $this->flash('danger', 'Choose a valid task status.');
            $this->redirect($backPath);
        }

        if (TaskPolicy::isStrict()) {
            $reason = $this->memberStatusReason($task, $status);
            if ($reason !== null) {
                $this->rejectAction($request, $reason, $backPath);
            }
        }

        $pct = $percent === null || $percent === '' ? null : (int) $percent;
        $this->tasks->setStatus((int) $task['id'], $status, $pct);

        LoggerHelper::audit('task.status_changed', 'task', (int) $task['id'], [
            'from' => (string) $task['status'],
            'to'   => $status,
        ]);

        $fresh  = $this->tasks->findDetailed((int) $task['id']) ?? $task;
        $pctOut = (int) ($fresh['completion_percent'] ?? Task::percentForStatus($status));

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json([
                'ok'                 => true,
                'status'             => $status,
                'completion_percent' => $pctOut,
                'status_css'         => Task::statusCss($status),
            ]);
        }

        $this->flash('success', '"' . $task['name'] . '" is now ' . $status . '.');
        $this->redirect($backPath);
    }

    /** POST /tasks/{id}/rename (inline edit on the project Tasks tab, JSON) */
    public function rename(Request $request, array $params): void
    {
        $this->requireTaskCapability('tasks.edit', $request);
        $this->requireInstalled();

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));
        $this->assertScope('rename', $task, $project, $this->taskTeamId($task), $request);
        $name = trim((string) $request->input('name', ''));

        if ($name === '' || mb_strlen($name) > 180) {
            $this->json(['ok' => false, 'message' => 'Task name must be 1 to 180 characters.', 'name' => (string) $task['name']], 422);
        }

        if ($name !== (string) $task['name']) {
            if (Task::isDone((string) $task['status'])) {
                $this->json(['ok' => false, 'message' => 'Completed tasks cannot be renamed. Mark the task active first.', 'name' => (string) $task['name']], 422);
            }
            if ($this->tasks->nameTaken((int) $task['project_id'], $name, (int) $task['id'], $this->parentId($task))) {
                $this->json(['ok' => false, 'message' => 'A task with this name already exists.', 'name' => (string) $task['name']], 422);
            }

            $this->tasks->update((int) $task['id'], ['name' => $name]);
            LoggerHelper::audit('task.updated', 'task', (int) $task['id'], ['name' => $name]);
        }

        $this->json(['ok' => true, 'name' => $name]);
    }

    /** POST /tasks/{id}/assignees (inline assignee picker on the project Tasks tab, JSON) */
    public function assignees(Request $request, array $params): void
    {
        $this->requireTaskCapability('tasks.assign', $request);
        $this->requireInstalled();

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));
        $teamId = $this->taskTeamId($task);
        $this->assertScope('assign', $task, $project, $teamId, $request);

        $assigneeIds = $this->postedAssigneeIds();
        try {
            TaskPolicy::assertAssignable((int) AuthHelper::id(), $project, $teamId, $assigneeIds);
        } catch (HttpException $e) {
            $this->json(['ok' => false, 'message' => $e->getMessage()], $e->status());
        }
        $this->tasks->syncAssignees((int) $task['id'], $assigneeIds, $this->assignableIds($project, $teamId));

        $names = [];
        foreach ($this->members->forProject((int) $project['id']) as $member) {
            if (in_array((int) $member['user_id'], $assigneeIds, true)) {
                $names[] = (string) $member['name'];
            }
        }
        sort($names, SORT_NATURAL | SORT_FLAG_CASE);

        LoggerHelper::audit('task.updated', 'task', (int) $task['id'], [
            'name'      => (string) $task['name'],
            'assignees' => count($assigneeIds),
        ]);
        $this->notifyAssignees(
            $assigneeIds,
            (string) $task['name'],
            (int) $task['id'],
            (int) $project['id'],
            (string) ($project['name'] ?? '')
        );

        $this->json(['ok' => true, 'names' => $names]);
    }

    /** POST /tasks/{id}/delete */
    public function destroy(Request $request, array $params): void
    {
        $this->requireTaskCapability('tasks.delete', $request);
        $this->requireInstalled();

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));
        $this->assertScope('delete', $task, $project, $this->taskTeamId($task), $request);
        $parentId = $this->parentId($task);

        $this->tasks->deleteWithLinks((int) $task['id']);

        if ($parentId !== null) {
            $this->tasks->refreshFrom($parentId);
        }

        LoggerHelper::audit('task.deleted', 'task', (int) $task['id'], [
            'project_id' => (int) $project['id'],
            'name'       => (string) $task['name'],
        ]);
        $this->flash('success', 'Task "' . $task['name'] . '" was deleted.');

        $this->redirect($this->safeBack($request, $this->tasksTabPath((int) $project['id'])));
    }

    private function requireInstalled(): void
    {
        if (!Task::installed()) {
            $this->flash('warning', 'Tasks are not installed yet. Run database/UPGRADE_LIVE.sql in phpMyAdmin, then reload.');
            $this->redirect('/dashboard');
        }
    }

    /** @return array<string, mixed> */
    private function loadVisibleProject(int $id): array
    {
        if ($id < 1) {
            $this->notFound();
        }

        $project = $this->projects->findWithRelations($id);
        if ($project === null) {
            $this->notFound();
        }

        if (!$this->projects->userCanView($project, (int) AuthHelper::id(), PermissionHelper::has('projects.view_all'))) {
            $this->forbidden();
        }
        ClientScope::assertCanSeeProject($project);

        return $project;
    }

    /** @return array{0: array<string, mixed>, 1: array<string, mixed>} [task, project] */
    private function loadTask(int $id): array
    {
        if ($id < 1 || !Task::installed()) {
            $this->notFound();
        }

        $task = $this->tasks->findDetailed($id) ?? $this->tasks->find($id);
        if ($task === null) {
            $this->notFound();
        }

        return [$task, $this->loadVisibleProject((int) $task['project_id'])];
    }

    /** @param array<string, mixed> $project */
    private function assertProjectOpen(array $project, string $back): void
    {
        if ((string) $project['status'] === Project::STATUS_ARCHIVED) {
            $this->flash('danger', 'Archived projects cannot receive new tasks.');
            $this->redirect($back);
        }
    }

    /**
     * @param array<string, mixed> $project
     * @return array<string, mixed>
     */
    private function validatedTask(string $failPath, array $project, ?int $ignoreId = null, ?int $teamId = null): array
    {
        $statusList   = implode(',', Task::STATUSES);
        $priorityList = implode(',', Task::PRIORITIES);

        $data = $this->validate([
            'name'               => 'required|string|max:180',
            'description'        => 'nullable|string|max:5000',
            'status'             => 'nullable|in:' . $statusList,
            'priority'           => 'nullable|in:' . $priorityList,
            'parent_task_id'     => 'nullable|int',
            'assigned_to'        => 'nullable|int',
            'estimated_hours'    => 'nullable|numeric|min:0|max:9999',
            'completion_percent' => 'nullable|int|min:0|max:100',
            'start_date'         => 'nullable|date',
            'due_date'           => 'nullable|date',
            'is_billable'        => 'nullable|boolean',
        ], $failPath, [
            'name'               => 'Task name',
            'description'        => 'Description',
            'status'             => 'Status',
            'priority'           => 'Priority',
            'parent_task_id'     => 'Parent task',
            'assigned_to'        => 'Assignee',
            'estimated_hours'    => 'Estimated hours',
            'completion_percent' => 'Completion',
            'start_date'         => 'Start date',
            'due_date'           => 'Due date',
            'is_billable'        => 'Billable',
        ]);

        $status = Task::normalizeStatus((string) ($data['status'] ?? Task::STATUS_TODO));
        if (!in_array($status, Task::STATUSES, true)) {
            $status = Task::STATUS_TODO;
        }

        $parentId = isset($data['parent_task_id']) && (int) $data['parent_task_id'] > 0
            ? (int) $data['parent_task_id'] : null;
        if ($parentId !== null) {
            $parent = $this->tasks->find($parentId);
            if ($parent === null || (int) $parent['project_id'] !== (int) $project['id']) {
                $this->backWithErrors($failPath, ['parent_task_id' => 'Choose a parent task from the same project.']);
            }
            if ($ignoreId !== null && $parentId === $ignoreId) {
                $this->backWithErrors($failPath, ['parent_task_id' => 'A task cannot be its own parent.']);
            }
            if ($ignoreId !== null) {
                $blocked = $this->tasks->parentOptions((int) $project['id'], $ignoreId);
                $ok = false;
                foreach ($blocked as $option) {
                    if ((int) $option['id'] === $parentId) {
                        $ok = true;
                        break;
                    }
                }
                if (!$ok) {
                    $this->backWithErrors($failPath, ['parent_task_id' => 'A task cannot be nested under one of its own subtasks.']);
                }
            }
        }

        $assignedTo = isset($data['assigned_to']) && (int) $data['assigned_to'] > 0
            ? (int) $data['assigned_to'] : null;
        if ($assignedTo !== null && !in_array($assignedTo, $this->assignableIds($project, $teamId), true)) {
            $this->backWithErrors($failPath, ['assigned_to' => 'Assignee must be a member of the project.']);
        }

        $startDate = isset($data['start_date']) && $data['start_date'] !== '' ? (string) $data['start_date'] : null;
        $dueDate   = isset($data['due_date']) && $data['due_date'] !== '' ? (string) $data['due_date'] : null;
        if ($startDate !== null && $dueDate !== null && $dueDate < $startDate) {
            $this->backWithErrors($failPath, ['due_date' => 'Due date cannot be before the start date.']);
        }

        $percent = isset($data['completion_percent']) ? (int) $data['completion_percent'] : Task::percentForStatus($status);
        if ($status === Task::STATUS_COMPLETED) {
            $percent = 100;
        } elseif ($status === Task::STATUS_TODO && $percent === 0) {
            $percent = 0;
        }

        $billable = $data['is_billable'] ?? null;
        $isBillable = in_array($billable, [1, '1', true, 'true', 'on', 'yes'], true) ? 1 : 0;
        if ($billable === null) {
            $isBillable = (int) ($project['is_billable'] ?? 0) === 1 ? 1 : 0;
        }

        return [
            'name'               => (string) $data['name'],
            'description'        => isset($data['description']) && $data['description'] !== '' ? (string) $data['description'] : null,
            'status'             => $status,
            'priority'           => in_array((string) ($data['priority'] ?? ''), Task::PRIORITIES, true)
                ? (string) $data['priority'] : Task::PRIORITY_MEDIUM,
            'parent_task_id'     => $parentId,
            'assigned_to'        => $assignedTo,
            'estimated_hours'    => isset($data['estimated_hours']) ? (float) $data['estimated_hours'] : 0,
            'completion_percent' => max(0, min(100, $percent)),
            'start_date'         => $startDate,
            'due_date'           => $dueDate,
            'is_billable'        => $isBillable,
        ];
    }

    /** @return list<int> */
    private function postedAssigneeIds(): array
    {
        $raw = $this->request->input('assignee_ids', []);
        if (!is_array($raw)) {
            $raw = $raw === null || $raw === '' ? [] : [$raw];
        }

        $ids = [];
        foreach ($raw as $value) {
            $id = (int) $value;
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * Users who may be assigned work on a project: non-viewer members plus its manager.
     *
     * @param array<string, mixed> $project
     * @return list<int>
     */
    private function assignableIds(array $project, ?int $teamId = null): array
    {
        return TaskPolicy::assignableIdsFor((int) AuthHelper::id(), $project, $teamId);
    }

    /**
     * @return list<int>
     */
    private function resolveAssignees(int $projectId, ?int $assignedTo, ?int $teamId = null): array
    {
        unset($projectId, $teamId);
        $ids = $this->postedAssigneeIds();
        if ($ids === [] && $assignedTo !== null) {
            $ids = [$assignedTo];
        }

        if (!TaskPolicy::hasCapability('tasks.assign') && $ids === [] && $assignedTo === null) {
            return [];
        }

        return $ids;
    }

    /**
     * @param array<string, mixed> $project
     */
    private function resolveCreateTeamId(array $project): ?int
    {
        $raw = $this->request->input('team_id', null);
        $posted = ($raw === null || $raw === '') ? null : (int) $raw;
        if ($posted !== null && $posted < 1) {
            $posted = null;
        }

        if (TaskPolicy::isLegacy()) {
            return $posted;
        }

        $userId    = (int) AuthHelper::id();
        $projectId = (int) $project['id'];
        $pos       = TaskPolicy::positionFor($userId, $projectId, $posted);

        if (in_array($pos, [TaskPolicy::POS_ADMIN, TaskPolicy::POS_PM], true)) {
            return $posted;
        }

        $ownTeams = TaskPolicy::teamsOf($userId, $projectId);
        $creatable = [];
        foreach ($ownTeams as $id) {
            if (TaskPolicy::can('create', null, $project, $id)) {
                $creatable[] = $id;
            }
        }
        if ($posted === null) {
            return $creatable[0] ?? null;
        }
        if (!in_array($posted, $creatable, true) && !TaskPolicy::can('create', null, $project, $posted)) {
            return $posted;
        }

        return $posted;
    }

    /** @param array<string, mixed> $task */
    private function taskTeamId(array $task): ?int
    {
        if (!isset($task['team_id']) || $task['team_id'] === null || $task['team_id'] === '') {
            return null;
        }
        $id = (int) $task['team_id'];

        return $id > 0 ? $id : null;
    }

    /**
     * @param array<string, mixed> $task
     * @param array<string, mixed> $project
     */
    private function assertScope(string $action, array $task, array $project, ?int $teamId, Request $request): void
    {
        if (TaskPolicy::isLegacy()) {
            return;
        }

        $reason = TaskPolicy::denyReason($action, $task, $project, $teamId);
        if ($reason === null) {
            return;
        }

        $this->rejectAction($request, $reason, $this->tasksTabPath((int) $project['id']));
    }

    private function rejectAction(Request $request, string $message, string $backPath): never
    {
        LoggerHelper::warning('Workspace policy denied', [
            'user_id' => AuthHelper::id(),
            'feature' => 'task_scope',
            'status'  => 403,
            'message' => $message,
        ]);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json(['ok' => false, 'message' => $message], 403);
        }

        throw new HttpException(403, $message);
    }

    private function requireTaskCapability(string $permission, Request $request): void
    {
        try {
            TaskPolicy::requireCapability($permission);
        } catch (HttpException $e) {
            if ($e->status() === 403 && ($request->wantsJson() || $request->isAjax())) {
                $message = $e->getMessage() !== '' ? $e->getMessage() : 'You do not have permission to do that.';
                $this->json(['ok' => false, 'message' => $message], 403);
            }
            throw $e;
        }
    }

    /**
     * Members may move own assigned tasks To Do ↔ In Progress ↔ On Hold and to Review.
     * Never Completed or Cancelled.
     *
     * @param array<string, mixed> $task
     */
    private function memberStatusReason(array $task, string $to): ?string
    {
        $userId    = (int) AuthHelper::id();
        $projectId = (int) ($task['project_id'] ?? 0);
        $pos       = TaskPolicy::positionFor($userId, $projectId, $this->taskTeamId($task));
        $rank      = match ($pos) {
            TaskPolicy::POS_ADMIN, TaskPolicy::POS_PM, TaskPolicy::POS_TEAM_MANAGER, TaskPolicy::POS_TEAM_LEAD => 2,
            default => 1,
        };
        if ($rank >= 2) {
            return null;
        }

        if (in_array($to, [Task::STATUS_COMPLETED, Task::STATUS_CANCELLED], true)) {
            return 'This task needs review before it can be completed.';
        }

        $allowed = [Task::STATUS_TODO, Task::STATUS_IN_PROGRESS, Task::STATUS_ON_HOLD, Task::STATUS_REVIEW];
        if (!in_array($to, $allowed, true)) {
            return 'You cannot set that status.';
        }

        return null;
    }

    /**
     * @param list<int> $assigneeIds
     */
    private function notifyAssignees(array $assigneeIds, string $taskName, int $taskId, int $projectId, string $projectName): void
    {
        $actor = (int) AuthHelper::id();

        foreach ($assigneeIds as $assigneeId) {
            if ($assigneeId === $actor) {
                continue;
            }
            NotificationHelper::taskAssigned($assigneeId, $taskName, $taskId, $projectId, $projectName);
            LoggerHelper::taskAssigned($taskId, $assigneeId, $taskName, $projectId);
        }
    }

    /** @param array<string, mixed> $task */
    private function parentId(array $task): ?int
    {
        if (!isset($task['parent_task_id']) || $task['parent_task_id'] === null || $task['parent_task_id'] === '') {
            return null;
        }
        $id = (int) $task['parent_task_id'];

        return $id > 0 ? $id : null;
    }

    /** Where every task action returns to: the project's Tasks tab. */
    private function tasksTabPath(int $projectId): string
    {
        return $projectId > 0 ? '/projects/' . $projectId . '?tab=tasks' : '/projects';
    }

    /**
     * A "back" path posted by the Tasks tab, accepted only when it is an internal path.
     * Anything else (empty, //host, backslashes, line breaks) falls back to $fallback.
     */
    private function safeBack(Request $request, string $fallback): string
    {
        $back = (string) $request->input('back', '');
        if ($back !== '' && $back[0] === '/' && !str_starts_with($back, '//')
            && !str_contains($back, '\\') && !preg_match('/[\r\n]/', $back)) {
            return $back;
        }

        return $fallback;
    }

    private function afterSavePath(Request $request, int $taskId, int $projectId): string
    {
        return $this->safeBack($request, $this->tasksTabPath($projectId));
    }
}
