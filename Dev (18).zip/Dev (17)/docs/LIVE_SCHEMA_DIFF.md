# Live schema diff used for Step 20

Compared against the supplied production dump `u897128490_timetrack (4).sql` from 2026-10-02.

The dump was **not** the final Step-17 schema. It still contained:

- `activity_logs.record_id` — removed by Phase 13 Step 17 in the final application schema.
- `tasks.assigned_to` — replaced by `task_assignees` in Phase 13 Step 17.
- `time_entries` did not yet contain `schedule_id`, `break_minutes`, `billable_rate`, `status`, `approved_by`, or `approved_at`.

The consolidated `database/install.sql` represents the **post-migration application schema**, not a byte-for-byte copy of that historical dump. The Step 19 upgrade migration adds the missing time-entry fields and snapshots the current project hourly rate into `time_entries.billable_rate` only for legacy rows whose frozen rate is zero.

This is the required reconciliation point for billing reports: after the migration, every billable legacy entry has a rate snapshot and future entries retain the rate frozen at creation time.
