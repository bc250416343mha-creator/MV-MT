# Step 20 — TimeTrack test matrix

Run this matrix against a clean staging database after installing `database/install.sql` and the required seed accounts. For every route below, also perform a direct-URL access test as each role; where the role lacks permission the expected result is **403** (feature-disabled routes may intentionally be 404 according to workspace policy).

## Role matrix

| Area | Admin | Manager | Employee | Client |
|---|---|---|---|---|
| Login / logout | ✓ | ✓ | ✓ | ✓ |
| Lockout / failed login | ✓ | ✓ | ✓ | ✓ |
| Password change | ✓ | ✓ | ✓ | ✓ |
| Users CRUD | ✓ | View only where granted | 403 | 403 |
| Client CRUD | ✓ | ✓ | 403 | 403 |
| Project CRUD | ✓ | ✓ | 403/limited by permission | 403/own read-only |
| Member access | ✓ | ✓ | own assignment | 403 |
| Timer start/pause/resume/stop | ✓ | ✓ | ✓ | 403 |
| Second-tab timer | ✓ | ✓ | ✓ | 403 |
| Manual entry/edit/delete | ✓ | ✓ | ✓ | 403 |
| Overlap rejection | ✓ | ✓ | ✓ | n/a |
| 12-hour auto-stop | ✓ | ✓ | ✓ | n/a |
| Timesheet submit | ✓ | ✓ | ✓ | 403 |
| Approve/reject/resubmit | ✓ | ✓ | 403 | 403 |
| Schedule create/recurrence/conflict/drag-resize | ✓ | ✓ | granted schedule roles | 403 on writes |
| Notifications | ✓ | ✓ | ✓ | ✓ |
| Settings on/off | ✓ | 403 | 403 | 403 |
| Dark mode | ✓ | ✓ | ✓ | ✓ |
| Mobile layout | ✓ | ✓ | ✓ | ✓ |
| Reports | ✓ | ✓ | own only | own client only |
| Report billing money | ✓ | ✓ | 403/hidden | 403/hidden |
| Report CSV export | ✓ | ✓ | 403 | 403 |

## Functional tests

1. **Login/lockout** — valid login succeeds; repeated invalid passwords lock the account; lockout expires; password change invalidates old password.
2. **CRUD** — create/edit/delete a client, project, task and user according to role permissions; direct URLs must not bypass controller checks.
3. **Timer** — start → pause → resume → stop; verify Pakistan/user-local display and UTC storage. Open a second tab and confirm only one active timer exists.
4. **Manual/overlap** — add 01:00–02:00, then attempt another entry overlapping that interval; server must reject it. Edit/delete unlocked entries; submitted/approved entries stay locked.
5. **Auto-stop** — set timer max to 12 hours; create a timer at a controlled test timestamp or use the cron script; verify `auto_stopped=1` and a completed entry is created.
6. **Timesheets** — submit selected entries; only those entries lock. Approve/reject; rejected entries can be resubmitted as a new batch.
7. **Scheduling** — create recurring schedules, verify conflicts, drag/resize updates, and direct route authorization.
8. **Notifications** — trigger approval/rejection/timer events and verify unread/read/read-all behavior.
9. **Workspace flags** — turn scheduling/projects/team/reports/timesheet flags on/off and verify both sidebar and direct URL enforcement.
10. **Reports** — compare report total seconds with the Time page under identical dates/billable filters. Employee must only see self. Client must only see rows whose client email matches the logged-in client account. Without `reports.billing`, rate and money fields are absent/hidden. Export CSV and inspect in Excel/LibreOffice; cells beginning `=`, `+`, `-`, `@`, tab or CR must be prefixed with an apostrophe.
11. **Mobile/dark mode** — test 360px/390px/768px widths, navigation, filters, tables and dark theme.

## Direct URL authorization checklist

At minimum test these routes as every role: `/users`, `/clients`, `/projects`, `/team`, `/schedule/team`, `/timesheets/team`, `/settings`, `/workspace`, `/reports`, `/reports/export.csv`, `/time`, `/timesheets`, `/profile`. Expected response is 403 where permission is absent; feature flags may intentionally return 404.
