-- TimeTrack Step 19: Reports module + required time-entry billing snapshot fields.
-- Safe to run on the supplied production dump and on newer installs.
SET NAMES utf8mb4;

-- The supplied 2026-10-02 production dump was missing the frozen billing-rate,
-- approval and schedule/break fields used by the current TimeEntry model.
ALTER TABLE time_entries
    ADD COLUMN IF NOT EXISTS schedule_id INT UNSIGNED NULL AFTER task_id,
    ADD COLUMN IF NOT EXISTS break_minutes INT UNSIGNED NOT NULL DEFAULT 0 AFTER duration_seconds,
    ADD COLUMN IF NOT EXISTS billable_rate DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER is_billable,
    ADD COLUMN IF NOT EXISTS status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending' AFTER billable_rate,
    ADD COLUMN IF NOT EXISTS approved_by INT UNSIGNED NULL AFTER status,
    ADD COLUMN IF NOT EXISTS approved_at DATETIME NULL AFTER approved_by;

ALTER TABLE time_entries
    ADD INDEX IF NOT EXISTS idx_time_entries_schedule (schedule_id),
    ADD INDEX IF NOT EXISTS idx_time_entries_status (status),
    ADD INDEX IF NOT EXISTS idx_time_entries_billable (is_billable),
    ADD INDEX IF NOT EXISTS idx_time_entries_approved_by (approved_by);

-- Snapshot the current project rate exactly once for legacy entries that did not
-- previously have a frozen rate. New timer/manual entries already write their
-- frozen rate through Timer/TimeEntry. Never overwrite a non-zero stored rate.
UPDATE time_entries te
INNER JOIN projects p ON p.id = te.project_id
SET te.billable_rate = CASE
    WHEN te.is_billable = 1 THEN COALESCE(p.hourly_rate,0)
    ELSE 0
END
WHERE COALESCE(te.billable_rate,0) = 0;

-- Add foreign keys only when they do not already exist.
SET @db_name := DATABASE();
SET @sql := IF(
    EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_schema=@db_name AND table_name='time_entries' AND constraint_name='fk_time_entries_schedule'),
    'SELECT 1',
    'ALTER TABLE time_entries ADD CONSTRAINT fk_time_entries_schedule FOREIGN KEY (schedule_id) REFERENCES schedules(id) ON DELETE SET NULL ON UPDATE CASCADE'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(
    EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_schema=@db_name AND table_name='time_entries' AND constraint_name='fk_time_entries_approved_by'),
    'SELECT 1',
    'ALTER TABLE time_entries ADD CONSTRAINT fk_time_entries_approved_by FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

INSERT INTO permissions (name, display_name, module, description) VALUES
('reports.view','View reports','reports','Open reports.'),
('reports.export','Export reports','reports','Download reports as CSV.'),
('reports.billing','View billing figures','reports','See rates and billable amounts.')
ON DUPLICATE KEY UPDATE display_name=VALUES(display_name), module=VALUES(module), description=VALUES(description);

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('admin','manager') AND p.name IN ('reports.view','reports.export','reports.billing');
INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('employee','client') AND p.name='reports.view';
