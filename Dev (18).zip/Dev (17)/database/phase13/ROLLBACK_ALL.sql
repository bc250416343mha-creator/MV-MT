-- TimeTrack Phase 13 complete rollback, reverse order.
-- Review before running on production. Some rollback steps intentionally refuse
-- destructive reversal when history would be lost (e.g. multiple submissions).
-- This script does NOT delete user/time/project data.

SOURCE database/phase13/15_enable_scheduling.down.sql;
SOURCE database/phase13/08_remove_role_schema_duplicates.down.sql;
SOURCE database/phase13/06_settings_workspace_ownership.down.sql;
SOURCE database/phase13/05_schedule_recurrence_parent.down.sql;
SOURCE database/phase13/03_timer_auto_stopped.down.sql;
SOURCE database/phase13/phase13/05_allow_multiple_submission_batches.down.sql;
