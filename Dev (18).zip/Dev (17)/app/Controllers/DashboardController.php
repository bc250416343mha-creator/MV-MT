<?php
/**
 * Role-tailored home: admin/manager get the Clockify-style weekly team dashboard,
 * employees get their own agenda and time.
 */

declare(strict_types=1);

final class DashboardController extends Controller
{
    public function __construct()
    {
        parent::__construct(true);
    }

    /** GET /dashboard  (optional ?week=YYYY-MM-DD&who=team|me) */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('dashboard.view');

        $userId = (int) AuthHelper::id();
        $me = AuthHelper::user() ?? ['name' => '', 'role' => ''];
        $hour = (int) FormatHelper::datetime(gmdate('Y-m-d H:i:s'), 'G');
        $greeting = $hour < 12
            ? 'Good morning'
            : ($hour < 18 ? 'Good afternoon' : 'Good evening');

        $firstName = trim((string) strtok((string) ($me['name'] ?? ''), ' '));

        $unread = 0;
        $notifications = [];
        $canViewNotifications = PermissionHelper::has('notifications.view');

        if ($canViewNotifications) {
            try {
                $unread = (int) Database::fetchValue(
                    'SELECT COUNT(*) FROM notifications WHERE user_id = :id AND is_read = 0',
                    ['id' => $userId]
                );

                $notifications = Database::fetchAll(
                    'SELECT id, type, title, message, link, is_read, created_at
                     FROM notifications
                     WHERE user_id = :id
                     ORDER BY created_at DESC, id DESC
                     LIMIT 6',
                    ['id' => $userId]
                );
            } catch (Throwable) {
                $unread = 0;
                $notifications = [];
            }
        }

        $shared = [
            'pageTitle' => 'Dashboard',
            'greeting' => $greeting,
            'firstName' => $firstName,
            'unread' => $unread,
            'notifications' => $notifications,
            'canViewNotifications' => $canViewNotifications,
            'canTrack' => PermissionHelper::has('time.track')
                && class_exists('Timer')
                && Timer::installed()
                && FeatureFlagsHelper::trackerVisible(),
            'currency' => AnalyticsHelper::currency(),
        ];

        $isLead = AuthHelper::hasRole(
            AuthHelper::ROLE_ADMIN,
            AuthHelper::ROLE_MANAGER
        );

        if ($isLead) {
            $this->adminManager($request, $shared, $userId);
            return;
        }

        $this->employee($shared, $userId);
    }

    /**
     * @param array<string, mixed> $shared
     */
    private function adminManager(Request $request, array $shared, int $userId): void
    {
        $viewAll = PermissionHelper::has('projects.view_all')
            || AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);

        // Both values are validated inside the helper (Y-m-d) or compared to a fixed word.
        $weekParam = (string) $request->input('week', '');
        $onlyMe    = (string) $request->input('who', 'team') === 'me';

        try {
            $week = WeekDashboardHelper::build(
                $userId,
                $viewAll,
                $weekParam !== '' ? $weekParam : null,
                $onlyMe
            );
        } catch (Throwable $e) {
            // Never break the home page because of a reporting query; log and show an empty week.
            LoggerHelper::exception($e);
            $week = WeekDashboardHelper::build($userId, $viewAll, null, true);
            $week['ready'] = false;
        }

        $pending = 0;
        $canApprove = PermissionHelper::has('time.approve');
        if ($canApprove && FeatureFlagsHelper::timeApprovalEnabled() && Timesheet::installed()) {
            try {
                $isAdmin = AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);
                $pending = (int) ((new Timesheet())->queueCounts((int) $userId, $isAdmin)['Submitted'] ?? 0);
            } catch (Throwable) {
                $pending = 0;
            }
        }

        $this->render(
            'dashboard/admin_manager',
            array_merge($shared, [
                'week' => $week,
                'canApprove' => $canApprove,
                'pendingApprovals' => $pending,
                'chartAssets' => true,
            ])
        );
    }

    /**
     * @param array<string, mixed> $shared
     */
    private function employee(array $shared, int $userId): void
    {
        $today = AnalyticsHelper::employeeToday($userId);
        $projects = [];

        if (class_exists('TimeEntry') && TimeEntry::installed()) {
            $projects = (new TimeEntry())->trackableProjects(
                $userId,
                PermissionHelper::has('projects.view_all')
            );
        }

        $this->render(
            'dashboard/employee',
            array_merge($shared, [
                'today' => $today,
                'projects' => $projects,
                'canManual' => PermissionHelper::has('time.edit_own') && FeatureFlagsHelper::allowManual(),
                'canDelete' => PermissionHelper::has('time.edit_own'),
                'canEdit' => PermissionHelper::has('time.edit_own'),
                'userId' => $userId,
                'capacityHours' => WorkspacePolicy::dailyCapacityHours(),
            ])
        );
    }

    /** POST /notifications/read : mark all of the user's notifications as read. */
    public function markNotificationsRead(Request $request, array $params): void
    {
        PermissionHelper::require('notifications.view');

        Database::execute(
            'UPDATE notifications
             SET is_read = 1, read_at = UTC_TIMESTAMP()
             WHERE user_id = :id AND is_read = 0',
            ['id' => (int) AuthHelper::id()]
        );

        if ($request->wantsJson()) {
            $this->json(['ok' => true]);
        }

        $this->redirect('/dashboard');
    }
}