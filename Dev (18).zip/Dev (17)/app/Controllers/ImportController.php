<?php
declare(strict_types=1);

/** CSV importer for initial migration from another time/project system. */
final class ImportController extends Controller
{
    private const TYPES = [
        'users' => 'Users / team members',
        'clients' => 'Clients',
        'projects' => 'Projects',
        'project_members' => 'Project members',
        'tasks' => 'Tasks',
        'task_assignees' => 'Task assignees',
        'time_entries' => 'Historical time entries',
        'schedules' => 'Schedules',
    ];

    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER]);
        PermissionHelper::require('imports.manage');
    }

    public function index(Request $request, array $params): void
    {
        $this->render('imports/index', [
            'pageTitle' => 'Import data',
            'types' => self::TYPES,
            'selected' => (string) $request->input('type', 'users'),
            'result' => null,
        ]);
    }

    public function import(Request $request, array $params): void
    {
        $type = (string) $request->input('type', '');
        if (!isset(self::TYPES[$type])) {
            $this->flash('danger', 'Choose a valid import type.');
            $this->redirect('/import');
        }
        if (!isset($_FILES['csv']) || !is_array($_FILES['csv']) || (int)($_FILES['csv']['error'] ?? 99) !== UPLOAD_ERR_OK) {
            $this->flash('danger', 'Please select a CSV file.');
            $this->redirect('/import?type=' . rawurlencode($type));
        }
        $tmp = (string) $_FILES['csv']['tmp_name'];
        if ((int) ($_FILES['csv']['size'] ?? 0) > 10 * 1024 * 1024) {
            $this->flash('danger', 'CSV is too large. Maximum size is 10 MB.');
            $this->redirect('/import?type=' . rawurlencode($type));
        }
        $rows = $this->readCsv($tmp);
        if ($rows === []) {
            $this->flash('danger', 'The CSV is empty or its header row could not be read.');
            $this->redirect('/import?type=' . rawurlencode($type));
        }
        $result = $this->runImport($type, $rows);
        LoggerHelper::audit('import.completed', 'import', null, [
            'type' => $type, 'rows' => count($rows), 'created' => $result['created'], 'updated' => $result['updated'], 'skipped' => $result['skipped'],
        ]);
        $this->render('imports/index', [
            'pageTitle' => 'Import data', 'types' => self::TYPES, 'selected' => $type, 'result' => $result,
        ]);
    }

    /** @return list<array<string,string>> */
    private function readCsv(string $path): array
    {
        $fh = fopen($path, 'rb');
        if ($fh === false) return [];
        $header = fgetcsv($fh);
        if ($header === false) { fclose($fh); return []; }
        $header = array_map(static fn($v): string => strtolower(trim((string)$v)), $header);
        if (isset($header[0])) $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', $header[0]) ?? $header[0];
        $rows = [];
        while (($line = fgetcsv($fh)) !== false) {
            if (count(array_filter($line, static fn($v): bool => trim((string)$v) !== '')) === 0) continue;
            $row = [];
            foreach ($header as $i => $key) if ($key !== '') $row[$key] = trim((string)($line[$i] ?? ''));
            $rows[] = $row;
        }
        fclose($fh);
        return $rows;
    }

    /** @param list<array<string,string>> $rows */
    private function runImport(string $type, array $rows): array
    {
        $result = ['created'=>0,'updated'=>0,'skipped'=>0,'errors'=>[]];
        foreach ($rows as $n => $row) {
            try {
                $changed = match ($type) {
                    'users' => $this->user($row),
                    'clients' => $this->client($row),
                    'projects' => $this->project($row),
                    'project_members' => $this->projectMember($row),
                    'tasks' => $this->task($row),
                    'task_assignees' => $this->taskAssignee($row),
                    'time_entries' => $this->timeEntry($row),
                    'schedules' => $this->schedule($row),
                };
                if ($changed === 'created') $result['created']++; elseif ($changed === 'updated') $result['updated']++; else $result['skipped']++;
            } catch (Throwable $e) {
                $result['skipped']++;
                if (count($result['errors']) < 100) $result['errors'][] = 'CSV row ' . ($n + 2) . ': ' . $e->getMessage();
                LoggerHelper::exception($e);
            }
        }
        return $result;
    }

    private function user(array $r): string
    {
        foreach (['name','email','role'] as $k) $this->required($r,$k);
        $role = strtolower($r['role']); if (!in_array($role, AuthHelper::ROLES, true)) throw new RuntimeException('Invalid role: '.$role);
        $roleId = (int) Database::fetchValue('SELECT id FROM roles WHERE name=:r', ['r'=>$role]); if (!$roleId) throw new RuntimeException('Role not found: '.$role);
        $email = strtolower($r['email']);
        $existing = Database::fetchOne('SELECT id FROM users WHERE email=:e', ['e'=>$email]);
        $password = $r['password'] !== '' ? $r['password'] : 'ChangeMe123!';
        $data = ['role_id'=>$roleId,'role'=>$role,'name'=>$r['name'],'email'=>$email,'phone'=>$r['phone']??null,'job_title'=>$r['job_title']??null,'hourly_rate'=>$this->num($r['hourly_rate']??'0'),'timezone'=>$r['timezone']!==''?$r['timezone']:'Asia/Karachi','status'=>in_array($r['status']??'active',['active','inactive','suspended'],true)?$r['status']:'active'];
        if ($existing) { Database::execute('UPDATE users SET role_id=:role_id,role=:role,name=:name,phone=:phone,job_title=:job_title,hourly_rate=:hourly_rate,timezone=:timezone,status=:status,updated_at=UTC_TIMESTAMP() WHERE id=:id', $data+['id'=>(int)$existing['id']]); return 'updated'; }
        Database::execute('INSERT INTO users (role_id,role,name,email,password,phone,job_title,hourly_rate,timezone,status,password_changed_at) VALUES (:role_id,:role,:name,:email,:password,:phone,:job_title,:hourly_rate,:timezone,:status,NULL)', $data+['password'=>password_hash($password,PASSWORD_BCRYPT,['cost'=>12])]);
        return 'created';
    }

    private function client(array $r): string
    {
        $this->required($r,'name');
        $existing = $r['email'] !== '' ? Database::fetchOne('SELECT id FROM clients WHERE email=:e', ['e'=>strtolower($r['email'])]) : Database::fetchOne('SELECT id FROM clients WHERE name=:n', ['n'=>$r['name']]);
        $data=['name'=>$r['name'],'email'=>$r['email']!==''?strtolower($r['email']):null,'phone'=>$r['phone']??null,'company'=>$r['company']??null,'address'=>$r['address']??null,'status'=>in_array($r['status']??'active',['active','inactive'],true)?$r['status']:'active'];
        if($existing){Database::execute('UPDATE clients SET name=:name,email=:email,phone=:phone,company=:company,address=:address,status=:status,updated_at=UTC_TIMESTAMP() WHERE id=:id',$data+['id'=>(int)$existing['id']]);return 'updated';}
        Database::execute('INSERT INTO clients (name,email,phone,company,address,status) VALUES (:name,:email,:phone,:company,:address,:status)',$data);return 'created';
    }

    private function project(array $r): string
    {
        foreach(['name','status'] as $k)$this->required($r,$k);
        $existing = $r['project_code']!=='' ? Database::fetchOne('SELECT id FROM projects WHERE project_code=:c',['c'=>$r['project_code']]) : Database::fetchOne('SELECT id FROM projects WHERE name=:n',['n'=>$r['name']]);
        $clientId=$this->lookupClient($r['client_email']??'', $r['client_name']??''); if(!$clientId) throw new RuntimeException('Client not found; provide client_email or client_name'); $managerId=$this->lookupUser($r['manager_email']??'');
        $allowed=['Planning','Active','On Hold','Completed','Archived']; $status=in_array($r['status'],$allowed,true)?$r['status']:'Planning';
        $data=['client_id'=>$clientId,'name'=>$r['name'],'project_code'=>$r['project_code']!==''?$r['project_code']:null,'description'=>$r['description']??null,'status'=>$status,'priority'=>in_array($r['priority']??'Medium',['Low','Medium','High','Urgent'],true)?$r['priority']:'Medium','start_date'=>$r['start_date']!==''?$r['start_date']:null,'due_date'=>$r['due_date']!==''?$r['due_date']:null,'manager_id'=>$managerId ?: null,'created_by'=>$this->lookupUser($r['created_by_email']??'') ?: (int)AuthHelper::id(),'hourly_rate'=>$this->num($r['hourly_rate']??'0'),'is_billable'=>$this->bool($r['is_billable']??'1')];
        if($existing){Database::execute('UPDATE projects SET client_id=:client_id,name=:name,project_code=:project_code,description=:description,status=:status,priority=:priority,start_date=:start_date,due_date=:due_date,manager_id=:manager_id,hourly_rate=:hourly_rate,is_billable=:is_billable,updated_at=UTC_TIMESTAMP() WHERE id=:id',$data+['id'=>(int)$existing['id']]);return 'updated';}
        Database::execute('INSERT INTO projects (client_id,name,project_code,description,status,priority,start_date,due_date,manager_id,created_by,hourly_rate,is_billable) VALUES (:client_id,:name,:project_code,:description,:status,:priority,:start_date,:due_date,:manager_id,:created_by,:hourly_rate,:is_billable)',$data);return 'created';
    }

    private function projectMember(array $r): string
    {
        foreach(['project_code','user_email'] as $k)$this->required($r,$k); $pid=$this->lookupProject($r['project_code']);$uid=$this->lookupUser($r['user_email']);if(!$pid||!$uid)throw new RuntimeException('Project or user not found');
        $role=in_array($r['project_role']??'member',['manager','member','viewer'],true)?$r['project_role']:'member';
        $ex=Database::fetchOne('SELECT 1 FROM project_members WHERE project_id=:p AND user_id=:u',['p'=>$pid,'u'=>$uid]);
        if($ex){Database::execute('UPDATE project_members SET project_role=:r WHERE project_id=:p AND user_id=:u',['r'=>$role,'p'=>$pid,'u'=>$uid]);return 'updated';}
        Database::execute('INSERT INTO project_members (project_id,user_id,project_role) VALUES (:p,:u,:r)',['p'=>$pid,'u'=>$uid,'r'=>$role]);return 'created';
    }

    private function task(array $r): string
    {
        foreach(['project_code','name'] as $k)$this->required($r,$k);$pid=$this->lookupProject($r['project_code']);if(!$pid)throw new RuntimeException('Project not found');
        $ex=Database::fetchOne('SELECT id FROM tasks WHERE project_id=:p AND name=:n',['p'=>$pid,'n'=>$r['name']]);
        $status=$r['status']!==''?$r['status']:'Open'; $data=['project_id'=>$pid,'name'=>$r['name'],'description'=>$r['description']??null,'status'=>in_array($status,['Open','In Progress','Done'],true)?$status:'Open','priority'=>in_array($r['priority']??'Medium',['Low','Medium','High','Urgent'],true)?$r['priority']:'Medium','estimated_hours'=>$this->num($r['estimated_hours']??'0'),'is_billable'=>$this->bool($r['is_billable']??'0'),'created_by'=>(int)AuthHelper::id()];
        if($ex){Database::execute('UPDATE tasks SET description=:description,status=:status,priority=:priority,estimated_hours=:estimated_hours,is_billable=:is_billable,updated_at=UTC_TIMESTAMP() WHERE id=:id',$data+['id'=>(int)$ex['id']]);return 'updated';}
        Database::execute('INSERT INTO tasks (project_id,name,description,status,priority,estimated_hours,is_billable,created_by) VALUES (:project_id,:name,:description,:status,:priority,:estimated_hours,:is_billable,:created_by)',$data);return 'created';
    }

    private function taskAssignee(array $r): string
    {
        foreach(['project_code','task_name','user_email'] as $k)$this->required($r,$k);$pid=$this->lookupProject($r['project_code']);$uid=$this->lookupUser($r['user_email']);$task=Database::fetchOne('SELECT id FROM tasks WHERE project_id=:p AND name=:n',['p'=>$pid,'n'=>$r['task_name']]);if(!$task||!$uid)throw new RuntimeException('Task or user not found');
        $ex=Database::fetchOne('SELECT 1 FROM task_assignees WHERE task_id=:t AND user_id=:u',['t'=>(int)$task['id'],'u'=>$uid]);if($ex)return 'skipped';Database::execute('INSERT INTO task_assignees (task_id,user_id) VALUES (:t,:u)',['t'=>(int)$task['id'],'u'=>$uid]);return 'created';
    }

    private function timeEntry(array $r): string
    {
        foreach(['user_email','project_code','start_time','end_time'] as $k)$this->required($r,$k);$uid=$this->lookupUser($r['user_email']);$pid=$this->lookupProject($r['project_code']);if(!$uid||!$pid)throw new RuntimeException('User or project not found');$taskId=null;if(($r['task_name']??'')!==''){ $t=Database::fetchOne('SELECT id FROM tasks WHERE project_id=:p AND name=:n',['p'=>$pid,'n'=>$r['task_name']]);$taskId=$t?(int)$t['id']:null; }
        $start=$this->datetime($r['start_time']);$end=$this->datetime($r['end_time']);if(strtotime($end)<=strtotime($start))throw new RuntimeException('End must be after start');$dur=max(1,strtotime($end)-strtotime($start)-((int)($r['break_minutes']??0)*60));$bill=$this->bool($r['is_billable']??'1');$rate=$this->num($r['billable_rate']??'0');if($rate<=0){$rate=(float)(Database::fetchValue('SELECT hourly_rate FROM projects WHERE id=:id',['id'=>$pid])??0);}
        $ex=Database::fetchOne('SELECT id FROM time_entries WHERE user_id=:u AND started_at=:s AND ended_at=:e LIMIT 1',['u'=>$uid,'s'=>$start,'e'=>$end]);$data=['user_id'=>$uid,'project_id'=>$pid,'task_id'=>$taskId,'started_at'=>$start,'ended_at'=>$end,'duration_seconds'=>$dur,'break_minutes'=>(int)($r['break_minutes']??0),'description'=>$r['description']??null,'is_billable'=>$bill,'billable_rate'=>$rate,'status'=>in_array($r['status']??'Pending',TimeEntry::STATUSES,true)?$r['status']:'Pending','auto_stopped'=>$this->bool($r['auto_stopped']??'0')];
        if($ex){Database::execute('UPDATE time_entries SET project_id=:project_id,task_id=:task_id,started_at=:started_at,ended_at=:ended_at,duration_seconds=:duration_seconds,break_minutes=:break_minutes,description=:description,is_billable=:is_billable,billable_rate=:billable_rate,status=:status,auto_stopped=:auto_stopped,updated_at=UTC_TIMESTAMP() WHERE id=:id',$data+['id'=>(int)$ex['id']]);return 'updated';}
        Database::execute('INSERT INTO time_entries (user_id,project_id,task_id,started_at,ended_at,duration_seconds,break_minutes,description,is_billable,billable_rate,status,auto_stopped) VALUES (:user_id,:project_id,:task_id,:started_at,:ended_at,:duration_seconds,:break_minutes,:description,:is_billable,:billable_rate,:status,:auto_stopped)',$data);return 'created';
    }

    private function schedule(array $r): string
    {
        foreach(['user_email','start_datetime','end_datetime'] as $k)$this->required($r,$k);$uid=$this->lookupUser($r['user_email']);if(!$uid)throw new RuntimeException('User not found');$pid=$this->lookupProject($r['project_code']??'');$start=$this->datetime($r['start_datetime']);$end=$this->datetime($r['end_datetime']);if(strtotime($end)<=strtotime($start))throw new RuntimeException('End must be after start');$data=['user_id'=>$uid,'project_id'=>$pid,'task_id'=>null,'start_datetime'=>$start,'end_datetime'=>$end,'status'=>in_array($r['status']??'Scheduled',['Scheduled','In Progress','Completed','Missed','Cancelled','Rescheduled'],true)?$r['status']:'Scheduled','notes'=>$r['notes']??null,'created_by'=>(int)AuthHelper::id()]; if(!$pid) throw new RuntimeException('Project not found');
        Database::execute('INSERT INTO schedules (user_id,project_id,task_id,start_datetime,end_datetime,status,notes,created_by) VALUES (:user_id,:project_id,:task_id,:start_datetime,:end_datetime,:status,:notes,:created_by)',$data);return 'created';
    }

    private function lookupUser(string $email): int { if($email==='')return 0; return (int)(Database::fetchValue('SELECT id FROM users WHERE email=:e',['e'=>strtolower($email)])??0); }
    private function lookupClient(string $email,string $name): ?int { if($email!==''){ $v=Database::fetchValue('SELECT id FROM clients WHERE email=:e',['e'=>strtolower($email)]);if($v)return (int)$v;}if($name!==''){ $v=Database::fetchValue('SELECT id FROM clients WHERE name=:n',['n'=>$name]);if($v)return (int)$v;}return null; }
    private function lookupProject(string $code): int { return $code===''?0:(int)(Database::fetchValue('SELECT id FROM projects WHERE project_code=:c',['c'=>$code])??0); }
    private function required(array $r,string $k): void { if(trim((string)($r[$k]??''))==='')throw new RuntimeException('Missing '.$k); }
    private function num(string $v): float { return max(0,(float)str_replace(',','',trim($v))); }
    private function bool(string $v): int { return in_array(strtolower(trim($v)),['1','true','yes','y'],true)?1:0; }
    private function datetime(string $v): string { $ts=strtotime(trim($v));if($ts===false)throw new RuntimeException('Invalid date/time: '.$v);return gmdate('Y-m-d H:i:s',$ts); }
}
