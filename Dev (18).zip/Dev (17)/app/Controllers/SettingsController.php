<?php
/**
 * Global/system settings: identity, formats, billing defaults, timezone, timer cap.
 * Workspace identity and workspace policies are managed separately under /workspace.
 *
 * Settings live in the key/value `settings` table. Only SYSTEM_DEFAULTS keys can be
 * written from this screen, so a crafted POST cannot create arbitrary configuration rows.
 */

declare(strict_types=1);

final class SettingsController extends Controller
{
    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN]);
    }

    /** GET /settings */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $this->render('settings/index', [
            'pageTitle' => 'System settings',
            'settings'  => SettingsService::system(),
            'timezones' => DateTimeZone::listIdentifiers(),
            'currencies' => SettingsService::CURRENCIES,
            'dateFormats' => SettingsService::DATE_FORMATS,
            'timeFormats' => SettingsService::TIME_FORMATS,
        ]);
    }

    /** GET /settings/audit-logs : searchable, filterable audit trail. */
    public function auditLogs(Request $request, array $params): void
    {
        PermissionHelper::require('activity.view');

        $filters = [
            'q'       => trim((string) $request->input('q', '')),
            'module'  => (string) $request->input('module', 'all'),
            'action'  => trim((string) $request->input('action', '')),
            'user_id' => (int) $request->input('user_id', 0),
        ];

        $model = new ActivityLog();
        $result = $model->search($filters, (int) $request->input('page', 1), 25);

        $this->render('settings/audit_logs', [
            'pageTitle' => 'Activity log',
            'result'    => $result,
            'filters'   => $filters,
            'modules'   => $model->modules(),
        ]);
    }

    /** POST /settings */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $data = $this->validate([
            'app_name'            => 'required|string|max:80',
            'company_email'       => 'required|email|max:190',
            'date_format'         => 'required|string|max:20',
            'time_format'         => 'required|in:' . implode(',', SettingsService::TIME_FORMATS),
            'currency_symbol'     => 'required|string|max:6',
            'currency'            => 'required|in:' . implode(',', SettingsService::CURRENCIES),
            'default_hourly_rate' => 'required|numeric|min:0|max:100000',
            'default_timezone'    => 'required|timezone',
            'timer_max_hours'     => 'required|numeric|min:1|max:24',
            'timer_reminder_minutes' => 'required|numeric|min:0|max:240',
        ], '/settings', [
            'app_name'            => 'Application name',
            'company_email'       => 'Company email',
            'date_format'         => 'Date format',
            'time_format'         => 'Time format',
            'currency_symbol'     => 'Currency symbol',
            'currency'            => 'Currency code',
            'default_hourly_rate' => 'Default hourly rate',
            'default_timezone'    => 'Timezone',
            'timer_max_hours'     => 'Timer maximum hours',
            'timer_reminder_minutes' => 'Still-working reminder',
        ]);

        if (!in_array((string) $data['date_format'], SettingsService::DATE_FORMATS, true)) {
            $this->backWithErrors('/settings', ['date_format' => 'Date format is invalid.']);
        }

        $before = SettingsService::system();
        $after  = [];

        Database::transaction(function () use ($data, $request, &$after): void {
            $writes = [
                'app_name' => trim((string) $data['app_name']),
                'company_email' => strtolower(trim((string) $data['company_email'])),
                'date_format' => (string) $data['date_format'],
                'time_format' => (string) $data['time_format'],
                'currency_symbol' => (string) $data['currency_symbol'],
                'currency' => (string) $data['currency'],
                'default_hourly_rate' => (string) $data['default_hourly_rate'],
                'default_timezone' => (string) $data['default_timezone'],
                'timer_max_hours' => (string) max(1, min(24, (int) $data['timer_max_hours'])),
                'timer_reminder_minutes' => (string) max(0, min(240, (int) $data['timer_reminder_minutes'])),
                'allow_manual_time_entries' => $request->input('allow_manual_time_entries') ? '1' : '0',
                'notifications_enabled' => $request->input('notifications_enabled') ? '1' : '0',
                'maintenance_mode' => $request->input('maintenance_mode') ? '1' : '0',
            ];
            foreach ($writes as $key => $value) {
                SettingsService::setSystem($key, $value);
                $after[$key] = $value;
            }
        });

        LoggerHelper::logEvent('settings.updated', LoggerHelper::MODULE_SETTINGS, null, $before, $after);

        $this->flash('success', 'System settings were saved.');
        $this->redirect('/settings');
    }
}
