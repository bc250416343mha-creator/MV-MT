<?php
/**
 * Assignment of users to a project. UNIQUE(project_id, user_id).
 */

declare(strict_types=1);

final class ProjectMember extends Model
{
    public const ROLE_MANAGER = 'manager';
    public const ROLE_MEMBER  = 'member';
    public const ROLE_VIEWER  = 'viewer';

    public const ROLES = [self::ROLE_MANAGER, self::ROLE_MEMBER, self::ROLE_VIEWER];

    protected string $table = 'project_members';

    protected array $columns = [
        'id', 'project_id', 'user_id', 'project_role', 'created_at',
    ];

    protected array $fillable = [
        'project_id', 'user_id', 'project_role',
    ];

    protected bool $timestamps = false;

    /** @return list<array<string, mixed>> */
    public function forProject(int $projectId): array
    {
        return Database::fetchAll(
            "SELECT pm.id, pm.project_id, pm.user_id, pm.project_role, pm.created_at,
                    u.name, u.email, r.name AS role, u.job_title, u.status
             FROM project_members pm
             INNER JOIN users u ON u.id = pm.user_id
             INNER JOIN roles r ON r.id = u.role_id
             WHERE pm.project_id = :project_id
             ORDER BY FIELD(pm.project_role, 'manager', 'member', 'viewer'), u.name ASC",
            ['project_id' => $projectId]
        );
    }

    /** @return list<int> */
    public function userIdsForProject(int $projectId): array
    {
        $rows = Database::fetchAll(
            'SELECT user_id FROM project_members WHERE project_id = :project_id',
            ['project_id' => $projectId]
        );

        return array_map(static fn (array $row): int => (int) $row['user_id'], $rows);
    }

    public function isMember(int $projectId, int $userId): bool
    {
        return (int) Database::fetchValue(
            'SELECT COUNT(*) FROM project_members WHERE project_id = :project_id AND user_id = :user_id',
            ['project_id' => $projectId, 'user_id' => $userId]
        ) > 0;
    }

    public function assign(int $projectId, int $userId, string $role = self::ROLE_MEMBER): int
    {
        $role = strtolower($role);
        if (!in_array($role, self::ROLES, true)) {
            $role = self::ROLE_MEMBER;
        }

        $existing = Database::fetchOne(
            'SELECT id, project_role FROM project_members WHERE project_id = :project_id AND user_id = :user_id LIMIT 1',
            ['project_id' => $projectId, 'user_id' => $userId]
        );

        if ($existing !== null) {
            if ((string) $existing['project_role'] !== $role) {
                Database::execute(
                    'UPDATE project_members SET project_role = :role WHERE id = :id',
                    ['role' => $role, 'id' => (int) $existing['id']]
                );
            }

            return (int) $existing['id'];
        }

        Database::execute(
            'INSERT INTO project_members (project_id, user_id, project_role, created_at)
             VALUES (:project_id, :user_id, :project_role, UTC_TIMESTAMP())',
            [
                'project_id'   => $projectId,
                'user_id'      => $userId,
                'project_role' => $role,
            ]
        );

        return Database::lastInsertId();
    }

    public function setRole(int $projectId, int $userId, string $role): void
    {
        $role = strtolower($role);
        if (!in_array($role, self::ROLES, true)) {
            return;
        }

        Database::execute(
            'UPDATE project_members SET project_role = :role WHERE project_id = :project_id AND user_id = :user_id',
            ['role' => $role, 'project_id' => $projectId, 'user_id' => $userId]
        );
    }

    public function remove(int $projectId, int $userId): bool
    {
        return Database::execute(
            'DELETE FROM project_members WHERE project_id = :project_id AND user_id = :user_id',
            ['project_id' => $projectId, 'user_id' => $userId]
        ) > 0;
    }

    /**
     * Replace the member set. $roles is user_id => project_role (optional).
     *
     * @param list<int>              $userIds
     * @param array<int, string>     $roles
     */
    public function sync(int $projectId, array $userIds, array $roles = []): void
    {
        $userIds = array_values(array_unique(array_filter(
            $userIds,
            static fn (int $id): bool => $id > 0
        )));

        Database::transaction(function () use ($projectId, $userIds, $roles): void {
            $current = $this->userIdsForProject($projectId);

            foreach (array_diff($userIds, $current) as $userId) {
                $role = $roles[$userId] ?? self::ROLE_MEMBER;
                $this->assign($projectId, (int) $userId, $role);
            }

            foreach (array_diff($current, $userIds) as $userId) {
                $this->remove($projectId, (int) $userId);
            }

            foreach ($userIds as $userId) {
                $role = isset($roles[$userId]) ? strtolower((string) $roles[$userId]) : '';
                if (in_array($role, self::ROLES, true)) {
                    Database::execute(
                        'UPDATE project_members SET project_role = :role
                         WHERE project_id = :project_id AND user_id = :user_id',
                        [
                            'role'       => $role,
                            'project_id' => $projectId,
                            'user_id'    => $userId,
                        ]
                    );
                }
            }
        });
    }
}
