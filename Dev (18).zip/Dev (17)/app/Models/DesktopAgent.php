<?php
/**
 * Windows TimeTrack agent pairing, device tokens and heartbeats.
 * The agent reports only activity timestamps; it never sends keystrokes,
 * screenshots, window titles or application contents.
 */

declare(strict_types=1);

final class DesktopAgent extends Model
{
    protected string $table = 'desktop_agent_devices';
    protected array $columns = [
        'id','workspace_id','user_id','device_id','device_name','token_hash',
        'last_seen_at','last_activity_at','is_locked','agent_version','status','created_at','updated_at',
    ];
    protected array $fillable = [];
    protected bool $timestamps = false;

    public static function installed(): bool
    {
        static $installed = null;
        if ($installed !== null) return $installed;
        try {
            Database::fetchValue('SELECT 1 FROM desktop_agent_devices LIMIT 1');
            $installed = true;
        } catch (Throwable) {
            $installed = false;
        }
        return $installed;
    }

    /** @return array{code:string,expires_at:string} */
    public static function createPairingCode(int $userId): array
    {
        $workspaceId = Workspace::currentId();
        if ($workspaceId < 1) throw new RuntimeException('Workspace is not initialized.');

        $code = str_pad((string) random_int(0, 99999999), 8, '0', STR_PAD_LEFT);
        $expires = gmdate('Y-m-d H:i:s', time() + 600);

        Database::execute(
            'DELETE FROM desktop_agent_pairing_codes WHERE user_id = :user_id AND used_at IS NULL',
            ['user_id' => $userId]
        );
        Database::execute(
            'INSERT INTO desktop_agent_pairing_codes (workspace_id,user_id,code_hash,expires_at,created_at)
             VALUES (:workspace_id,:user_id,:code_hash,:expires_at,UTC_TIMESTAMP())',
            [
                'workspace_id' => $workspaceId,
                'user_id' => $userId,
                'code_hash' => hash('sha256', $code),
                'expires_at' => $expires,
            ]
        );
        return ['code' => $code, 'expires_at' => $expires];
    }

    /** @return array{user_id:int,workspace_id:int,token:string,device_id:string}|null */
    public static function pair(string $code, string $deviceId, string $deviceName, string $agentVersion): ?array
    {
        $code = trim($code);
        if (!preg_match('/^\d{8}$/', $code) || $deviceId === '') return null;

        $rows = Database::fetchAll(
            'SELECT id, workspace_id, user_id, code_hash, attempts
             FROM desktop_agent_pairing_codes
             WHERE expires_at > UTC_TIMESTAMP() AND used_at IS NULL AND attempts < 10
             ORDER BY id DESC LIMIT 20'
        );
        $match = null;
        $hash = hash('sha256', $code);
        foreach ($rows as $row) {
            if (hash_equals((string) $row['code_hash'], $hash)) { $match = $row; break; }
        }
        if ($match === null) {
            // Count failed attempts for the most recent active code(s) so the 8-digit
            // pairing code cannot be brute-forced indefinitely.
            foreach ($rows as $row) {
                Database::execute('UPDATE desktop_agent_pairing_codes SET attempts = attempts + 1 WHERE id = :id AND used_at IS NULL', ['id' => (int) $row['id']]);
            }
            return null;
        }

        $token = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
        $tokenHash = hash('sha256', $token);
        $now = gmdate('Y-m-d H:i:s');
        $deviceId = substr($deviceId, 0, 120);
        $deviceName = substr($deviceName !== '' ? $deviceName : 'Windows PC', 0, 160);
        $agentVersion = substr($agentVersion !== '' ? $agentVersion : 'unknown', 0, 40);

        Database::transaction(function () use ($match, $deviceId, $deviceName, $agentVersion, $tokenHash, $now): void {
            Database::execute(
                'DELETE FROM desktop_agent_devices WHERE user_id = :user_id AND device_id = :device_id',
                ['user_id' => (int) $match['user_id'], 'device_id' => $deviceId]
            );
            Database::execute(
                'INSERT INTO desktop_agent_devices
                 (workspace_id,user_id,device_id,device_name,token_hash,last_seen_at,last_activity_at,is_locked,agent_version,status,created_at,updated_at)
                 VALUES (:workspace_id,:user_id,:device_id,:device_name,:token_hash,:now1,:now2,0,:agent_version,\'active\',:now3,:now4)',
                [
                    'workspace_id' => (int) $match['workspace_id'],
                    'user_id' => (int) $match['user_id'],
                    'device_id' => $deviceId,
                    'device_name' => $deviceName,
                    'token_hash' => $tokenHash,
                    'now1' => $now,
                    'now2' => $now,
                    'now3' => $now,
                    'now4' => $now,
                    'agent_version' => $agentVersion,
                ]
            );
            Database::execute(
                'UPDATE desktop_agent_pairing_codes SET used_at = :now WHERE id = :id',
                ['now' => $now, 'id' => (int) $match['id']]
            );
        });

        return [
            'user_id' => (int) $match['user_id'],
            'workspace_id' => (int) $match['workspace_id'],
            'token' => $token,
            'device_id' => $deviceId,
        ];
    }

    /** @return array<string,mixed>|null */
    public static function authenticateToken(string $token): ?array
    {
        $token = trim($token);
        if ($token === '') return null;
        return Database::fetchOne(
            "SELECT * FROM desktop_agent_devices WHERE token_hash = :token_hash AND status = 'active' LIMIT 1",
            ['token_hash' => hash('sha256', $token)]
        );
    }

    /** @param array<string,mixed> $body */
    public static function heartbeat(array $device, array $body): void
    {
        $now = time();
        $activityTs = (int) ($body['last_activity_unix'] ?? 0);
        if ($activityTs < 1 || $activityTs > $now + 120) $activityTs = $now;
        $activityTs = min($activityTs, $now);
        $locked = !empty($body['locked']) ? 1 : 0;
        $version = substr((string) ($body['agent_version'] ?? $device['agent_version'] ?? 'unknown'), 0, 40);

        Database::execute(
            'UPDATE desktop_agent_devices
             SET last_seen_at = UTC_TIMESTAMP(), last_activity_at = :activity_at,
                 is_locked = :locked, agent_version = :version, updated_at = UTC_TIMESTAMP()
             WHERE id = :id AND status = \'active\'',
            [
                'activity_at' => gmdate('Y-m-d H:i:s', $activityTs),
                'locked' => $locked,
                'version' => $version,
                'id' => (int) $device['id'],
            ]
        );
    }

    /** @return list<array<string,mixed>> */
    public static function forUser(int $userId): array
    {
        if (!self::installed()) return [];
        return Database::fetchAll(
            'SELECT id,device_id,device_name,last_seen_at,last_activity_at,is_locked,agent_version,status,created_at
             FROM desktop_agent_devices WHERE user_id = :user_id ORDER BY device_name ASC',
            ['user_id' => $userId]
        );
    }

    public static function revoke(int $userId, int $deviceId): bool
    {
        return Database::execute(
            "UPDATE desktop_agent_devices SET status='revoked', updated_at=UTC_TIMESTAMP() WHERE id=:id AND user_id=:user_id",
            ['id' => $deviceId, 'user_id' => $userId]
        ) > 0;
    }

    /** @return list<array<string,mixed>> Active people an admin can pair a computer for. */
    public static function pairableUsers(): array
    {
        return Database::fetchAll(
            "SELECT u.id, u.name, u.email, r.name AS role
             FROM users u INNER JOIN roles r ON r.id = u.role_id
             WHERE u.status = 'active' AND r.name <> 'client'
             ORDER BY u.name ASC"
        );
    }

    /** @return list<array<string,mixed>> Every paired computer, with its owner (admin view). */
    public static function allWithUsers(): array
    {
        if (!self::installed()) return [];
        return Database::fetchAll(
            "SELECT d.id, d.device_id, d.device_name, d.last_seen_at, d.last_activity_at, d.is_locked,
                    d.agent_version, d.status, d.created_at, u.name AS user_name
             FROM desktop_agent_devices d INNER JOIN users u ON u.id = d.user_id
             WHERE d.status = 'active'
             ORDER BY u.name ASC, d.device_name ASC"
        );
    }

    public static function revokeAny(int $deviceId): bool
    {
        return Database::execute(
            "UPDATE desktop_agent_devices SET status='revoked', updated_at=UTC_TIMESTAMP() WHERE id=:id",
            ['id' => $deviceId]
        ) > 0;
    }
}
