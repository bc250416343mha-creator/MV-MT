<?php
declare(strict_types=1);
$tab=(string)$tab;
$settings=$settings ?? [];
$enabled=static fn(string $k):bool=>($settings[$k]??'0')==='1';
$sel=static fn(string $k,string $v):string=>(($settings[$k]??'')===$v?'selected':'');
?>
<div class="page-head d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">
  <div><h2 class="page-heading mb-1">Workspace settings</h2><p class="text-muted mb-0">One place for workspace identity, permissions and workspace-wide rules.</p></div>
</div>
<div class="workspace-settings-shell">
  <aside class="workspace-settings-sidebar">
    <div class="workspace-brand-card">
      <?php if(!empty($workspace['logo_path'])): ?><img src="<?=e(url((string)$workspace['logo_path']))?>" class="workspace-logo" alt="Workspace logo"><?php else: ?><div class="workspace-logo workspace-logo-placeholder"><i class="fa-solid fa-building"></i></div><?php endif; ?>
      <strong><?=e((string)$workspace['name'])?></strong><span>Workspace</span>
    </div>
    <nav class="workspace-settings-nav">
      <a class="<?=$tab==='general'?'active':''?>" href="<?=e(url('/workspace?tab=general'))?>"><i class="fa-solid fa-sliders"></i> General</a>
      <a class="<?=$tab==='permissions'?'active':''?>" href="<?=e(url('/workspace?tab=permissions'))?>"><i class="fa-solid fa-shield-halved"></i> Permissions</a>
      <a class="<?=$tab==='features'?'active':''?>" href="<?=e(url('/workspace?tab=features'))?>"><i class="fa-solid fa-toggle-on"></i> Features &amp; policies</a>
    </nav>
  </aside>
  <section class="workspace-settings-content">
  <?php if($tab==='general'): ?>
    <div class="settings-card"><div class="settings-card-head"><h3>General</h3><p>Workspace name and company logo.</p></div>
      <form method="post" action="<?=e(url('/workspace/general'))?>" enctype="multipart/form-data" class="settings-form" data-workspace-general-form><?=csrf_field()?><div class="row g-4">
        <div class="col-md-7"><label class="form-label">Workspace name</label><input class="form-control" name="name" maxlength="160" required value="<?=e((string)$workspace['name'])?>"><div class="form-text">Used throughout the application and shared reports.</div></div>
        <div class="col-md-5"><label class="form-label">Company logo</label><input class="form-control" type="file" name="logo" accept="image/png,image/jpeg"><div class="form-text">PNG or JPG, maximum 5 MB.</div></div>
      </div><div class="settings-card-foot"><button class="btn btn-primary">Save workspace</button></div></form>
    </div>
  <?php elseif($tab==='permissions'): ?>
    <div class="settings-card"><div class="settings-card-head"><h3>Permissions</h3><p>Manage the existing application permissions by workspace role.</p></div>
      <form method="post" action="<?=e(url('/workspace/permissions'))?>" data-single-submit><?=csrf_field()?><div class="table-responsive workspace-permissions-table"><table class="table align-middle mb-0"><thead><tr><th>Permission</th><?php foreach($roles as $r):?><th class="text-center"><?=e((string)$r['display_name'])?></th><?php endforeach;?></tr></thead><tbody>
      <?php $module=''; foreach($permissions as $p): if($module!==(string)$p['module']):$module=(string)$p['module'];?><tr class="permission-module"><td colspan="<?=1+count($roles)?>"><?=e(ucfirst($module))?></td></tr><?php endif;?><tr><td><strong><?=e((string)$p['display_name'])?></strong><small><?=e((string)($p['description']??''))?></small></td><?php foreach($roles as $r):$rid=(int)$r['id'];$pid=(int)$p['id'];?><td class="text-center"><input class="form-check-input" type="checkbox" name="permissions[<?=$rid?>][]" value="<?=$pid?>" <?=!empty($rolePermissionMap[$rid][$pid])?'checked':''?>></td><?php endforeach;?></tr><?php endforeach;?></tbody></table></div><div class="settings-card-foot"><button class="btn btn-primary">Save permissions</button></div></form>
    </div>
  <?php else: ?>
    <div class="settings-card"><div class="settings-card-head"><h3>Features &amp; policies</h3><p>Workspace-wide tracking rules and policies. These values are authoritative for this workspace.</p></div>
      <form method="post" action="<?=e(url('/workspace/features'))?>" class="settings-form" data-single-submit><?=csrf_field()?>
      <div class="settings-section"><h4>Time tracking</h4><div class="row g-3"><?php foreach([['timesheet_enabled','Activate timesheet'],['hide_tracker','Hide tracker'],['time_approval_enabled','Enable time approval'],['lock_time_enabled','Lock time'],['force_timer','Force timer']] as [$k,$l]):?><div class="col-md-6"><label class="form-check form-switch"><input class="form-check-input" type="checkbox" name="<?=$k?>" value="1" <?=$enabled($k)?'checked':''?>><span class="form-check-label"><?=e($l)?></span></label></div><?php endforeach;?></div></div>
      <div class="settings-section"><h4>Defaults</h4><div class="row g-3">
        <div class="col-md-4"><label class="form-label">New Projects are by default</label><select class="form-select" name="default_project_visibility"><option value="public" <?=$sel('default_project_visibility','public')?>>Public</option><option value="private" <?=$sel('default_project_visibility','private')?>>Private</option></select></div>
        <div class="col-md-4"><label class="form-label">Week start</label><select class="form-select" name="week_start"><option value="monday" <?=$sel('week_start','monday')?>>Monday</option><option value="sunday" <?=$sel('week_start','sunday')?>>Sunday</option></select></div>
        <div class="col-md-4"><label class="form-label">Daily work capacity (workspace)</label><input class="form-control" type="number" min="1" max="24" step=".25" name="daily_capacity" value="<?=e((string)($settings['daily_capacity']??8))?>"></div>
        <div class="col-md-4"><label class="form-label">Time rounding (minutes, workspace)</label><input class="form-control" type="number" min="1" max="60" name="time_rounding_minutes" value="<?=e((string)($settings['time_rounding_minutes']??1))?>"></div>
      </div></div>
      <div class="settings-section"><h4>Workspace policies</h4><div class="row g-3"><?php $selects=[['project_creation_policy','Who can create Projects',['admins'=>'Admins','admins_project_managers'=>'Admins and Project managers','anyone'=>'Anyone']],['task_creation_policy','Who can create Tasks',['admins'=>'Admins','admins_project_managers'=>'Admins and Project managers','anyone'=>'Anyone']],['regular_user_time_visibility','Regular users can see',['all'=>'All tracked time','public'=>'Only time on public Projects','own'=>'Only their own']],['edit_time_others_policy','Who can edit time for others',['admins'=>'Admins','admins_team_managers'=>'Admins and team managers']],['approval_period','Approval period',['weekly'=>'Weekly','semi-monthly'=>'Semi-monthly','monthly'=>'Monthly']]];foreach($selects as [$k,$l,$opts]):?><div class="col-md-6"><label class="form-label"><?=e($l)?></label><select class="form-select" name="<?=$k?>"><?php foreach($opts as $v=>$label):?><option value="<?=$v?>" <?=$sel($k,$v)?>><?=e($label)?></option><?php endforeach;?></select></div><?php endforeach;?></div></div>
      <div class="settings-section"><h4>Computer activity / idle detection</h4><p class="small text-secondary">When enabled, the Windows TimeTrack Agent detects only whether the computer is being used. It does not record keystrokes or screenshots. A running timer shows an idle warning after the selected period; no response automatically pauses the timer.</p><div class="row g-3"><div class="col-md-6"><label class="form-check form-switch"><input class="form-check-input" type="checkbox" name="idle_detection_enabled" value="1" <?=$enabled('idle_detection_enabled')?'checked':''?>><span class="form-check-label">Enable computer activity / idle detection</span></label></div><div class="col-md-3"><label class="form-label">Idle after (minutes)</label><input class="form-control" type="number" min="1" max="1440" name="idle_threshold_minutes" value="<?=e((string)($settings['idle_threshold_minutes']??10))?>"></div><div class="col-md-3"><label class="form-label">No response → pause (seconds)</label><input class="form-control" type="number" min="10" max="3600" name="idle_warning_seconds" value="<?=e((string)($settings['idle_warning_seconds']??60))?>"></div></div></div>
      <div class="settings-section"><h4>Modules &amp; visibility</h4><div class="row g-3"><?php foreach([['scheduling_enabled','Activate Project and team scheduling'],['hide_projects','Hide Projects from regular users'],['hide_team','Hide Team from regular users'],['hide_reports','Hide Reports from regular users']] as [$k,$l]):?><div class="col-md-6"><label class="form-check form-switch"><input class="form-check-input" type="checkbox" name="<?=$k?>" value="1" <?=$enabled($k)?'checked':''?>><span class="form-check-label"><?=e($l)?></span></label></div><?php endforeach;?></div></div>
      <div class="settings-card-foot"><button class="btn btn-primary">Save workspace policies</button></div></form>
    </div>
  <?php endif; ?>
  </section>
</div>