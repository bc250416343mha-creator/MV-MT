<?php
declare(strict_types=1);

/** Employee dashboard styled consistently with the admin dashboard. */
$me = AuthHelper::user() ?? ['name' => '', 'role' => ''];
$entries = $today['entries'] ?? [];
$schedule = $today['schedule'] ?? [];
$tasks = $today['active_tasks'] ?? [];
$statusClass = static fn (string $status): string => match ($status) {
    'Approved', 'Completed', 'Done' => 'completed',
    'Rejected', 'Missed', 'Cancelled' => 'cancelled',
    'In Progress' => 'active',
    default => 'planning',
};
?>
<div class="clock-dash-head">
    <div>
        <h2 class="clock-dash-title">Dashboard</h2>
        <p class="clock-dash-subtitle"><?= e(FormatHelper::datetime(gmdate('Y-m-d H:i:s'), 'l, F j, Y')) ?></p>
    </div>
    <div class="clock-dash-controls">
        <span class="clock-filter"><i class="fa-regular fa-calendar" aria-hidden="true"></i> Today</span>
        <?php if (!empty($canTrack) && FeatureFlagsHelper::trackerVisible()): ?><a class="btn btn-primary" href="<?= e(url('/time')) ?>"><i class="fa-solid fa-play me-1" aria-hidden="true"></i> Track time</a><?php endif; ?>
    </div>
</div>

<div class="clock-summary-grid">
    <?php $capHours = (float) ($capacityHours ?? WorkspacePolicy::dailyCapacityHours()); $remainH = max(0, $capHours - (float) $today['tracked_hours']); ?>
    <article class="clock-summary-card"><span class="clock-summary-label">Total time today</span><strong><?= e(FormatHelper::duration((int) $today['tracked_seconds'])) ?></strong><small><?= e(AnalyticsHelper::formatHours((float) $today['tracked_hours'])) ?> of <?= e(AnalyticsHelper::formatHours($capHours)) ?>h capacity (<?= e(AnalyticsHelper::formatHours($remainH)) ?>h remaining)</small></article>
    <article class="clock-summary-card"><span class="clock-summary-label">Scheduled time</span><strong><?= e(AnalyticsHelper::formatHours((float) $today['scheduled_hours'])) ?>h</strong><small>From today's schedule</small></article>
    <article class="clock-summary-card"><span class="clock-summary-label">Variance</span><strong><?= e((string) $today['variance_formatted']) ?></strong><small>Tracked minus scheduled</small></article>
    <article class="clock-summary-card"><span class="clock-summary-label">Active tasks</span><strong><?= (int) $today['active_task_count'] ?></strong><small>Open and in progress</small></article>
</div>

<div class="clock-dashboard-split">
    <section class="clock-dashboard-card">
        <div class="clock-card-head"><div><h3>Today's schedule</h3><span>Your planned work</span></div><?php if (FeatureFlagsHelper::schedulingEnabled()): ?><a class="clock-card-link" href="<?= e(url('/schedule/my')) ?>">Full schedule <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a><?php endif; ?></div>
        <?php if ($schedule === []): ?><div class="clock-empty">Nothing planned for today.</div><?php else: ?>
            <div class="clock-schedule-list">
            <?php foreach ($schedule as $block): ?>
                <div class="clock-schedule-row">
                    <span class="clock-schedule-time"><?= e(FormatHelper::datetime((string) $block['start_datetime'], 'H:i')) ?>–<?= e(FormatHelper::datetime((string) $block['end_datetime'], 'H:i')) ?></span>
                    <div><strong><?= e($block['project_name']) ?></strong><?php if (!empty($block['task_name'])): ?><small><?= e($block['task_name']) ?></small><?php endif; ?></div>
                    <span class="status-badge status-<?= e($statusClass((string) $block['status'])) ?>"><?= e($block['status']) ?></span>
                    <?php if (!empty($canTrack) && !in_array($block['status'], ['Cancelled','Completed'], true)): ?><button type="button" class="btn btn-sm btn-primary" data-timer-start data-project-id="<?= (int) $block['project_id'] ?>" <?= !empty($block['task_id']) ? 'data-task-id="' . (int) $block['task_id'] . '"' : '' ?> data-description="<?= e((string) ($block['notes'] ?? '')) ?>">Start</button><?php endif; ?>
                </div>
            <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <section class="clock-dashboard-card">
        <div class="clock-card-head"><div><h3>Active tasks</h3><span>Tasks assigned to you</span></div></div>
        <?php if ($tasks === []): ?><div class="clock-empty">No open tasks assigned to you.</div><?php else: ?>
            <div class="clock-team-list">
            <?php foreach ($tasks as $task): ?><div class="clock-team-row"><span class="clock-avatar"><?= e(mb_strtoupper(mb_substr((string) $task['name'], 0, 1, 'UTF-8'), 'UTF-8')) ?></span><div class="clock-team-info"><a href="<?= e(url('/projects/' . (int) $task['project_id'])) ?>"><strong><?= e($task['name']) ?></strong></a><span><?= e($task['project_name']) ?></span></div><?php if (!empty($canTrack)): ?><button type="button" class="btn btn-sm btn-outline-primary" data-timer-start data-project-id="<?= (int) $task['project_id'] ?>" data-task-id="<?= (int) $task['id'] ?>">Start</button><?php endif; ?></div><?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</div>

<section class="clock-dashboard-card" id="recent-entries">
        <div class="clock-card-head"><div><h3>Recent time entries</h3><span>Start and end times are shown in Pakistan time (PKT)</span></div><?php if (FeatureFlagsHelper::trackerVisible()): ?><a class="clock-card-link" href="<?= e(url('/time')) ?>">All time <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a><?php endif; ?></div>
    <?php if ($entries === []): ?><div class="clock-empty">No time entries yet.</div><?php else: ?>
    <div class="table-responsive"><table class="table clock-activity-table mb-0"><thead><tr><th>Start (PKT)</th><th>End (PKT)</th><th>Project</th><th>Task</th><th>Note</th><th>Duration</th><th>Status</th><th class="text-end">Actions</th></tr></thead><tbody>
    <?php foreach ($entries as $entry): ?>
        <?php $locked = (string) $entry['status'] === TimeEntry::STATUS_APPROVED || (int) ($entry['timesheet_id'] ?? 0) > 0; $own = (int) $entry['user_id'] === $userId; $canRemove = !$locked && $own && !empty($canDelete); $canChange = !$locked && $own && !empty($canEdit); ?>
        <tr>
            <td><strong><?= e(FormatHelper::datetime((string) $entry['start_time'], 'M j, Y')) ?></strong><small><?= e(FormatHelper::datetime((string) $entry['start_time'], 'H:i')) ?></small></td>
            <td><strong><?= e(FormatHelper::datetime((string) $entry['end_time'], 'M j, Y')) ?></strong><small><?= e(FormatHelper::datetime((string) $entry['end_time'], 'H:i')) ?></small></td>
            <td><a href="<?= e(url('/projects/' . (int) $entry['project_id'])) ?>"><?= e($entry['project_name']) ?></a></td>
            <td><?= e($entry['task_name'] ?? '—') ?></td>
            <td><?= e($entry['description'] ?? '—') ?></td>
            <td class="mono"><?= e(FormatHelper::duration((int) $entry['duration_seconds'])) ?></td>
            <td><span class="clock-status clock-status-<?= e(strtolower((string) $entry['status'])) ?>"><?= e((string) $entry['status']) ?></span></td>
            <td class="text-end text-nowrap">
                <?php if ($canChange): ?><button type="button" class="btn btn-sm btn-outline-secondary" data-entry-edit data-id="<?= (int) $entry['id'] ?>" data-project-id="<?= (int) $entry['project_id'] ?>" data-task-id="<?= (int) ($entry['task_id'] ?? 0) ?>" data-start="<?= e(FormatHelper::datetime((string) $entry['start_time'], 'Y-m-d\TH:i')) ?>" data-end="<?= e(FormatHelper::datetime((string) $entry['end_time'], 'Y-m-d\TH:i')) ?>" data-break="<?= (int) ($entry['break_minutes'] ?? 0) ?>" data-description="<?= e((string) ($entry['description'] ?? '')) ?>" data-billable="<?= (int) $entry['is_billable'] ?>">Edit</button><?php endif; ?>
                <?php if ($canRemove): ?><form method="post" action="<?= e(url('/time/' . (int) $entry['id'] . '/delete')) ?>" class="d-inline" data-confirm="Delete this time entry?"><?= csrf_field() ?><button type="submit" class="btn btn-sm btn-outline-danger">Delete</button></form><?php elseif ($locked): ?><span class="small text-secondary">Locked</span><?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?></tbody></table></div>
    <?php endif; ?>
</section>

<?php if (!empty($canEdit) || !empty($canManual)): ?>
<div class="modal fade" id="editEntryModal" tabindex="-1" aria-labelledby="editEntryTitle" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-centered"><form method="post" action="<?= e(url('/time/0')) ?>" id="editEntryForm" class="modal-content" novalidate data-single-submit><?= csrf_field() ?><div class="modal-header"><h2 class="modal-title h5" id="editEntryTitle">Edit time entry</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="row g-3"><div class="col-md-6"><label for="edit_project_id" class="form-label">Project</label><select id="edit_project_id" name="project_id" required class="form-select" data-timer-project-select><option value="">Choose a project</option><?php foreach ($projects as $project): ?><option value="<?= (int) $project['id'] ?>"><?= e($project['name']) ?></option><?php endforeach; ?></select></div><div class="col-md-6"><label for="edit_task_id" class="form-label">Task</label><select id="edit_task_id" name="task_id" class="form-select" data-timer-task-select><option value="">No task</option></select></div><div class="col-md-4"><label for="edit_start_time" class="form-label">Start</label><input type="datetime-local" id="edit_start_time" name="start_time" required class="form-control"></div><div class="col-md-4"><label for="edit_end_time" class="form-label">End</label><input type="datetime-local" id="edit_end_time" name="end_time" required class="form-control"></div><div class="col-md-4"><label for="edit_break_minutes" class="form-label">Break (minutes)</label><input type="number" id="edit_break_minutes" name="break_minutes" min="0" max="1440" step="1" class="form-control" value="0"></div><div class="col-12"><label for="edit_description" class="form-label">Note</label><input type="text" id="edit_description" name="description" maxlength="255" class="form-control"></div><div class="col-12"><div class="form-check"><input type="hidden" name="is_billable" value="0"><input class="form-check-input" type="checkbox" value="1" id="edit_is_billable" name="is_billable"><label class="form-check-label" for="edit_is_billable">Billable</label></div></div></div></div><div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save changes</button></div></form></div></div>
<?php endif; ?>
