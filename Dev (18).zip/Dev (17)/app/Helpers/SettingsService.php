<?php
/**
 * Single typed access layer for system and workspace settings.
 *
 * System settings are global and live only in `settings`.
 * Workspace policies live only in `workspace_settings`.
 * Values are cached for the request and invalidated after writes.
 *
 * Timezone precedence: users.timezone (display) -> settings.default_timezone
 * -> UTC. Storage is always UTC. config app.timezone is not a source of truth.
 */

declare(strict_types=1);

final class SettingsService
{
    /** @var array<string,string>|null */
    private static ?array $systemCache = null;
    /** @var array<int,array<string,string>> */
    private static array $workspaceCache = [];

    /**
     * Legacy keys removed from `settings`; they must never be written again.
     * 'time_rounding_minutes' is deliberately NOT listed: it now lives in
     * workspace_settings (see Workspace::DEFAULT_SETTINGS), and listing it here made
     * setWorkspace() throw "System keys cannot be written" on every policies save.
     */
    public const LEGACY_SYSTEM_KEYS = [
        'company_name',
        'week_start_day',
        'working_hours_per_day',
        'timesheet_approval',
    ];

    /**
     * Canonical system keys and defaults. This is the only catalog for /settings.
     *
     * @var array<string,string>
     */
    public const SYSTEM_DEFAULTS = [
        'app_name' => 'TimeTrack',
        'company_email' => 'hello@timetrack.local',
        'date_format' => 'M j, Y',
        'time_format' => 'H:i',
        'currency' => 'USD',
        'currency_symbol' => '$',
        'default_hourly_rate' => '0',
        'default_timezone' => 'UTC',
        'timer_max_hours' => '12',
        'timer_reminder_minutes' => '10',
        'allow_manual_time_entries' => '1',
        'notifications_enabled' => '1',
        'maintenance_mode' => '0',
    ];

    /**
     * @var array<string,array{type:string,group:string}>
     */
    private const SYSTEM_META = [
        'app_name' => ['type' => 'string', 'group' => 'general'],
        'company_email' => ['type' => 'string', 'group' => 'general'],
        'date_format' => ['type' => 'string', 'group' => 'general'],
        'time_format' => ['type' => 'string', 'group' => 'general'],
        'currency' => ['type' => 'string', 'group' => 'billing'],
        'currency_symbol' => ['type' => 'string', 'group' => 'billing'],
        'default_hourly_rate' => ['type' => 'string', 'group' => 'billing'],
        'default_timezone' => ['type' => 'string', 'group' => 'general'],
        'timer_max_hours' => ['type' => 'int', 'group' => 'time'],
        'timer_reminder_minutes' => ['type' => 'int', 'group' => 'time'],
        'allow_manual_time_entries' => ['type' => 'bool', 'group' => 'time'],
        'notifications_enabled' => ['type' => 'bool', 'group' => 'system'],
        'maintenance_mode' => ['type' => 'bool', 'group' => 'system'],
    ];

    public const DATE_FORMATS = ['M j, Y', 'Y-m-d', 'd/m/Y', 'm/d/Y', 'j M Y'];
    public const TIME_FORMATS = ['H:i', 'H:i:s', 'h:i A'];
    public const CURRENCIES = ['USD', 'EUR', 'GBP', 'PKR', 'INR', 'AED', 'SAR', 'AUD', 'CAD', 'JPY'];

    /** @return array<string,string> */
    public static function system(): array
    {
        if (self::$systemCache !== null) return self::$systemCache;

        $keys = array_keys(self::SYSTEM_DEFAULTS);
        $rows = Database::fetchAll(
            'SELECT setting_key, setting_value FROM settings WHERE setting_key IN (' .
            implode(', ', array_fill(0, count($keys), '?')) . ')',
            $keys
        );
        $out = self::SYSTEM_DEFAULTS;
        foreach ($rows as $row) {
            $key = (string) $row['setting_key'];
            if (array_key_exists($key, $out)) $out[$key] = (string) ($row['setting_value'] ?? '');
        }
        return self::$systemCache = $out;
    }

    public static function systemString(string $key, ?string $default = null): string
    {
        $values = self::system();
        if (array_key_exists($key, $values)) return $values[$key];
        if ($default !== null) return $default;
        throw new InvalidArgumentException('Unknown system setting: ' . $key);
    }

    public static function systemInt(string $key, ?int $default = null): int
    {
        $value = self::systemString($key, $default === null ? null : (string) $default);
        return is_numeric($value) ? (int) $value : ($default ?? 0);
    }

    public static function systemFloat(string $key, ?float $default = null): float
    {
        $value = self::systemString($key, $default === null ? null : (string) $default);
        return is_numeric($value) ? (float) $value : ($default ?? 0.0);
    }

    public static function systemBool(string $key, ?bool $default = null): bool
    {
        $value = strtolower(trim(self::systemString($key, $default === null ? null : ($default ? '1' : '0'))));
        return in_array($value, ['1','true','yes','on'], true);
    }

    public static function systemTimezone(): string
    {
        $zone = self::systemString('default_timezone', 'UTC');
        return in_array($zone, DateTimeZone::listIdentifiers(), true) ? $zone : 'UTC';
    }

    public static function appName(): string
    {
        $name = trim(self::systemString('app_name', 'TimeTrack'));
        return $name !== '' ? $name : 'TimeTrack';
    }

    public static function dateFormat(): string
    {
        $format = self::systemString('date_format', 'M j, Y');
        return in_array($format, self::DATE_FORMATS, true) ? $format : 'M j, Y';
    }

    public static function timeFormat(): string
    {
        $format = self::systemString('time_format', 'H:i');
        return in_array($format, self::TIME_FORMATS, true) ? $format : 'H:i';
    }

    public static function setSystem(string $key, string $value): void
    {
        if (in_array($key, self::LEGACY_SYSTEM_KEYS, true) || array_key_exists($key, Workspace::DEFAULT_SETTINGS)) {
            throw new InvalidArgumentException('Workspace or legacy keys cannot be written to settings.');
        }
        if (!array_key_exists($key, self::SYSTEM_DEFAULTS)) {
            throw new InvalidArgumentException('Unknown system setting.');
        }
        $meta = self::SYSTEM_META[$key];
        Database::execute(
            'INSERT INTO settings (setting_key, setting_value, setting_type, setting_group, description)
             VALUES (:key, :value, :type, :grp, NULL)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP()',
            [
                'key' => $key,
                'value' => $value,
                'type' => $meta['type'],
                'grp' => $meta['group'],
            ]
        );
        self::clearSystemCache();
    }

    /** @return array<string,string> */
    public static function workspace(int $workspaceId): array
    {
        if ($workspaceId < 1) throw new InvalidArgumentException('Invalid workspace id.');
        if (isset(self::$workspaceCache[$workspaceId])) return self::$workspaceCache[$workspaceId];

        $defaults = Workspace::DEFAULT_SETTINGS;
        $rows = Database::fetchAll(
            'SELECT setting_key, setting_value FROM workspace_settings WHERE workspace_id = :id',
            ['id' => $workspaceId]
        );
        foreach ($rows as $row) {
            $key = (string) $row['setting_key'];
            if (array_key_exists($key, $defaults)) $defaults[$key] = (string) ($row['setting_value'] ?? '');
        }
        return self::$workspaceCache[$workspaceId] = $defaults;
    }

    public static function workspaceString(int $workspaceId, string $key, ?string $default = null): string
    {
        $values = self::workspace($workspaceId);
        if (array_key_exists($key, $values)) return $values[$key];
        if ($default !== null) return $default;
        throw new InvalidArgumentException('Unknown workspace setting: ' . $key);
    }

    public static function workspaceInt(int $workspaceId, string $key, ?int $default = null): int
    {
        $value = self::workspaceString($workspaceId, $key, $default === null ? null : (string) $default);
        return is_numeric($value) ? (int) $value : ($default ?? 0);
    }

    public static function workspaceFloat(int $workspaceId, string $key, ?float $default = null): float
    {
        $value = self::workspaceString($workspaceId, $key, $default === null ? null : (string) $default);
        return is_numeric($value) ? (float) $value : ($default ?? 0.0);
    }

    public static function workspaceBool(int $workspaceId, string $key, ?bool $default = null): bool
    {
        $value = strtolower(trim(self::workspaceString($workspaceId, $key, $default === null ? null : ($default ? '1' : '0'))));
        return in_array($value, ['1','true','yes','on'], true);
    }

    public static function setWorkspace(int $workspaceId, string $key, string $value): void
    {
        if (array_key_exists($key, self::SYSTEM_DEFAULTS) || in_array($key, self::LEGACY_SYSTEM_KEYS, true)) {
            throw new InvalidArgumentException('System keys cannot be written to workspace_settings.');
        }
        if (!array_key_exists($key, Workspace::DEFAULT_SETTINGS)) {
            throw new InvalidArgumentException('Unknown workspace setting.');
        }
        Database::execute(
            'INSERT INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
             VALUES (:workspace_id, :setting_key, :setting_value, UTC_TIMESTAMP())
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP()',
            ['workspace_id' => $workspaceId, 'setting_key' => $key, 'setting_value' => $value]
        );
        self::clearWorkspaceCache($workspaceId);
    }

    public static function clearSystemCache(): void { self::$systemCache = null; }
    public static function clearWorkspaceCache(?int $workspaceId = null): void
    {
        if ($workspaceId === null) self::$workspaceCache = [];
        else unset(self::$workspaceCache[$workspaceId]);
    }
    public static function clearAllCaches(): void { self::clearSystemCache(); self::clearWorkspaceCache(); }
}