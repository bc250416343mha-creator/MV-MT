<?php
/**
 * Output helpers. Every method terminates the request, so callers never
 * need to remember a trailing exit.
 */

declare(strict_types=1);

final class Response
{
    /** Send a JSON document. Flags escape <, >, &, ' and " so the payload is safe even if inlined in HTML. */
    public static function json(array $payload, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');

        echo json_encode(
            $payload,
            JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        exit;
    }

    /**
     * Redirect to an application-internal path (e.g. "/dashboard?tab=1").
     * Absolute URLs and protocol-relative paths are rejected to prevent open-redirect abuse.
     */
    public static function redirect(string $path, int $status = 302): never
    {
        if (
            $path === ''
            || $path[0] !== '/'
            || str_starts_with($path, '//')
            || str_contains($path, '\\')
            || preg_match('/[\r\n]/', $path)
        ) {
            throw new InvalidArgumentException('Redirect target must be an internal path.');
        }

        header('Location: ' . FormatHelper::url($path), true, $status);
        exit;
    }

    /**
     * Render an error as JSON (AJAX/API callers) or as a small self-contained HTML page.
     *
     * @param array<string, string> $headers
     */
    public static function error(int $status, string $message, bool $asJson, array $headers = []): never
    {
        foreach ($headers as $name => $value) {
            header($name . ': ' . $value);
        }

        if ($asJson) {
            self::json(['ok' => false, 'error' => ['status' => $status, 'message' => $message]], $status);
        }

        http_response_code($status);
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-store');

        $safeMessage = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
        $appName = htmlspecialchars((string) Config::get('app.name', 'App'), ENT_QUOTES, 'UTF-8');
        $home = htmlspecialchars(FormatHelper::url('/'), ENT_QUOTES, 'UTF-8');

        echo <<<HTML
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta name="robots" content="noindex">
            <title>{$status} | {$appName}</title>
            <style>
                body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
                     background:#f4f6f9;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#1f2937}
                .box{max-width:460px;margin:1rem;padding:2rem;background:#fff;border-radius:12px;
                     box-shadow:0 4px 24px rgba(0,0,0,.08);text-align:center}
                h1{margin:0;font-size:3rem;color:#0d6efd}
                p{line-height:1.5;color:#4b5563}
                a{display:inline-block;margin-top:.5rem;padding:.55rem 1.1rem;border-radius:8px;
                  background:#0d6efd;color:#fff;text-decoration:none}
            </style>
        </head>
        <body>
            <div class="box">
                <h1>{$status}</h1>
                <p>{$safeMessage}</p>
                <a href="{$home}">Back to {$appName}</a>
            </div>
        </body>
        </html>
        HTML;
        exit;
    }
}
