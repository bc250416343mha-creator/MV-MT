<?php
/**
 * Edit project / Settings tab.
 *
 * @var array<string, mixed> $project
 * @var string $formAction
 * @var string $submitLabel
 */
$statusClass = match ((string) ($project['status'] ?? 'Planning')) {
    'Planning'  => 'planning',
    'Active'    => 'active',
    'On Hold'   => 'hold',
    'Completed' => 'completed',
    'Cancelled' => 'cancelled',
    'Archived'  => 'archived',
    default     => 'planning',
};
$activeProjectTab = 'settings';
?>
<div class="page-toolbar project-page-toolbar">
    <div>
        <p class="mono text-secondary mb-1"><?= e($project['project_code'] ?? '') ?></p>
        <h2 class="page-heading"><?= e($project['name'] ?? '') ?></h2>
        <p class="page-lead mb-0"><?= e($project['client_name'] ?? '') ?></p>
    </div>
    <span class="status-badge status-<?= e($statusClass) ?>"><?= e($project['status'] ?? '') ?></span>
</div>

<?php require APP_PATH . '/Views/projects/tabs.php'; ?>
<?php require APP_PATH . '/Views/projects/form.php'; ?>
