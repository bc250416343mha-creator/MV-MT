<?php
/**
 * SETTINGS tab: Name, Client, Color, Project estimate, Additional fields.
 * Posts to ProjectController::updateSettings. Fields that are not shown are disabled, so they
 * are not posted and keep their stored value.
 *
 * @var array<string, mixed> $project
 * @var list<array<string, mixed>> $clients
 * @var list<array<string, mixed>> $managers
 * @var list<string> $statuses
 * @var list<string> $priorities
 * @var bool $extrasReady
 */

$projectId = (int) $project['id'];
$color     = strtoupper((string) ($project['color'] ?? '#03A9F4')) ?: '#03A9F4';
$palette   = ['#03A9F4', '#2196F3', '#3F51B5', '#673AB7', '#9C27B0', '#E91E63', '#F44336', '#FF5722', '#FF9800',
              '#FFC107', '#CDDC39', '#8BC34A', '#4CAF50', '#009688', '#00BCD4', '#607D8B', '#795548', '#9E9E9E'];

$estimateType = (string) ($project['estimate_type'] ?? '');
if ($estimateType === '') {
    $estimateType = (float) $project['estimated_hours'] > 0 ? 'time' : ((float) $project['budget'] > 0 ? 'budget' : 'none');
}
$num = static fn (mixed $v): string => (float) $v > 0 ? rtrim(rtrim(number_format((float) $v, 2, '.', ''), '0'), '.') : '';

$extra = [
    'status'       => ['Status', true],
    'priority'     => ['Priority', true],
    'project_code' => ['Project code', true],
    'start_date'   => ['Start date', !empty($project['start_date'])],
    'due_date'     => ['Due date', !empty($project['due_date'])],
    'manager_id'   => ['Manager', !empty($project['manager_id'])],
    'billing'      => ['Billing', (float) $project['hourly_rate'] > 0 || (int) $project['is_billable'] !== 1],
];
?>
<section class="cf-card cf-pad">
    <form method="post" action="<?= e(url('/projects/' . $projectId . '/settings')) ?>" class="cf-settings" data-single-submit novalidate>
        <?= csrf_field() ?>

        <div class="cf-setting">
            <h2 class="cf-h2"><label for="s-name">Name</label></h2>
            <input type="text" id="s-name" name="name" class="cf-input cf-w-wide" maxlength="160" required value="<?= e($project['name']) ?>">
        </div>

        <div class="cf-setting">
            <h2 class="cf-h2"><label for="s-client">Client</label></h2>
            <p class="cf-hint">Used for grouping similar Projects together.</p>
            <select id="s-client" name="client_id" class="cf-select cf-w-select" required>
                <?php foreach ($clients as $client): ?>
                    <option value="<?= (int) $client['id'] ?>"<?= (int) $client['id'] === (int) $project['client_id'] ? ' selected' : '' ?>><?= e($client['name']) ?></option>
                <?php endforeach; ?>
                <?php
                $knownClient = false;
                foreach ($clients as $client) {
                    if ((int) $client['id'] === (int) $project['client_id']) { $knownClient = true; }
                }
                if (!$knownClient): ?>
                    <option value="<?= (int) $project['client_id'] ?>" selected><?= e($project['client_name'] ?? 'Current client') ?></option>
                <?php endif; ?>
            </select>
        </div>

        <?php if ($extrasReady): ?>
            <div class="cf-setting">
                <h2 class="cf-h2">Color</h2>
                <p class="cf-hint">Use color to visually differentiate Projects.</p>
                <div class="dropdown">
                    <button type="button" class="cf-color-btn" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false" aria-label="Project color">
                        <span class="cf-swatch" id="cf-color-swatch" style="background: <?= e($color) ?>"></span><i class="fa-solid fa-caret-down" aria-hidden="true"></i>
                    </button>
                    <div class="dropdown-menu cf-palette">
                        <?php foreach ($palette as $hex): ?>
                            <button type="button" class="cf-swatch-pick<?= $hex === $color ? ' is-on' : '' ?>" data-color="<?= e($hex) ?>"
                                    style="background: <?= e($hex) ?>" aria-label="Color <?= e($hex) ?>"></button>
                        <?php endforeach; ?>
                    </div>
                </div>
                <input type="hidden" name="color" id="cf-color-input" value="<?= e($color) ?>">
            </div>
        <?php endif; ?>

        <div class="cf-setting">
            <h2 class="cf-h2"><label for="s-estimate">Project estimate</label></h2>
            <p class="cf-hint">Choose how you wish to track Project progress (time or fixed fee budget).</p>
            <select id="s-estimate" name="estimate_type" class="cf-select cf-w-select" data-estimate-select>
                <option value="none"<?= $estimateType === 'none' ? ' selected' : '' ?>>No estimate</option>
                <option value="time"<?= $estimateType === 'time' ? ' selected' : '' ?>>Time estimate</option>
                <option value="budget"<?= $estimateType === 'budget' ? ' selected' : '' ?>>Budget estimate</option>
            </select>
            <div class="cf-estimate-input" data-estimate-for="time"<?= $estimateType === 'time' ? '' : ' hidden' ?>>
                <label for="s-hours" class="cf-label">Estimated hours</label>
                <input type="number" id="s-hours" name="estimated_hours" class="cf-input cf-w-select" min="0" step="0.25"
                       value="<?= e($num($project['estimated_hours'])) ?>"<?= $estimateType === 'time' ? '' : ' disabled' ?>>
            </div>
            <div class="cf-estimate-input" data-estimate-for="budget"<?= $estimateType === 'budget' ? '' : ' hidden' ?>>
                <label for="s-budget" class="cf-label">Budget</label>
                <input type="number" id="s-budget" name="budget" class="cf-input cf-w-select" min="0" step="0.01"
                       value="<?= e($num($project['budget'])) ?>"<?= $estimateType === 'budget' ? '' : ' disabled' ?>>
            </div>
        </div>

        <div class="cf-setting cf-setting-last">
            <h2 class="cf-h2">Additional fields</h2>
            <p class="cf-hint">All time entries on this Project will have these fields. You can<br>choose if users can see them and set their default value.</p>

            <?php foreach ($extra as $key => [$label, $visible]): ?>
                <div class="cf-extra" data-cf-field="<?= e($key) ?>"<?= $visible ? '' : ' hidden' ?>>
                    <?php if ($key === 'status'): ?>
                        <label class="cf-label" for="f-status"><?= e($label) ?></label>
                        <select id="f-status" name="status" class="cf-select cf-w-select"<?= $visible ? '' : ' disabled' ?>>
                            <?php foreach ($statuses as $st): ?>
                                <option value="<?= e($st) ?>"<?= $st === (string) $project['status'] ? ' selected' : '' ?>><?= e($st) ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php elseif ($key === 'priority'): ?>
                        <label class="cf-label" for="f-priority"><?= e($label) ?></label>
                        <select id="f-priority" name="priority" class="cf-select cf-w-select"<?= $visible ? '' : ' disabled' ?>>
                            <?php foreach ($priorities as $pr): ?>
                                <option value="<?= e($pr) ?>"<?= $pr === (string) $project['priority'] ? ' selected' : '' ?>><?= e($pr) ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php elseif ($key === 'project_code'): ?>
                        <label class="cf-label" for="f-code"><?= e($label) ?></label>
                        <input type="text" id="f-code" name="project_code" class="cf-input cf-w-select" maxlength="40"
                               value="<?= e($project['project_code']) ?>"<?= $visible ? '' : ' disabled' ?>>
                    <?php elseif ($key === 'start_date'): ?>
                        <label class="cf-label" for="f-start"><?= e($label) ?></label>
                        <input type="date" id="f-start" name="start_date" class="cf-input cf-w-select"
                               value="<?= e((string) ($project['start_date'] ?? '')) ?>"<?= $visible ? '' : ' disabled' ?>>
                    <?php elseif ($key === 'due_date'): ?>
                        <label class="cf-label" for="f-due"><?= e($label) ?></label>
                        <input type="date" id="f-due" name="due_date" class="cf-input cf-w-select"
                               value="<?= e((string) ($project['due_date'] ?? '')) ?>"<?= $visible ? '' : ' disabled' ?>>
                    <?php elseif ($key === 'manager_id'): ?>
                        <label class="cf-label" for="f-manager"><?= e($label) ?></label>
                        <select id="f-manager" name="manager_id" class="cf-select cf-w-select"<?= $visible ? '' : ' disabled' ?>>
                            <option value="">Unassigned</option>
                            <?php foreach ($managers as $manager): ?>
                                <option value="<?= (int) $manager['id'] ?>"<?= (int) $manager['id'] === (int) ($project['manager_id'] ?? 0) ? ' selected' : '' ?>><?= e($manager['name']) ?> (<?= e($manager['role']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    <?php else: ?>
                        <label class="cf-label" for="f-rate">Hourly rate (<?= e($currency) ?>)</label>
                        <input type="number" id="f-rate" name="hourly_rate" class="cf-input cf-w-select" min="0" step="0.01"
                               value="<?= e($num($project['hourly_rate'])) ?>"<?= $visible ? '' : ' disabled' ?>>
                        <input type="hidden" name="is_billable" value="0"<?= $visible ? '' : ' disabled' ?>>
                        <label class="cf-check mt-2">
                            <input type="checkbox" name="is_billable" value="1"<?= (int) $project['is_billable'] === 1 ? ' checked' : '' ?><?= $visible ? '' : ' disabled' ?>>
                            <span>Billable</span>
                        </label>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>

            <select class="cf-select cf-w-select" id="cf-add-field" aria-label="Add more fields">
                <option value="" selected>Add more fields...</option>
                <?php foreach ($extra as $key => [$label, $visible]): ?>
                    <?php if (!$visible): ?><option value="<?= e($key) ?>"><?= e($label) ?></option><?php endif; ?>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="cf-settings-foot">
            <button type="submit" class="cf-btn cf-btn-primary">Save</button>
            <a class="cf-btn cf-btn-ghost" href="<?= e(url('/projects/' . $projectId . '?tab=settings')) ?>">Cancel</a>
        </div>
    </form>
</section>
