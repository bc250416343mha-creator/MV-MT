<?php
/**
 * TASKS tab (Clockify layout): filter + search on the left, "Add new Task" + ADD on the right,
 * grey "Tasks" band, NAME / ASSIGNEES table with inline rename, inline assignee picker and row menu.
 * Included by projects/view.php (shares its variables).
 *
 * @var array<string, mixed> $project
 * @var list<array<string, mixed>> $members
 * @var list<array<string, mixed>> $tasks
 * @var array{all: int, active: int, done: int} $taskCounts
 * @var string $taskFilter   active|done|all
 * @var string $taskSearch
 * @var string $taskDir      asc|desc
 * @var bool $canCreateTask
 * @var bool $canEditTask
 * @var bool $canDeleteTask
 * @var bool $canAssignTask
 */

$projectId  = (int) $project['id'];
$projectUrl = url('/projects/' . $projectId);
$hasFilter  = $taskSearch !== '' || $taskFilter !== 'active';
$showKebab  = $canEditTask || $canDeleteTask;
$sortUrl    = $projectUrl . '?' . http_build_query([
    'tab'         => 'tasks',
    'task_status' => $taskFilter,
    'task_q'      => $taskSearch,
    'task_dir'    => $taskDir === 'asc' ? 'desc' : 'asc',
]);
// Where plain (non-JS) form posts return to: this project's Tasks tab with the same filters.
$backPath   = '/projects/' . $projectId . '?' . http_build_query([
    'tab'         => 'tasks',
    'task_status' => $taskFilter,
    'task_q'      => $taskSearch,
    'task_dir'    => $taskDir,
]);
$assignable = array_values(array_filter($members, static fn (array $m): bool => (string) ($m['status'] ?? 'active') === 'active'));
?>
<section class="cf-card cf-tasks">
    <div class="cf-toolbar">
        <form method="get" action="<?= e($projectUrl) ?>" class="cf-filters">
            <input type="hidden" name="tab" value="tasks">
            <label for="task-status-filter" class="visually-hidden">Show</label>
            <select id="task-status-filter" name="task_status" class="cf-select cf-select-filter" data-auto-submit>
                <option value="active"<?= $taskFilter === 'active' ? ' selected' : '' ?>>Show active</option>
                <option value="done"<?= $taskFilter === 'done' ? ' selected' : '' ?>>Show done</option>
                <option value="all"<?= $taskFilter === 'all' ? ' selected' : '' ?>>Show all</option>
            </select>
            <div class="cf-search">
                <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                <label for="task-search" class="visually-hidden">Search tasks</label>
                <input type="search" id="task-search" name="task_q" maxlength="100" placeholder="Search by name" value="<?= e($taskSearch) ?>">
            </div>
        </form>

        <?php if ($canCreateTask): ?>
            <form method="post" action="<?= e(url('/projects/' . $projectId . '/tasks')) ?>" class="cf-add" data-single-submit>
                <?= csrf_field() ?>
                <label for="new-task-name" class="visually-hidden">Add new task</label>
                <input type="text" id="new-task-name" name="name" maxlength="160" required placeholder="Add new Task" autocomplete="off">
                <button type="submit" class="cf-btn cf-btn-primary">Add</button>
            </form>
        <?php endif; ?>
    </div>

    <div class="cf-band">
        <span>Tasks</span>
        <?php if ($hasFilter): ?>
            <a class="cf-band-link" href="<?= e($projectUrl . '?tab=tasks') ?>">Reset filter</a>
        <?php endif; ?>
    </div>

    <?php if ($tasks === []): ?>
        <div class="cf-empty">
            <?php if ($hasFilter && $taskCounts['all'] > 0): ?>
                No tasks match this filter.
            <?php else: ?>
                This project has no tasks yet.<?= $canCreateTask ? ' Type a name above and press ADD.' : '' ?>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="cf-table-wrap">
            <table class="cf-table">
                <thead>
                    <tr>
                        <th class="cf-col-name">
                            <a class="cf-sort" href="<?= e($sortUrl) ?>">Name
                                <i class="fa-solid <?= $taskDir === 'desc' ? 'fa-sort-down' : 'fa-sort-up' ?>" aria-hidden="true"></i>
                            </a>
                        </th>
                        <th class="cf-col-assignees">Assignees</th>
                        <th class="cf-col-status">Status</th>
                        <?php if ($showKebab): ?><th class="cf-col-actions" aria-label="Actions"></th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tasks as $task): ?>
                        <?php
                        $taskId = (int) $task['id'];
                        $isDone = Task::isDone((string) $task['status']);
                        $names  = array_map(static fn (array $a): string => (string) $a['name'], $task['assignees']);
                        $label  = $names === [] ? 'Anyone' : implode(', ', $names);
                        $payload = [
                            'name'            => (string) $task['name'],
                            'description'     => (string) ($task['description'] ?? ''),
                            'status'          => (string) $task['status'],
                            'estimated_hours' => (float) $task['estimated_hours'] > 0 ? rtrim(rtrim(number_format((float) $task['estimated_hours'], 2, '.', ''), '0'), '.') : '',
                            'due_date'        => (string) ($task['due_date'] ?? ''),
                            'assignee_ids'    => $task['assignee_ids'],
                        ];
                        ?>
                        <tr<?= $isDone ? ' class="is-done"' : '' ?>>
                            <td class="cf-col-name" data-label="Name">
                                <?php if ($canEditTask): ?>
                                    <input type="text" class="cf-name-input" value="<?= e($task['name']) ?>" maxlength="160"
                                           data-task-rename="<?= e(url('/tasks/' . $taskId . '/rename')) ?>"
                                           data-original="<?= e($task['name']) ?>" aria-label="Task name" autocomplete="off"
                                           <?= $isDone ? 'disabled title="Completed tasks cannot be renamed. Mark the task active first."' : '' ?>>
                                <?php else: ?>
                                    <span class="cf-name-text"><?= e($task['name']) ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="cf-col-assignees" data-label="Assignees">
                                <?php if ($canAssignTask && $assignable !== []): ?>
                                    <div class="dropdown cf-assignee" data-task-assignees="<?= e(url('/tasks/' . $taskId . '/assignees')) ?>">
                                        <button type="button" class="cf-pill" data-bs-toggle="dropdown" data-bs-auto-close="outside" data-bs-popper-config='{"strategy":"fixed"}' aria-expanded="false">
                                            <span class="cf-pill-label"><?= e($label) ?></span><i class="fa-solid fa-caret-down" aria-hidden="true"></i>
                                        </button>
                                        <div class="dropdown-menu cf-assignee-menu">
                                            <?php foreach ($assignable as $member): ?>
                                                <label class="cf-check">
                                                    <input type="checkbox" value="<?= (int) $member['user_id'] ?>"
                                                           data-name="<?= e($member['name']) ?>"
                                                           <?= in_array((int) $member['user_id'], $task['assignee_ids'], true) ? 'checked' : '' ?>>
                                                    <span><?= e($member['name']) ?></span>
                                                </label>
                                            <?php endforeach; ?>
                                            <p class="cf-menu-hint">Nobody selected means <strong>Anyone</strong>.</p>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <span class="cf-pill is-static"><span class="cf-pill-label"><?= e($label) ?></span><i class="fa-solid fa-caret-down" aria-hidden="true"></i></span>
                                <?php endif; ?>
                            </td>
                            <td class="cf-col-status" data-label="Status">
                                <span class="cf-status-badge <?= $isDone ? 'is-done' : 'is-active' ?>" data-task-status><?= $isDone ? 'Done' : 'Active' ?></span>
                            </td>
                            <?php if ($showKebab): ?>
                                <td class="cf-col-actions" data-label="Actions">
                                    <div class="dropdown">
                                        <button type="button" class="cf-kebab" data-bs-toggle="dropdown" data-bs-popper-config='{"strategy":"fixed"}' aria-expanded="false" aria-label="Task actions">
                                            <span class="cf-dots" aria-hidden="true"><i></i><i></i><i></i></span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end cf-menu">
                                            <?php if ($canEditTask): ?>
                                                <li>
                                                    <button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#taskModal"
                                                            data-task-edit="<?= e(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT)) ?>"
                                                            data-task-action="<?= e(url('/tasks/' . $taskId)) ?>">Edit</button>
                                                </li>
                                                <li>
                                                    <form method="post" action="<?= e(url('/tasks/' . $taskId . '/status')) ?>"
                                                          data-task-toggle-status data-task-filter="<?= e($taskFilter) ?>">
                                                        <?= csrf_field() ?>
                                                        <input type="hidden" name="back" value="<?= e($backPath) ?>">
                                                        <input type="hidden" name="status" value="<?= $isDone ? 'To Do' : 'Completed' ?>">
                                                        <button type="submit" class="dropdown-item"><?= $isDone ? 'Mark as active' : 'Mark as done' ?></button>
                                                    </form>
                                                </li>
                                            <?php endif; ?>
                                            <?php if ($canDeleteTask): ?>
                                                <?php if ($canEditTask): ?><li><hr class="dropdown-divider"></li><?php endif; ?>
                                                <li>
                                                    <form method="post" action="<?= e(url('/tasks/' . $taskId . '/delete')) ?>"
                                                          data-confirm="Delete task <?= e($task['name']) ?>? Planned schedule blocks keep their time but lose the task link.">
                                                        <?= csrf_field() ?>
                                                        <button type="submit" class="dropdown-item text-danger">Delete</button>
                                                    </form>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<?php if ($canCreateTask || $canEditTask): ?>
    <?php require APP_PATH . '/Views/tasks/form_modal.php'; ?>
<?php endif; ?>
