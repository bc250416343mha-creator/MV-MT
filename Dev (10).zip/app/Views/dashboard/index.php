<?php
/**
 * Starter dashboard.
 *
 * @var int                                  $unread         unread notification count
 * @var list<array<string, mixed>>           $notifications  latest notifications for the user
 * @var list<array<string, mixed>>           $team           [display_name, total] (empty without users.view)
 * @var list<array<string, mixed>>           $activity       recent audit rows (empty without activity.view)
 * @var bool                                 $canTrack
 */

$me   = AuthHelper::user() ?? ['name' => '', 'role' => ''];
$hour = (int) FormatHelper::datetime(gmdate('Y-m-d H:i:s'), 'G'); // hour of day for the viewer
$greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');
$firstName = trim((string) strtok((string) $me['name'], ' '));

$activityText = [
    'auth.login'                  => 'signed in',
    'auth.logout'                 => 'signed out',
    'auth.login_failed'           => 'had a failed sign-in',
    'auth.login_blocked'          => 'was blocked from signing in',
    'auth.password_changed'       => 'changed their password',
    'auth.password_change_failed' => 'entered the wrong current password',
    'profile.updated'             => 'updated their profile',
    'timer.started'               => 'started a timer',
    'timer.stopped'               => 'stopped a timer',
    'time_entry.created'          => 'added a time entry',
    'time_entry.deleted'          => 'deleted a time entry',
    'timesheet.submitted'         => 'submitted a timesheet',
    'timesheet.approved'          => 'approved a timesheet',
    'timesheet.rejected'          => 'rejected a timesheet',
];

$typeIcon = [
    'success' => 'fa-circle-check',
    'warning' => 'fa-triangle-exclamation',
    'danger'  => 'fa-circle-exclamation',
    'info'    => 'fa-circle-info',
];
?>
<div class="dash-hello">
    <div>
        <h2 class="dash-greeting"><?= e($greeting) ?><?= $firstName !== '' ? ', ' . e($firstName) : '' ?></h2>
        <p class="dash-date"><?= e(FormatHelper::datetime(gmdate('Y-m-d H:i:s'), 'l, F j')) ?></p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <?php if (!empty($canTrack)): ?>
            <a class="btn btn-primary" href="<?= e(url('/time')) ?>"><i class="fa-solid fa-stopwatch me-1" aria-hidden="true"></i>Track time</a>
        <?php endif; ?>
        <?php if (PermissionHelper::has('time.view_own') && is_file(APP_PATH . '/Controllers/TimesheetController.php')): ?>
            <a class="btn btn-outline-primary" href="<?= e(url('/timesheets')) ?>"><i class="fa-solid fa-table me-1" aria-hidden="true"></i>Timesheet</a>
        <?php endif; ?>
        <span class="role-pill role-<?= e((string) $me['role']) ?>"><?= e(ucfirst((string) $me['role'])) ?></span>
    </div>
</div>

<div class="row g-4">
    <div class="col-xl-7">
        <section class="panel" id="notifications" aria-labelledby="notifications-title">
            <div class="panel-head">
                <h2 id="notifications-title" class="panel-title">
                    Notifications
                    <?php if ($unread > 0): ?><span class="count-pill"><?= (int) $unread ?> new</span><?php endif; ?>
                </h2>
                <?php if ($unread > 0): ?>
                    <form method="post" action="<?= e(url('/notifications/read')) ?>" class="m-0">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-outline-secondary">Mark all as read</button>
                    </form>
                <?php endif; ?>
            </div>

            <?php if ($notifications === []): ?>
                <div class="empty-state">
                    <i class="fa-regular fa-bell-slash" aria-hidden="true"></i>
                    <p>You are all caught up. New messages about your projects and time will show up here.</p>
                </div>
            <?php else: ?>
                <ul class="feed">
                    <?php foreach ($notifications as $note): ?>
                        <li class="feed-item<?= $note['is_read'] ? '' : ' is-unread' ?>">
                            <span class="feed-icon feed-<?= e($note['type']) ?>" aria-hidden="true">
                                <i class="fa-solid <?= e($typeIcon[$note['type']] ?? 'fa-circle-info') ?>"></i>
                            </span>
                            <div class="feed-body">
                                <div class="feed-title">
                                    <?php if (!empty($note['link']) && str_starts_with((string) $note['link'], '/') && !str_starts_with((string) $note['link'], '//')): ?>
                                        <a href="<?= e(url((string) $note['link'])) ?>"><?= e($note['title']) ?></a>
                                    <?php else: ?>
                                        <?= e($note['title']) ?>
                                    <?php endif; ?>
                                    <?php if (!$note['is_read']): ?><span class="visually-hidden">(unread)</span><?php endif; ?>
                                </div>
                                <?php if (!empty($note['message'])): ?>
                                    <div class="feed-text"><?= e($note['message']) ?></div>
                                <?php endif; ?>
                            </div>
                            <time class="feed-time" datetime="<?= e(str_replace(' ', 'T', (string) $note['created_at'])) ?>Z"><?= e(FormatHelper::datetime($note['created_at'], 'M j, H:i')) ?></time>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </section>
    </div>

    <div class="col-xl-5">
        <?php if ($team !== []): ?>
            <section class="panel mb-4" aria-labelledby="team-title">
                <div class="panel-head">
                    <h2 id="team-title" class="panel-title">Active people</h2>
                </div>
                <ul class="tally">
                    <?php foreach ($team as $row): ?>
                        <li>
                            <span><?= e($row['display_name']) ?></span>
                            <strong><?= (int) $row['total'] ?></strong>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </section>
        <?php endif; ?>

        <?php if ($activity !== []): ?>
            <section class="panel" aria-labelledby="activity-title">
                <div class="panel-head">
                    <h2 id="activity-title" class="panel-title">Recent activity</h2>
                </div>
                <ul class="feed feed-compact">
                    <?php foreach ($activity as $row): ?>
                        <li class="feed-item">
                            <div class="feed-body">
                                <div class="feed-text">
                                    <strong><?= e($row['user_name'] ?? 'Someone') ?></strong>
                                    <?= e($activityText[$row['action']] ?? str_replace(['.', '_'], ' ', (string) $row['action'])) ?>
                                </div>
                            </div>
                            <time class="feed-time" datetime="<?= e(str_replace(' ', 'T', (string) $row['created_at'])) ?>Z"><?= e(FormatHelper::datetime($row['created_at'], 'M j, H:i')) ?></time>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </section>
        <?php endif; ?>

        <?php if ($team === [] && $activity === []): ?>
            <section class="panel" aria-labelledby="start-title">
                <div class="panel-head">
                    <h2 id="start-title" class="panel-title">Your account</h2>
                </div>
                <div class="panel-body">
                    <p class="mb-3">Keep your details and timezone up to date so dates and times match your day.</p>
                    <a class="btn btn-outline-primary" href="<?= e(url('/profile')) ?>">Open my profile</a>
                </div>
            </section>
        <?php endif; ?>
    </div>
</div>
