<?php
/**
 * Planned work blocks with overlap (conflict) detection.
 */

declare(strict_types=1);

final class Schedule extends Model
{
    public const STATUS_SCHEDULED    = 'Scheduled';
    public const STATUS_IN_PROGRESS  = 'In Progress';
    public const STATUS_COMPLETED    = 'Completed';
    public const STATUS_MISSED       = 'Missed';
    public const STATUS_CANCELLED    = 'Cancelled';
    public const STATUS_RESCHEDULED  = 'Rescheduled';

    public const STATUSES = [
        self::STATUS_SCHEDULED,
        self::STATUS_IN_PROGRESS,
        self::STATUS_COMPLETED,
        self::STATUS_MISSED,
        self::STATUS_CANCELLED,
        self::STATUS_RESCHEDULED,
    ];

    public const ACTIVE_STATUSES = [
        self::STATUS_SCHEDULED,
        self::STATUS_IN_PROGRESS,
        self::STATUS_COMPLETED,
        self::STATUS_MISSED,
        self::STATUS_RESCHEDULED,
    ];

    public const RECURRENCE_DAILY    = 'daily';
    public const RECURRENCE_WEEKLY   = 'weekly';
    public const RECURRENCE_WEEKDAYS = 'weekdays';
    public const RECURRENCE_CUSTOM   = 'custom';

    public const RECURRENCE_TYPES = [
        self::RECURRENCE_DAILY,
        self::RECURRENCE_WEEKLY,
        self::RECURRENCE_WEEKDAYS,
        self::RECURRENCE_CUSTOM,
    ];

    protected string $table = 'schedules';

    protected array $columns = [
        'id', 'project_id', 'task_id', 'user_id', 'recurrence_parent_id',
        'start_datetime', 'end_datetime', 'estimated_hours',
        'status', 'notes', 'created_by', 'created_at', 'updated_at',
    ];

    protected array $fillable = [
        'project_id', 'task_id', 'user_id', 'recurrence_parent_id',
        'start_datetime', 'end_datetime', 'estimated_hours',
        'status', 'notes', 'created_by',
    ];

    public function findWithRelations(int $id): ?array
    {
        $row = Database::fetchOne(
            $this->selectSql() . ' WHERE s.id = :id LIMIT 1',
            ['id' => $id]
        );

        return $row === null ? null : $this->hydrate($row);
    }

    /**
     * Overlap test: existing.start < newEnd AND existing.end > newStart,
     * excluding Cancelled (and optionally one schedule being moved).
     *
     * @return list<array{id: int, task_name: string, project_name: string, start_datetime: string, end_datetime: string, status: string, user_name: string, time_range: string}>
     */
    public function checkConflict(int $userId, string $startDatetime, string $endDatetime, ?int $excludeScheduleId = null): array
    {
        $sql = $this->selectSql() . '
            WHERE s.user_id = :user_id
              AND s.status <> :cancelled
              AND s.start_datetime < :end_datetime
              AND s.end_datetime > :start_datetime';

        $params = [
            'user_id'        => $userId,
            'cancelled'      => self::STATUS_CANCELLED,
            'end_datetime'   => $endDatetime,
            'start_datetime' => $startDatetime,
        ];

        if ($excludeScheduleId !== null && $excludeScheduleId > 0) {
            $sql .= ' AND s.id <> :exclude_id';
            $params['exclude_id'] = $excludeScheduleId;
        }

        $sql .= ' ORDER BY s.start_datetime ASC';

        $rows = Database::fetchAll($sql, $params);
        $conflicts = [];

        foreach ($rows as $row) {
            $row = $this->hydrate($row);
            $conflicts[] = [
                'id'              => (int) $row['id'],
                'task_name'       => (string) ($row['task_name'] ?: 'No task'),
                'project_name'    => (string) $row['project_name'],
                'start_datetime'  => (string) $row['start_datetime'],
                'end_datetime'    => (string) $row['end_datetime'],
                'status'          => (string) $row['status'],
                'user_name'       => (string) $row['user_name'],
                'time_range'      => FormatHelper::datetime((string) $row['start_datetime'], 'M j, H:i')
                    . ' – ' . FormatHelper::datetime((string) $row['end_datetime'], 'H:i'),
            ];
        }

        return $conflicts;
    }

    /**
     * Calendar / list feed between two UTC datetimes.
     *
     * @return list<array<string, mixed>>
     */
    public function inRange(string $startUtc, string $endUtc, ?int $userId = null, bool $viewAll = false, int $viewerId = 0): array
    {
        $sql = $this->selectSql() . '
            WHERE s.start_datetime < :end_utc
              AND s.end_datetime > :start_utc
              AND s.status <> :cancelled';

        $params = [
            'end_utc'   => $endUtc,
            'start_utc' => $startUtc,
            'cancelled' => self::STATUS_CANCELLED,
        ];

        if ($userId !== null && $userId > 0) {
            $sql .= ' AND s.user_id = :user_id';
            $params['user_id'] = $userId;
        } elseif (!$viewAll && $viewerId > 0) {
            $sql .= ' AND s.user_id = :viewer';
            $params['viewer'] = $viewerId;
        }

        if ($viewAll && $viewerId > 0 && !PermissionHelper::has('projects.view_all')) {
            $sql .= ' AND (p.manager_id = :viewer_mgr OR p.created_by = :viewer_own)';
            $params['viewer_mgr'] = $viewerId;
            $params['viewer_own'] = $viewerId;
        }

        $sql .= ' ORDER BY s.start_datetime ASC';

        return array_map([$this, 'hydrate'], Database::fetchAll($sql, $params));
    }

    /**
     * Upcoming blocks for one person (my schedule).
     *
     * @return list<array<string, mixed>>
     */
    public function forUser(int $userId, string $fromUtc, int $limit = 50): array
    {
        $rows = Database::fetchAll(
            $this->selectSql() . '
             WHERE s.user_id = :user_id
               AND s.end_datetime >= :from_utc
               AND s.status <> :cancelled
             ORDER BY s.start_datetime ASC
             LIMIT :limit',
            [
                'user_id'  => $userId,
                'from_utc' => $fromUtc,
                'cancelled'=> self::STATUS_CANCELLED,
                'limit'    => max(1, $limit),
            ]
        );

        return array_map([$this, 'hydrate'], $rows);
    }

    /**
     * Planned hours per person in a window (team matrix).
     *
     * @return list<array<string, mixed>>
     */
    public function teamWorkload(string $startUtc, string $endUtc): array
    {
        $sql = "SELECT u.id AS user_id, u.name, u.email, u.role, u.job_title,
                       COALESCE(SUM(
                           TIMESTAMPDIFF(SECOND,
                               GREATEST(s.start_datetime, :start_a),
                               LEAST(s.end_datetime, :end_a)
                           )
                       ), 0) AS planned_seconds,
                       COUNT(s.id) AS block_count
                FROM users u
                LEFT JOIN schedules s
                  ON s.user_id = u.id
                 AND s.status NOT IN ('Cancelled')
                 AND s.start_datetime < :end_b
                 AND s.end_datetime > :start_b
                LEFT JOIN projects p ON p.id = s.project_id
                WHERE u.status = 'active' AND u.role IN ('admin','manager','employee')";

        $params = [
            'start_a' => $startUtc,
            'end_a'   => $endUtc,
            'end_b'   => $endUtc,
            'start_b' => $startUtc,
        ];

        if (!PermissionHelper::has('projects.view_all')) {
            $viewer = (int) AuthHelper::id();
            $sql .= ' AND EXISTS (
                SELECT 1 FROM projects tp
                WHERE (tp.manager_id = :uid_mgr OR tp.created_by = :uid_own)
                  AND (
                      tp.manager_id = u.id
                      OR tp.created_by = u.id
                      OR EXISTS (
                          SELECT 1 FROM project_members tpm
                          WHERE tpm.project_id = tp.id AND tpm.user_id = u.id
                      )
                  )
            )';
            $sql .= ' AND (s.id IS NULL OR p.manager_id = :sid_mgr OR p.created_by = :sid_own)';
            $params['uid_mgr'] = $viewer;
            $params['uid_own'] = $viewer;
            $params['sid_mgr'] = $viewer;
            $params['sid_own'] = $viewer;
        }

        $sql .= ' GROUP BY u.id, u.name, u.email, u.role, u.job_title ORDER BY u.name ASC';

        return Database::fetchAll($sql, $params);
    }

    public function userCanView(array $schedule, int $userId, bool $viewTeam): bool
    {
        if ((int) $schedule['user_id'] === $userId) {
            return true;
        }

        if (!$viewTeam) {
            return false;
        }

        $project = (new Project())->find((int) $schedule['project_id']);
        if ($project === null) {
            return false;
        }

        return (new Project())->userCanView($project, $userId, PermissionHelper::has('projects.view_all'));
    }

    public function userCanEdit(array $schedule, int $userId, bool $isAdmin, bool $isManager): bool
    {
        if ($isAdmin) {
            return true;
        }

        if ($isManager) {
            $project = (new Project())->find((int) $schedule['project_id']);
            if ($project !== null && (int) ($project['manager_id'] ?? 0) === $userId) {
                return true;
            }
        }

        return (int) $schedule['user_id'] === $userId || (int) ($schedule['created_by'] ?? 0) === $userId;
    }

    /**
     * @param array{recurrence_type?: string, repeat_until?: string|null, days_of_week?: string|null} $recurrence
     */
    public function saveRecurrence(int $scheduleId, array $recurrence): void
    {
        $type = (string) ($recurrence['recurrence_type'] ?? '');
        if (!in_array($type, self::RECURRENCE_TYPES, true)) {
            Database::execute('DELETE FROM schedule_recurrences WHERE schedule_id = :id', ['id' => $scheduleId]);
            return;
        }

        $until = $recurrence['repeat_until'] ?? null;
        $days  = $recurrence['days_of_week'] ?? null;

        $existing = Database::fetchOne(
            'SELECT id FROM schedule_recurrences WHERE schedule_id = :id LIMIT 1',
            ['id' => $scheduleId]
        );

        if ($existing !== null) {
            Database::execute(
                'UPDATE schedule_recurrences
                 SET recurrence_type = :type, repeat_until = :until, days_of_week = :days
                 WHERE id = :id',
                [
                    'type'  => $type,
                    'until' => $until,
                    'days'  => $days,
                    'id'    => (int) $existing['id'],
                ]
            );
            return;
        }

        Database::execute(
            'INSERT INTO schedule_recurrences (schedule_id, recurrence_type, repeat_until, days_of_week, created_at)
             VALUES (:schedule_id, :type, :until, :days, UTC_TIMESTAMP())',
            [
                'schedule_id' => $scheduleId,
                'type'        => $type,
                'until'       => $until,
                'days'        => $days,
            ]
        );
    }

    /**
     * Expand a newly created block into additional dated copies.
     *
     * @return list<int> created schedule ids (not including the original)
     */
    public function expandRecurrence(int $scheduleId, int $maxCopies = 30): array
    {
        $source = $this->find($scheduleId);
        $rule   = Database::fetchOne(
            'SELECT * FROM schedule_recurrences WHERE schedule_id = :id LIMIT 1',
            ['id' => $scheduleId]
        );

        if ($source === null || $rule === null) {
            return [];
        }

        $start = new DateTimeImmutable((string) $source['start_datetime'], new DateTimeZone('UTC'));
        $end   = new DateTimeImmutable((string) $source['end_datetime'], new DateTimeZone('UTC'));
        $until = !empty($rule['repeat_until'])
            ? new DateTimeImmutable((string) $rule['repeat_until'] . ' 23:59:59', new DateTimeZone('UTC'))
            : $start->modify('+8 weeks');

        $days = $this->parseDays((string) ($rule['days_of_week'] ?? ''), (string) $rule['recurrence_type']);
        if ($days === [] && (string) $rule['recurrence_type'] === self::RECURRENCE_WEEKLY) {
            $days = [(int) $start->format('N')];
        }
        $created = [];
        $cursor = $start->modify('+1 day');
        $guard  = 0;

        while ($cursor <= $until && count($created) < $maxCopies && $guard < 400) {
            $guard++;
            $iso = (int) $cursor->format('N');
            $include = match ((string) $rule['recurrence_type']) {
                self::RECURRENCE_DAILY    => true,
                self::RECURRENCE_WEEKDAYS => $iso <= 5,
                self::RECURRENCE_WEEKLY,
                self::RECURRENCE_CUSTOM   => in_array($iso, $days, true),
                default                   => false,
            };

            if ($include) {
                $copyStart = $cursor->setTime(
                    (int) $start->format('H'),
                    (int) $start->format('i'),
                    (int) $start->format('s')
                );
                $copyEnd = $copyStart->add($start->diff($end));

                // Recurrence expansion must obey the same overlap rule as
                // manually created/moved schedules. The original block is
                // already persisted; only create an occurrence when its
                // complete interval is free for the assigned user.
                $conflicts = $this->checkConflict(
                    (int) $source['user_id'],
                    $copyStart->format('Y-m-d H:i:s'),
                    $copyEnd->format('Y-m-d H:i:s')
                );

                if ($conflicts !== []) {
                    $cursor = $cursor->modify('+1 day');
                    continue;
                }

                $copyId = $this->create([
                    'project_id'      => (int) $source['project_id'],
                    'task_id'         => $source['task_id'] !== null ? (int) $source['task_id'] : null,
                    'user_id'         => (int) $source['user_id'],
                    'start_datetime'  => $copyStart->format('Y-m-d H:i:s'),
                    'end_datetime'    => $copyEnd->format('Y-m-d H:i:s'),
                    'estimated_hours' => $source['estimated_hours'],
                    'status'          => self::STATUS_SCHEDULED,
                    'notes'           => $source['notes'],
                    'created_by'      => $source['created_by'] !== null ? (int) $source['created_by'] : null,
                ]);
                $created[] = $copyId;
            }

            $cursor = $cursor->modify('+1 day');
        }

        return $created;
    }

    public function cancel(int $id): int
    {
        return Database::execute(
            "UPDATE schedules SET status = 'Cancelled', updated_at = UTC_TIMESTAMP() WHERE id = :id",
            ['id' => $id]
        );
    }

    public static function hoursBetween(string $startUtc, string $endUtc): float
    {
        try {
            $a = new DateTimeImmutable($startUtc, new DateTimeZone('UTC'));
            $b = new DateTimeImmutable($endUtc, new DateTimeZone('UTC'));
        } catch (Exception) {
            return 0.0;
        }

        $seconds = max(0, $b->getTimestamp() - $a->getTimestamp());

        return round($seconds / 3600, 2);
    }

    public static function colorFor(array $row): string
    {
        return match ((string) ($row['status'] ?? '')) {
            self::STATUS_IN_PROGRESS => '#0b7a75',
            self::STATUS_COMPLETED   => '#1c6a2c',
            self::STATUS_MISSED      => '#962222',
            self::STATUS_CANCELLED   => '#7a7f7e',
            self::STATUS_RESCHEDULED => '#3d2f80',
            default => match ((string) ($row['project_priority'] ?? '')) {
                'Urgent' => '#962222',
                'High'   => '#b56a00',
                'Low'    => '#3a4a48',
                default  => '#12426f',
            },
        };
    }

    private function selectSql(): string
    {
        $taskSelect = $this->tasksExist() ? 't.name AS task_name' : 'NULL AS task_name';
        $taskJoin   = $this->tasksExist() ? 'LEFT JOIN tasks t ON t.id = s.task_id' : '';

        return "SELECT s.*,
                       p.name AS project_name, p.project_code, p.priority AS project_priority, p.manager_id AS project_manager_id,
                       u.name AS user_name, u.email AS user_email, u.role AS user_role,
                       {$taskSelect},
                       r.recurrence_type, r.repeat_until, r.days_of_week
                FROM schedules s
                INNER JOIN projects p ON p.id = s.project_id
                INNER JOIN users u ON u.id = s.user_id
                {$taskJoin}
                LEFT JOIN schedule_recurrences r ON r.schedule_id = s.id";
    }

    /** @param array<string, mixed> $row */
    private function hydrate(array $row): array
    {
        $row['id']              = (int) $row['id'];
        $row['project_id']      = (int) $row['project_id'];
        $row['task_id']         = $row['task_id'] !== null ? (int) $row['task_id'] : null;
        $row['user_id']         = (int) $row['user_id'];
        $row['estimated_hours'] = (float) $row['estimated_hours'];
        $row['task_name']       = $row['task_name'] ?? null;
        $row['color']           = self::colorFor($row);

        return $row;
    }

    /** @return list<int> */
    private function parseDays(string $raw, string $type): array
    {
        if ($type === self::RECURRENCE_WEEKDAYS) {
            return [1, 2, 3, 4, 5];
        }

        $days = [];
        foreach (explode(',', $raw) as $part) {
            $n = (int) trim($part);
            if ($n >= 1 && $n <= 7) {
                $days[] = $n;
            }
        }

        if ($days === [] && $type === self::RECURRENCE_WEEKLY) {
            return [];
        }

        return array_values(array_unique($days));
    }

    private function tasksExist(): bool
    {
        static $exists = null;

        if ($exists === null) {
            try {
                $exists = (int) Database::fetchValue(
                    "SELECT COUNT(*) FROM information_schema.tables
                     WHERE table_schema = DATABASE() AND table_name = 'tasks'"
                ) > 0;
            } catch (Throwable) {
                $exists = false;
            }
        }

        return $exists;
    }
}
