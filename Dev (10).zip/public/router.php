<?php
/**
 * Router for PHP's built-in server (php -S). Apache uses public/.htaccess instead.
 */

declare(strict_types=1);

$uri = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
$uri = rawurldecode($uri);

if ($uri !== '/' && $uri !== '') {
    $file = __DIR__ . $uri;
    if (is_file($file)) {
        return false;
    }
}

require __DIR__ . '/index.php';
