-- TimeTrack Phase 13 / Step 13 rollback
-- Safe to run when the Step 13 column/constraint is absent.

SET @db_name := DATABASE();

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_schema = @db_name
          AND table_name = 'schedules'
          AND constraint_name = 'fk_schedules_recurrence_parent'
          AND constraint_type = 'FOREIGN KEY'
    ),
    'ALTER TABLE `schedules` DROP FOREIGN KEY `fk_schedules_recurrence_parent`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name
          AND table_name = 'schedules'
          AND column_name = 'recurrence_parent_id'
    ),
    'ALTER TABLE `schedules` DROP COLUMN `recurrence_parent_id`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
