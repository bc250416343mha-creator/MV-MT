-- Phase 13 / Step 12 correction: allow multiple approval submissions
-- inside the same configured approval period. Each submission batch gets
-- its own timesheet row and locks only its linked time entries.
ALTER TABLE `timesheets`
    ADD COLUMN IF NOT EXISTS `submission_token` VARCHAR(64) NULL AFTER `end_date`;

UPDATE `timesheets`
SET `submission_token` = CONCAT('legacy-', `id`)
WHERE `submission_token` IS NULL OR `submission_token` = '';

ALTER TABLE `timesheets`
    DROP INDEX IF EXISTS `uq_timesheets_user_period`;

ALTER TABLE `timesheets`
    ADD UNIQUE INDEX IF NOT EXISTS `uq_timesheets_submission_token` (`submission_token`),
    ADD INDEX IF NOT EXISTS `idx_timesheets_user_period` (`user_id`, `start_date`, `end_date`);
