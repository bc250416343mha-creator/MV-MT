-- TimeTrack Phase 13 / Step 14 rollback.
-- Recreates the legacy global keys from the canonical workspace/system values.
-- Workspace rows are intentionally retained to avoid deleting settings that may
-- have been changed after migration; the pre-Step-14 application can ignore them.

START TRANSACTION;

INSERT INTO settings (setting_key, setting_value, setting_type, setting_group, description)
SELECT 'company_name', w.name, 'string', 'general', 'Legacy company name restored from workspace name.'
FROM workspaces w
WHERE w.id = (SELECT MIN(id) FROM workspaces)
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP();

INSERT INTO settings (setting_key, setting_value, setting_type, setting_group, description)
SELECT 'week_start_day',
       CASE WHEN ws.setting_value = 'sunday' THEN '0' ELSE '1' END,
       'int', 'general', 'Legacy week start restored from workspace policy.'
FROM workspace_settings ws
WHERE ws.workspace_id = (SELECT MIN(id) FROM workspaces)
  AND ws.setting_key = 'week_start'
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP();

INSERT INTO settings (setting_key, setting_value, setting_type, setting_group, description)
SELECT 'working_hours_per_day', ws.setting_value, 'string', 'general',
       'Legacy working hours restored from workspace daily capacity.'
FROM workspace_settings ws
WHERE ws.workspace_id = (SELECT MIN(id) FROM workspaces)
  AND ws.setting_key = 'daily_capacity'
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP();

INSERT INTO settings (setting_key, setting_value, setting_type, setting_group, description)
SELECT 'time_rounding_minutes', ws.setting_value, 'int', 'time',
       'Legacy rounding restored from workspace policy.'
FROM workspace_settings ws
WHERE ws.workspace_id = (SELECT MIN(id) FROM workspaces)
  AND ws.setting_key = 'time_rounding_minutes'
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP();

INSERT INTO settings (setting_key, setting_value, setting_type, setting_group, description)
SELECT 'timesheet_approval', ws.setting_value, 'bool', 'time',
       'Legacy approval switch restored from workspace policy.'
FROM workspace_settings ws
WHERE ws.workspace_id = (SELECT MIN(id) FROM workspaces)
  AND ws.setting_key = 'time_approval_enabled'
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP();

COMMIT;
