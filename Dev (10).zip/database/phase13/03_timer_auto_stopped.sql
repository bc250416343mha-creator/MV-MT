-- Phase 13 / Step 9: mark entries created by the server-side timer auto-stop.
-- Idempotent for MariaDB 11.8.

ALTER TABLE `time_entries`
    ADD COLUMN IF NOT EXISTS `auto_stopped` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_billable`;
