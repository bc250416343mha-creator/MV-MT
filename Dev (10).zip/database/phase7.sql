-- =====================================================================
--  TimeTrack: Phase 7 schema, weekly/monthly timesheets and approval
--  Run AFTER Phase 1, 2, 4, 5 and 6 on an existing database.
--  Safe to re-run: tables use IF NOT EXISTS.
--
--      mysql -u USER -p DATABASE < database/phase7.sql
--
--  Requires: users, time_entries.
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- timesheets: one row per user per period (week or month)
-- Statuses: Draft, Submitted, Approved, Rejected
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `timesheets` (
    `id`                INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `user_id`           INT UNSIGNED  NOT NULL,
    `start_date`        DATE          NOT NULL,
    `end_date`          DATE          NOT NULL,
    `total_seconds`     INT UNSIGNED  NOT NULL DEFAULT 0,
    `billable_seconds`  INT UNSIGNED  NOT NULL DEFAULT 0,
    `status`            ENUM('Draft','Submitted','Approved','Rejected') NOT NULL DEFAULT 'Draft',
    `submitted_at`      DATETIME      NULL,
    `approved_by`       INT UNSIGNED  NULL,
    `approved_at`       DATETIME      NULL,
    `rejection_reason`  VARCHAR(500)  NULL,
    `created_at`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_timesheets_user_period` (`user_id`, `start_date`, `end_date`),
    KEY `idx_timesheets_status` (`status`),
    KEY `idx_timesheets_submitted` (`submitted_at`),
    KEY `idx_timesheets_approved_by` (`approved_by`),
    CONSTRAINT `fk_timesheets_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_timesheets_approved_by`
        FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- timesheet_entries: which time entries are locked into a timesheet.
-- Foreign keys are omitted so this still creates when live time_entries.id
-- is signed INT (errno 150 on mixed signedness / engine / collation).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `timesheet_entries` (
    `timesheet_id`   INT UNSIGNED NOT NULL,
    `time_entry_id`  INT UNSIGNED NOT NULL,
    `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`timesheet_id`, `time_entry_id`),
    UNIQUE KEY `uq_timesheet_entries_entry` (`time_entry_id`),
    KEY `idx_timesheet_entries_timesheet` (`timesheet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO `permissions` (`name`, `display_name`, `module`, `description`) VALUES
    ('time.approve', 'Approve timesheets', 'time', 'Approve or reject submitted timesheets.')
ON DUPLICATE KEY UPDATE `display_name` = VALUES(`display_name`);

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 1, `id` FROM `permissions` WHERE `name` = 'time.approve';

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 2, `id` FROM `permissions` WHERE `name` = 'time.approve';

INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `setting_group`, `description`)
VALUES ('timesheet_approval', '1', 'bool', 'time', 'Require manager approval before time is billable.')
ON DUPLICATE KEY UPDATE `setting_key` = `setting_key`;
