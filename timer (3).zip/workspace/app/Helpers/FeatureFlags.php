<?php
/**
 * Server-side workspace feature switches.
 *
 * Menu hiding is not access control. Disabled modules 404; hide-* flags 403
 * regular users (employee/client) who open the URL directly.
 */

declare(strict_types=1);

final class FeatureFlagsHelper
{
    public static function bool(string $key): bool
    {
        $defaults = Workspace::DEFAULT_SETTINGS;
        if (!array_key_exists($key, $defaults)) {
            throw new InvalidArgumentException('Unknown workspace setting: ' . $key);
        }

        $default = in_array(strtolower((string) $defaults[$key]), ['1', 'true', 'yes', 'on'], true);

        try {
            $workspaceId = Workspace::currentId();
            if ($workspaceId < 1) {
                return $default;
            }

            return SettingsService::workspaceBool($workspaceId, $key, $default);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return $default;
        }
    }

    public static function timesheetEnabled(): bool
    {
        return self::bool('timesheet_enabled');
    }

    public static function schedulingEnabled(): bool
    {
        return self::bool('scheduling_enabled');
    }

    public static function timeApprovalEnabled(): bool
    {
        return self::timesheetEnabled() && self::bool('time_approval_enabled');
    }

    public static function lockTimeEnabled(): bool
    {
        return self::bool('lock_time_enabled');
    }

    public static function forceTimer(): bool
    {
        return self::bool('force_timer');
    }

    public static function allowManual(): bool
    {
        if (self::forceTimer()) {
            return false;
        }

        try {
            return SettingsService::systemBool('allow_manual_time_entries', true);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return true;
        }
    }

    public static function hideTracker(): bool
    {
        return self::bool('hide_tracker');
    }

    public static function hideProjects(): bool
    {
        return self::bool('hide_projects');
    }

    public static function hideTeam(): bool
    {
        return self::bool('hide_team');
    }

    public static function hideReports(): bool
    {
        return self::bool('hide_reports');
    }

    public static function isPrivileged(): bool
    {
        return AuthHelper::hasRole(AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER);
    }

    public static function trackerVisible(): bool
    {
        return !self::hideTracker();
    }

    public static function projectsVisible(): bool
    {
        return self::isPrivileged() || !self::hideProjects();
    }

    public static function teamVisible(): bool
    {
        if (self::isPrivileged()) {
            return true;
        }

        return !self::hideTeam() && !self::hideProjects();
    }

    public static function reportsVisible(): bool
    {
        // Once report_access exists, the per-person grants made by the admin decide.
        if (ReportAccessHelper::tableReady()) {
            return ReportAccessHelper::canView();
        }

        return self::isPrivileged() || !self::hideReports();
    }

    public static function requireTimesheet(): void
    {
        if (!self::timesheetEnabled()) {
            self::deny(404, 'timesheet');
        }
    }

    public static function requireScheduling(): void
    {
        if (!self::schedulingEnabled()) {
            self::deny(404, 'scheduling');
        }
    }

    public static function requireTimeApproval(): void
    {
        self::requireTimesheet();
        if (!self::bool('time_approval_enabled')) {
            self::deny(404, 'time_approval');
        }
    }

    public static function requireTracker(): void
    {
        if (!self::trackerVisible()) {
            self::deny(404, 'tracker');
        }
    }

    public static function requireProjects(): void
    {
        if (!self::projectsVisible()) {
            self::deny(403, 'projects');
        }
    }

    public static function requireTeam(): void
    {
        if (!self::teamVisible()) {
            self::deny(403, 'team');
        }
    }

    public static function requireReports(): void
    {
        if (!self::reportsVisible()) {
            self::deny(403, 'reports');
        }
    }

    public static function denyManualIfForced(): void
    {
        self::requireManual();
    }

    public static function requireManual(): void
    {
        if (self::forceTimer()) {
            self::deny(403, 'force_timer', 'Manual time entries are disabled because the timer is required.');
        }

        if (!self::allowManual()) {
            self::deny(403, 'allow_manual_time_entries', 'Manual time entries are turned off.');
        }
    }

    private static function deny(int $status, string $feature, string $message = ''): never
    {
        LoggerHelper::warning('Feature flag denied', [
            'user_id' => AuthHelper::id(),
            'feature' => $feature,
            'status'  => $status,
        ]);

        throw new HttpException($status, $message);
    }
}
