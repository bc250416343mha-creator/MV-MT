<?php
/**
 * Two kinds of logging:
 *
 *  1. Application log (info/warning/error/exception): daily files in storage/logs,
 *     for operators debugging problems.
 *  2. Audit trail: rows in the activity_logs table recording WHO did WHAT to which
 *     record, for accountability. audit_logs is a read-only view over that table.
 *
 * SECURITY: never log passwords, tokens, or full request bodies. Newlines are stripped
 * from messages and context so an attacker cannot forge extra log lines (log injection).
 *
 * Phase 9: audits capture a logical `module`, entity_id and old/new value
 * snapshots. The original audit() signature is preserved; the new logEvent()/named
 * helpers are the preferred way to record the seven business events.
 */

declare(strict_types=1);

final class LoggerHelper
{
    public const MODULE_PROJECT  = 'project';
    public const MODULE_TASK     = 'task';
    public const MODULE_SCHEDULE = 'schedule';
    public const MODULE_TIME     = 'time';
    public const MODULE_TIMESHEET = 'timesheet';
    public const MODULE_AUTH     = 'auth';
    public const MODULE_USER     = 'user';
    public const MODULE_SETTINGS = 'settings';
    public const MODULE_INVITE   = 'invite';
    public const MODULE_MAIL     = 'mail';

    private const RESERVED_META_KEYS = ['module', 'record_id', 'entity_id', 'old', 'old_value', 'new', 'new_value'];

    /** @param array<string, mixed> $context */
    public static function info(string $message, array $context = []): void
    {
        self::write('INFO', $message, $context);
    }

    /** @param array<string, mixed> $context */
    public static function warning(string $message, array $context = []): void
    {
        self::write('WARNING', $message, $context);
    }

    /** @param array<string, mixed> $context */
    public static function error(string $message, array $context = []): void
    {
        self::write('ERROR', $message, $context);
    }

    /** Expected / noisy failures that must not flood the production log. */
    public static function debug(string $message, array $context = []): void
    {
        if (!Config::get('app.debug', false)) {
            return;
        }
        self::write('DEBUG', $message, $context);
    }

    /** Log an exception with file and line; the stack trace is included only when debug is on. */
    public static function exception(Throwable $e): void
    {
        $context = [
            'type' => $e::class,
            'file' => basename($e->getFile()) . ':' . $e->getLine(),
        ];

        if (Config::get('app.debug', false)) {
            $context['trace'] = $e->getTraceAsString();
        }

        self::write('ERROR', $e->getMessage(), $context);
    }

    /**
     * Record a business event in activity_logs (legacy signature).
     *
     * Recognised $meta keys (not stored in the meta JSON): module, record_id /
     * entity_id, old / old_value and new / new_value.
     *
     * @param array<string, mixed> $meta Small JSON-serialisable details (no secrets)
     */
    public static function audit(string $action, ?string $entityType = null, ?int $entityId = null, array $meta = []): void
    {
        $module   = isset($meta['module']) ? substr((string) $meta['module'], 0, 60) : $entityType;
        $entityId = isset($meta['entity_id']) ? (int) $meta['entity_id']
            : (isset($meta['record_id']) ? (int) $meta['record_id'] : $entityId);
        $old      = $meta['old'] ?? $meta['old_value'] ?? null;
        $new      = $meta['new'] ?? $meta['new_value'] ?? null;

        foreach (self::RESERVED_META_KEYS as $key) {
            unset($meta[$key]);
        }

        self::logEvent($action, $module, $entityId, $old, $new, $meta, $entityType, $entityId);
    }

    /**
     * Insert one audit row. Never throws: auditing must not break the user's action.
     *
     * @param mixed                 $oldValue Snapshot before the change (array => JSON)
     * @param mixed                 $newValue Snapshot after the change (array => JSON)
     * @param array<string, mixed>  $meta     Extra details (no secrets)
     */
    public static function logEvent(
        string $action,
        ?string $module = null,
        ?int $recordId = null,
        mixed $oldValue = null,
        mixed $newValue = null,
        array $meta = [],
        ?string $entityType = null,
        ?int $entityId = null
    ): void {
        try {
            $request = Request::current();
            $id      = $entityId ?? $recordId;

            Database::execute(
                'INSERT INTO activity_logs
                    (user_id, action, module, entity_type, entity_id,
                     ip_address, user_agent, meta, old_value, new_value, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP())',
                [
                    AuthHelper::id(),
                    substr($action, 0, 100),
                    $module !== null && $module !== '' ? substr($module, 0, 60) : null,
                    $entityType !== null && $entityType !== '' ? substr($entityType, 0, 60) : $module,
                    $id,
                    $request->ip(),
                    $request->userAgent(),
                    $meta === [] ? null : self::json($meta),
                    self::json($oldValue),
                    self::json($newValue),
                ]
            );
        } catch (Throwable $e) {
            self::write('ERROR', 'Audit write failed', [
                'action' => $action,
                'reason' => $e->getMessage(),
            ]);
        }
    }

    /* ------------------------------------------------------------------
     * Named business events (Phase 9). Thin wrappers over logEvent().
     * ------------------------------------------------------------------ */

    /** @param array<string, mixed> $snapshot */
    public static function projectCreated(int $projectId, array $snapshot): void
    {
        self::logEvent('project.created', self::MODULE_PROJECT, $projectId, null, $snapshot);
    }

    /** @param array<string, mixed> $before @param array<string, mixed> $after */
    public static function projectEdited(int $projectId, array $before, array $after): void
    {
        self::logEvent('project.updated', self::MODULE_PROJECT, $projectId, $before, $after);
    }

    public static function taskAssigned(int $taskId, int $assigneeId, string $taskName, int $projectId): void
    {
        self::logEvent('task.assigned', self::MODULE_TASK, $taskId, null, [
            'task'      => $taskName,
            'assignee'  => $assigneeId,
            'project_id' => $projectId,
        ]);
    }

    /** @param array<string, mixed> $before @param array<string, mixed> $after */
    public static function scheduleChanged(int $scheduleId, array $before, array $after): void
    {
        self::logEvent('schedule.changed', self::MODULE_SCHEDULE, $scheduleId, $before, $after);
    }

    /** @param list<array<string, mixed>> $conflicts */
    public static function scheduleConflictOverridden(int $scheduleId, array $conflicts): void
    {
        self::logEvent('schedule.conflict_overridden', self::MODULE_SCHEDULE, $scheduleId, null, [
            'conflicts' => array_map(
                static fn (array $c): array => [
                    'id'    => (int) ($c['id'] ?? 0),
                    'start' => (string) ($c['start_datetime'] ?? ''),
                    'end'   => (string) ($c['end_datetime'] ?? ''),
                ],
                $conflicts
            ),
        ]);
    }

    public static function timerStarted(int $timerId, int $projectId, ?int $taskId): void
    {
        self::logEvent('timer.started', self::MODULE_TIME, $timerId, null, [
            'project_id' => $projectId,
            'task_id'    => $taskId,
        ]);
    }

    public static function timerStopped(int $entryId, int $seconds): void
    {
        self::logEvent('timer.stopped', self::MODULE_TIME, $entryId, null, ['seconds' => $seconds]);
    }

    public static function timesheetSubmitted(int $timesheetId, int $userId, string $period, int $totalSeconds): void
    {
        self::logEvent('timesheet.submitted', self::MODULE_TIMESHEET, $timesheetId, null, [
            'user_id'       => $userId,
            'period'        => $period,
            'total_seconds' => $totalSeconds,
        ]);
    }

    public static function timesheetApproved(int $timesheetId, int $userId, string $period): void
    {
        self::logEvent('timesheet.approved', self::MODULE_TIMESHEET, $timesheetId, ['status' => 'Submitted'], [
            'status'  => 'Approved',
            'user_id' => $userId,
            'period'  => $period,
        ]);
    }

    public static function timesheetRejected(int $timesheetId, int $userId, string $period, string $reason): void
    {
        self::logEvent('timesheet.rejected', self::MODULE_TIMESHEET, $timesheetId, ['status' => 'Submitted'], [
            'status'  => 'Rejected',
            'user_id' => $userId,
            'period'  => $period,
            'reason'  => mb_substr($reason, 0, 200, 'UTF-8'),
        ]);
    }

    /* ------------------------------------------------------------------ internals */

    private static function json(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (is_array($value) || is_object($value)) {
            try {
                return substr((string) json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE), 0, 65500);
            } catch (Throwable) {
                return null;
            }
        }

        return substr((string) $value, 0, 65500);
    }

    /** @param array<string, mixed> $context */
    private static function write(string $level, string $message, array $context): void
    {
        $dir = STORAGE_PATH . '/logs';

        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            error_log("[{$level}] {$message}"); // last resort: PHP's own error log
            return;
        }

        $line = sprintf(
            "[%s] %s %s%s\n",
            gmdate('Y-m-d H:i:s') . ' UTC',
            $level,
            self::clean($message),
            $context === [] ? '' : ' ' . self::clean((string) json_encode($context, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR))
        );

        @file_put_contents($dir . '/app-' . gmdate('Y-m-d') . '.log', $line, FILE_APPEND | LOCK_EX);
    }

    /** Collapse CR/LF so one log call is always exactly one line. */
    private static function clean(string $text): string
    {
        return str_replace(["\r", "\n"], ['\r', '\n'], $text);
    }
}
