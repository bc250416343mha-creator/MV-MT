<?php
/**
 * ACCESS tab: Visibility (Private / Public), "Add members", Users table (NAME / ROLE).
 *
 * @var array<string, mixed> $project
 * @var list<array<string, mixed>> $members
 * @var list<array<string, mixed>> $candidates users that are not on the project yet
 * @var bool $canManageMembers
 * @var bool $extrasReady
 */

$projectId = (int) $project['id'];
$isPublic  = !empty($project['is_public']);
$roleLabel = static fn (string $role): string => ucfirst($role);
$managerId = (int) ($project['manager_id'] ?? 0);
?>
<section class="cf-card cf-pad">
    <h2 class="cf-h2">Visibility</h2>
    <p class="cf-hint" id="cf-visibility-hint" data-public="Everyone can track time on public Projects." data-private="Only project members can track time on private Projects.">
        <?= $isPublic ? 'Everyone can track time on public Projects.' : 'Only project members can track time on private Projects.' ?>
    </p>
    <div class="cf-radios" role="radiogroup" aria-label="Project visibility"
         data-visibility-url="<?= e(url('/projects/' . $projectId . '/visibility')) ?>">
        <?php $disabled = (!$canManageMembers || !$extrasReady) ? ' disabled' : ''; ?>
        <label class="cf-radio">
            <input type="radio" name="visibility" value="private"<?= !$isPublic ? ' checked' : '' ?><?= $disabled ?>>
            <span class="cf-radio-dot"></span><span>Private</span>
        </label>
        <label class="cf-radio">
            <input type="radio" name="visibility" value="public"<?= $isPublic ? ' checked' : '' ?><?= $disabled ?>>
            <span class="cf-radio-dot"></span><span>Public</span>
        </label>
    </div>
    <?php if (!$extrasReady): ?>
        <p class="cf-hint cf-warn mt-2 mb-0">Run <code>database/UPGRADE_LIVE.sql</code> to enable project visibility.</p>
    <?php endif; ?>

    <hr class="cf-hr">

    <?php if ($canManageMembers): ?>
        <button type="button" class="cf-link-btn" data-bs-toggle="modal" data-bs-target="#addMembersModal">
            <span class="cf-plus" aria-hidden="true"><i class="fa-solid fa-plus"></i></span>Add members
        </button>
    <?php endif; ?>

    <div class="cf-band cf-band-spaced"><span>Users</span></div>
    <div class="cf-table-wrap">
        <table class="cf-table cf-access-table">
            <thead>
                <tr>
                    <th class="cf-col-name">Name</th>
                    <th class="cf-col-role">Role</th>
                    <?php if ($canManageMembers): ?><th class="cf-col-actions" aria-label="Actions"></th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if ($members === []): ?>
                    <tr><td colspan="3" class="cf-empty">No one is assigned yet.</td></tr>
                <?php endif; ?>
                <?php foreach ($members as $member): ?>
                    <?php
                    $uid       = (int) $member['user_id'];
                    $isManager = $uid === $managerId;
                    $role      = strtolower((string) $member['project_role']);
                    ?>
                    <tr>
                        <td class="cf-col-name" data-label="Name"><?= e($member['name']) ?></td>
                        <td class="cf-col-role" data-label="Role"><?= e($roleLabel($role)) ?><?= $isManager ? ' <span class="cf-muted">(project manager)</span>' : '' ?></td>
                        <?php if ($canManageMembers): ?>
                            <td class="cf-col-actions" data-label="Actions">
                                <div class="dropdown">
                                    <button type="button" class="cf-kebab" data-bs-toggle="dropdown" data-bs-popper-config='{"strategy":"fixed"}' aria-expanded="false" aria-label="Member actions">
                                        <span class="cf-dots" aria-hidden="true"><i></i><i></i><i></i></span>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end cf-menu">
                                        <?php foreach (ProjectMember::ROLES as $r): ?>
                                            <?php if ($r === $role || ($isManager && $r !== 'manager')) { continue; } ?>
                                            <li>
                                                <form method="post" action="<?= e(url('/projects/' . $projectId . '/members/' . $uid . '/role')) ?>" data-single-submit>
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="role" value="<?= e($r) ?>">
                                                    <button type="submit" class="dropdown-item">Make <?= e(strtolower($roleLabel($r))) ?></button>
                                                </form>
                                            </li>
                                        <?php endforeach; ?>
                                        <?php if (!$isManager): ?>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <form method="post" action="<?= e(url('/projects/' . $projectId . '/members/' . $uid . '/remove')) ?>"
                                                      data-confirm="Remove <?= e($member['name']) ?> from this project?">
                                                    <?= csrf_field() ?>
                                                    <button type="submit" class="dropdown-item text-danger">Remove</button>
                                                </form>
                                            </li>
                                        <?php else: ?>
                                            <li><span class="dropdown-item-text cf-muted small">Change the manager in Settings.</span></li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<?php if ($canManageMembers): ?>
<div class="modal fade cf-modal" id="addMembersModal" tabindex="-1" aria-labelledby="addMembersTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" action="<?= e(url('/projects/' . $projectId . '/members/add')) ?>" class="modal-content" data-single-submit>
            <?= csrf_field() ?>
            <div class="modal-header">
                <h2 class="modal-title" id="addMembersTitle">Add members</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if ($candidates === []): ?>
                    <p class="cf-hint mb-0">Everyone is already on this project.</p>
                <?php else: ?>
                    <div class="cf-search cf-search-block mb-3">
                        <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                        <input type="search" placeholder="Search by name" data-filter-list="#cf-candidates" aria-label="Search people">
                    </div>
                    <div class="cf-candidates" id="cf-candidates">
                        <?php foreach ($candidates as $user): ?>
                            <label class="cf-check" data-filter-text="<?= e(strtolower((string) $user['name'] . ' ' . (string) ($user['job_title'] ?? ''))) ?>">
                                <input type="checkbox" name="user_ids[]" value="<?= (int) $user['id'] ?>">
                                <span><?= e($user['name']) ?><?php if (!empty($user['job_title'])): ?> <span class="cf-muted">· <?= e($user['job_title']) ?></span><?php endif; ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <label for="add-role" class="cf-label mt-3">Role</label>
                    <select id="add-role" name="role" class="cf-select">
                        <option value="member">Member</option>
                        <option value="manager">Manager</option>
                        <option value="viewer">Viewer</option>
                    </select>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="cf-btn cf-btn-ghost" data-bs-dismiss="modal">Cancel</button>
                <?php if ($candidates !== []): ?><button type="submit" class="cf-btn cf-btn-primary">Add</button><?php endif; ?>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
