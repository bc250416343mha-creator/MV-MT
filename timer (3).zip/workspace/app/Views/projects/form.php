<?php
/**
 * Shared project create/edit fields.
 *
 * @var array<string, mixed>         $project
 * @var list<array<string, mixed>>   $clients
 * @var list<array<string, mixed>>   $managers
 * @var list<array<string, mixed>>   $users
 * @var list<string>                 $statuses
 * @var list<string>                 $priorities
 * @var list<int>                    $selectedIds
 * @var array<int, string>           $memberRoles
 * @var string                       $formAction
 * @var string                       $submitLabel
 */

$val = static fn (string $key): string => old($key, (string) ($project[$key] ?? ''));
$selectedClient  = old('client_id', (string) ($project['client_id'] ?? ''));
$selectedManager = old('manager_id', (string) ($project['manager_id'] ?? ''));
$selectedStatus  = old('status', (string) ($project['status'] ?? 'Planning'));
$selectedPriority = old('priority', (string) ($project['priority'] ?? 'Medium'));
$billable = old('is_billable', (string) ((int) ($project['is_billable'] ?? 1)));
$selectedIds = $selectedIds ?? [];
$memberRoles = $memberRoles ?? [];
?>
<form method="post" action="<?= e($formAction) ?>" novalidate data-single-submit>
    <?= csrf_field() ?>

    <section class="panel mb-4">
        <div class="panel-head">
            <h2 class="panel-title">Project details</h2>
        </div>
        <div class="panel-body">
            <div class="row g-3">
                <div class="col-md-8">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" id="name" name="name" maxlength="160" required
                           class="form-control<?= field_error('name') ? ' is-invalid' : '' ?>"
                           value="<?= e($val('name')) ?>">
                    <?php if (field_error('name')): ?><div class="invalid-feedback"><?= e(field_error('name')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-4">
                    <label for="project_code" class="form-label">Code</label>
                    <input type="text" id="project_code" name="project_code" maxlength="40"
                           class="form-control<?= field_error('project_code') ? ' is-invalid' : '' ?>"
                           value="<?= e($val('project_code')) ?>" aria-describedby="code-help">
                    <?php if (field_error('project_code')): ?><div class="invalid-feedback"><?= e(field_error('project_code')) ?></div><?php endif; ?>
                    <div id="code-help" class="form-text">Leave blank on create to auto-assign.</div>
                </div>
                <div class="col-md-6">
                    <label for="client_id" class="form-label">Client</label>
                    <select id="client_id" name="client_id" required class="form-select<?= field_error('client_id') ? ' is-invalid' : '' ?>">
                        <option value="">Select a client</option>
                        <?php foreach ($clients as $client): ?>
                            <option value="<?= (int) $client['id'] ?>"<?= (string) $client['id'] === (string) $selectedClient ? ' selected' : '' ?>>
                                <?= e($client['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (field_error('client_id')): ?><div class="invalid-feedback"><?= e(field_error('client_id')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label for="manager_id" class="form-label">Manager</label>
                    <select id="manager_id" name="manager_id" class="form-select<?= field_error('manager_id') ? ' is-invalid' : '' ?>">
                        <option value="">Unassigned</option>
                        <?php foreach ($managers as $manager): ?>
                            <option value="<?= (int) $manager['id'] ?>"<?= (string) $manager['id'] === (string) $selectedManager ? ' selected' : '' ?>>
                                <?= e($manager['name']) ?> (<?= e($manager['role']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (field_error('manager_id')): ?><div class="invalid-feedback"><?= e(field_error('manager_id')) ?></div><?php endif; ?>
                </div>
                <div class="col-12">
                    <label for="description" class="form-label">Description</label>
                    <textarea id="description" name="description" rows="4" maxlength="5000"
                              class="form-control<?= field_error('description') ? ' is-invalid' : '' ?>"><?= e($val('description')) ?></textarea>
                    <?php if (field_error('description')): ?><div class="invalid-feedback"><?= e(field_error('description')) ?></div><?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="panel mb-4">
        <div class="panel-head">
            <h2 class="panel-title">Schedule and billing</h2>
        </div>
        <div class="panel-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" required class="form-select<?= field_error('status') ? ' is-invalid' : '' ?>">
                        <?php foreach ($statuses as $status): ?>
                            <option value="<?= e($status) ?>"<?= $status === $selectedStatus ? ' selected' : '' ?>><?= e($status) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (field_error('status')): ?><div class="invalid-feedback"><?= e(field_error('status')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-3">
                    <label for="priority" class="form-label">Priority</label>
                    <select id="priority" name="priority" required class="form-select<?= field_error('priority') ? ' is-invalid' : '' ?>">
                        <?php foreach ($priorities as $priority): ?>
                            <option value="<?= e($priority) ?>"<?= $priority === $selectedPriority ? ' selected' : '' ?>><?= e($priority) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (field_error('priority')): ?><div class="invalid-feedback"><?= e(field_error('priority')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-3">
                    <label for="start_date" class="form-label">Start date</label>
                    <input type="date" id="start_date" name="start_date"
                           class="form-control<?= field_error('start_date') ? ' is-invalid' : '' ?>"
                           value="<?= e($val('start_date')) ?>">
                    <?php if (field_error('start_date')): ?><div class="invalid-feedback"><?= e(field_error('start_date')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-3">
                    <label for="due_date" class="form-label">Due date</label>
                    <input type="date" id="due_date" name="due_date"
                           class="form-control<?= field_error('due_date') ? ' is-invalid' : '' ?>"
                           value="<?= e($val('due_date')) ?>">
                    <?php if (field_error('due_date')): ?><div class="invalid-feedback"><?= e(field_error('due_date')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-3">
                    <label for="estimated_hours" class="form-label">Estimated hours</label>
                    <input type="number" id="estimated_hours" name="estimated_hours" min="0" step="0.25"
                           class="form-control<?= field_error('estimated_hours') ? ' is-invalid' : '' ?>"
                           value="<?= e($val('estimated_hours')) ?>">
                    <?php if (field_error('estimated_hours')): ?><div class="invalid-feedback"><?= e(field_error('estimated_hours')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-3">
                    <label for="budget" class="form-label">Budget</label>
                    <input type="number" id="budget" name="budget" min="0" step="0.01"
                           class="form-control<?= field_error('budget') ? ' is-invalid' : '' ?>"
                           value="<?= e($val('budget')) ?>">
                    <?php if (field_error('budget')): ?><div class="invalid-feedback"><?= e(field_error('budget')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-3">
                    <label for="hourly_rate" class="form-label">Hourly rate</label>
                    <input type="number" id="hourly_rate" name="hourly_rate" min="0" step="0.01"
                           class="form-control<?= field_error('hourly_rate') ? ' is-invalid' : '' ?>"
                           value="<?= e($val('hourly_rate')) ?>">
                    <?php if (field_error('hourly_rate')): ?><div class="invalid-feedback"><?= e(field_error('hourly_rate')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <div class="form-check mb-2">
                        <input type="hidden" name="is_billable" value="0">
                        <input class="form-check-input<?= field_error('is_billable') ? ' is-invalid' : '' ?>" type="checkbox"
                               id="is_billable" name="is_billable" value="1"<?= $billable === '1' ? ' checked' : '' ?>>
                        <label class="form-check-label" for="is_billable">Billable</label>
                        <?php if (field_error('is_billable')): ?><div class="invalid-feedback"><?= e(field_error('is_billable')) ?></div><?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if (PermissionHelper::has('projects.manage_members')): ?>
        <section class="panel mb-4">
            <div class="panel-head">
                <h2 class="panel-title">Assigned members</h2>
            </div>
            <div class="panel-body">
                <?php if ($users === []): ?>
                    <p class="text-secondary mb-0">No active users are available to assign.</p>
                <?php else: ?>
                    <div class="member-picker">
                        <?php foreach ($users as $user): ?>
                            <?php
                            $uid = (int) $user['id'];
                            $checked = in_array($uid, $selectedIds, true);
                            $role = strtolower((string) ($memberRoles[$uid] ?? 'member'));
                            ?>
                            <label class="member-pick">
                                <input type="checkbox" name="member_ids[]" value="<?= $uid ?>"<?= $checked ? ' checked' : '' ?>>
                                <span class="member-pick-body">
                                    <strong><?= e($user['name']) ?></strong>
                                    <span class="text-secondary small"><?= e($user['job_title'] ?: $user['role']) ?></span>
                                </span>
                                <select name="member_roles[<?= $uid ?>]" class="form-select form-select-sm" aria-label="Role for <?= e($user['name']) ?>">
                                    <option value="manager"<?= $role === 'manager' ? ' selected' : '' ?>>Manager</option>
                                    <option value="member"<?= $role === 'member' ? ' selected' : '' ?>>Member</option>
                                    <option value="viewer"<?= $role === 'viewer' ? ' selected' : '' ?>>Viewer</option>
                                </select>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary"><?= e($submitLabel) ?></button>
        <a class="btn btn-outline-secondary" href="<?= e(url('/projects')) ?>">Cancel</a>
    </div>
</form>
