<?php
/**
 * Project page header (breadcrumb, title, client, star + menu) followed by the tabs.
 *
 * @var array<string, mixed> $project
 * @var string $activeProjectTab
 * @var bool $isFavorite
 * @var bool $canArchive
 * @var bool $canDelete
 */

$projectId = (int) $project['id'];
$isFavorite = !empty($isFavorite);
?>
<div class="cf-head">
    <a class="cf-breadcrumb" href="<?= e(url('/projects')) ?>">Projects</a>
    <div class="cf-title-row">
        <div class="cf-title-block">
            <h1 class="cf-title"><?= e($project['name']) ?></h1>
            <p class="cf-subtitle"><?= e($project['client_name'] ?? '') ?></p>
        </div>
        <div class="cf-title-actions">
            <form method="post" action="<?= e(url('/projects/' . $projectId . '/favorite')) ?>" class="m-0">
                <?= csrf_field() ?>
                <input type="hidden" name="tab" value="<?= e((string) ($activeProjectTab ?? '')) ?>">
                <button type="submit" class="cf-icon-btn<?= $isFavorite ? ' is-on' : '' ?>"
                        aria-label="<?= $isFavorite ? 'Remove from favorites' : 'Add to favorites' ?>"
                        title="<?= $isFavorite ? 'Remove from favorites' : 'Add to favorites' ?>">
                    <i class="<?= $isFavorite ? 'fa-solid' : 'fa-regular' ?> fa-star" aria-hidden="true"></i>
                </button>
            </form>
            <div class="dropdown">
                <button type="button" class="cf-icon-btn" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Project actions">
                    <span class="cf-dots" aria-hidden="true"><i></i><i></i><i></i></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end cf-menu">
                    <?php if (FeatureFlagsHelper::reportsVisible()): ?>
                    <li><a class="dropdown-item" href="<?= e(url('/projects/' . $projectId . '/dashboard')) ?>">Project dashboard</a></li>
                    <?php endif; ?>
                    <?php if (!empty($canArchive) && (string) $project['status'] !== 'Archived'): ?>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="post" action="<?= e(url('/projects/' . $projectId . '/archive')) ?>"
                                  data-confirm="Archive <?= e($project['name']) ?>? It will be hidden from the active project list.">
                                <?= csrf_field() ?>
                                <button type="submit" class="dropdown-item">Archive project</button>
                            </form>
                        </li>
                    <?php elseif (!empty($canDelete) && (string) $project['status'] === 'Archived'): ?>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="post" action="<?= e(url('/projects/' . $projectId . '/delete')) ?>"
                                  data-confirm="Permanently delete <?= e($project['name']) ?>? This is only allowed when the project has no time entries and no timers.">
                                <?= csrf_field() ?>
                                <button type="submit" class="dropdown-item text-danger">Delete project</button>
                            </form>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php require APP_PATH . '/Views/projects/tabs.php'; ?>
