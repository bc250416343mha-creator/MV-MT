<?php
/**
 * Team page (Phase 14): people directory with weekly workload.
 *
 * @var list<array<string, mixed>> $rows
 * @var array<string, mixed>       $summary
 * @var array<string, mixed>       $filters   q, role, status, project, sort
 * @var list<array<string, mixed>> $projectOptions
 * @var DateTimeImmutable          $weekStart
 * @var DateTimeImmutable          $weekEnd
 * @var string                     $prevWeek
 * @var string                     $nextWeek
 * @var bool                       $isThisWeek
 * @var float                      $capacityHours
 * @var bool                       $planning
 * @var bool                       $canWorkload
 * @var int                        $viewerId
 */

$hours    = static fn (int $seconds): string => number_format($seconds / 3600, 1);
$capLabel = rtrim(rtrim(number_format($capacityHours, 1), '0'), '.');
$week     = $weekStart->format('Y-m-d');

$weekEndShown = $weekEnd->modify('-1 day');
$weekLabel    = $weekStart->format('M j') . ' – ' . $weekEndShown->format('M j, Y');

$query = static function (array $override) use ($filters, $week): string {
    $params = array_merge([
        'week'    => $week,
        'q'       => $filters['q'],
        'role'    => $filters['role'],
        'status'  => $filters['status'],
        'project' => $filters['project'],
        'sort'    => $filters['sort'],
    ], $override);

    return url('/team?' . http_build_query(array_filter($params, static fn ($v): bool => $v !== '' && $v !== 0 && $v !== '0')));
};

require __DIR__ . '/_styles.php';
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Team</h2>
        <p class="page-lead">People, their projects and weekly workload.</p>
    </div>
    <?php if ($canWorkload): ?>
        <div class="tm-week" role="group" aria-label="Choose week">
            <a class="btn btn-outline-secondary" href="<?= e($query(['week' => $prevWeek])) ?>" aria-label="Previous week"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i></a>
            <span class="tm-week-label"><?= e($weekLabel) ?></span>
            <a class="btn btn-outline-secondary" href="<?= e($query(['week' => $nextWeek])) ?>" aria-label="Next week"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i></a>
            <?php if (!$isThisWeek): ?>
                <a class="btn btn-outline-secondary" href="<?= e($query(['week' => ''])) ?>">This week</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php if ($canWorkload): ?>
    <div class="kpi-grid mb-4">
        <article class="kpi-card">
            <p class="kpi-label">People</p>
            <p class="kpi-value"><?= (int) $summary['members'] ?></p>
            <p class="kpi-sub"><?= (int) $summary['available'] ?> with spare capacity</p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label"><?= $planning ? 'Planned' : 'Tracked' ?> this week</p>
            <p class="kpi-value"><?= e($hours((int) ($planning ? $summary['planned'] : $summary['tracked']))) ?>h</p>
            <p class="kpi-sub"><?= (int) $summary['avg_percent'] ?>% average of <?= e($capLabel) ?>h</p>
        </article>
        <?php if ($planning): ?>
            <article class="kpi-card">
                <p class="kpi-label">Tracked so far</p>
                <p class="kpi-value"><?= e($hours((int) $summary['tracked'])) ?>h</p>
                <p class="kpi-sub">This week</p>
            </article>
        <?php endif; ?>
        <article class="kpi-card">
            <p class="kpi-label">Over capacity</p>
            <p class="kpi-value"><?= (int) $summary['over'] ?></p>
            <p class="kpi-sub"><?= (int) $summary['overdue'] ?> overdue task<?= (int) $summary['overdue'] === 1 ? '' : 's' ?></p>
        </article>
    </div>
<?php endif; ?>

<form method="get" action="<?= e(url('/team')) ?>" class="filter-bar">
    <input type="hidden" name="week" value="<?= e($week) ?>">
    <div class="filter-search">
        <label for="tm-q" class="visually-hidden">Search people</label>
        <input type="search" id="tm-q" name="q" class="form-control" placeholder="Search name, email or title" value="<?= e((string) $filters['q']) ?>">
    </div>
    <div>
        <label for="tm-project" class="visually-hidden">Project</label>
        <select id="tm-project" name="project" class="form-select">
            <option value="0">All projects</option>
            <?php foreach ($projectOptions as $project): ?>
                <option value="<?= (int) $project['id'] ?>"<?= (int) $filters['project'] === (int) $project['id'] ? ' selected' : '' ?>><?= e((string) $project['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="tm-role" class="visually-hidden">Role</label>
        <select id="tm-role" name="role" class="form-select">
            <option value="">All roles</option>
            <?php foreach (['admin' => 'Admin', 'manager' => 'Manager', 'employee' => 'Employee'] as $value => $label): ?>
                <option value="<?= e($value) ?>"<?= $filters['role'] === $value ? ' selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="tm-status" class="visually-hidden">Status</label>
        <select id="tm-status" name="status" class="form-select">
            <?php foreach (['active' => 'Active', 'inactive' => 'Inactive', 'suspended' => 'Suspended', 'all' => 'All statuses'] as $value => $label): ?>
                <option value="<?= e($value) ?>"<?= $filters['status'] === $value ? ' selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="tm-sort" class="visually-hidden">Sort</label>
        <select id="tm-sort" name="sort" class="form-select">
            <option value="name"<?= $filters['sort'] === 'name' ? ' selected' : '' ?>>Sort: Name</option>
            <?php if ($canWorkload): ?>
                <option value="load"<?= $filters['sort'] === 'load' ? ' selected' : '' ?>>Sort: Workload</option>
            <?php endif; ?>
            <option value="projects"<?= $filters['sort'] === 'projects' ? ' selected' : '' ?>>Sort: Projects</option>
        </select>
    </div>
    <button type="submit" class="btn btn-outline-secondary">Filter</button>
</form>

<section class="panel">
    <div class="panel-head"><h2 class="panel-title">People <span class="count-pill"><?= count($rows) ?></span></h2></div>
    <?php if ($rows === []): ?>
        <div class="empty-state"><i class="fa-solid fa-users" aria-hidden="true"></i><p>No people match these filters.</p></div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table table-stack mb-0">
                <thead>
                    <tr>
                        <th>Person</th>
                        <th>Role</th>
                        <th>Projects</th>
                        <?php if ($canWorkload): ?>
                            <th>Workload</th>
                            <th>Open tasks</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $row): ?>
                        <?php
                        $initial  = mb_strtoupper(mb_substr((string) $row['name'], 0, 1, 'UTF-8'), 'UTF-8');
                        $isSelf   = (int) $row['id'] === $viewerId;
                        $projects = $row['projects'];
                        $shown    = array_slice($projects, 0, 3);
                        $more     = count($projects) - count($shown);
                        ?>
                        <tr>
                            <td data-label="Person">
                                <div class="tm-person">
                                    <span class="avatar" aria-hidden="true"><?= e($initial) ?></span>
                                    <div>
                                        <a class="tm-name" href="<?= e(url('/team/' . (int) $row['id'] . '?week=' . $week)) ?>"><?= e((string) $row['name']) ?><?= $isSelf ? ' (you)' : '' ?></a>
                                        <span class="tm-sub"><?= e((string) ($row['job_title'] ?: $row['email'])) ?></span>
                                    </div>
                                </div>
                            </td>
                            <td data-label="Role">
                                <span class="role-pill role-<?= e(strtolower((string) $row['role'])) ?>"><?= e((string) $row['role_name']) ?></span>
                                <?php if ($row['status'] !== 'active'): ?>
                                    <span class="status-badge status-inactive"><?= e(ucfirst((string) $row['status'])) ?></span>
                                <?php endif; ?>
                            </td>
                            <td data-label="Projects">
                                <?php if ($projects === []): ?>
                                    <span class="tm-muted">–</span>
                                <?php else: ?>
                                    <div class="tm-chips">
                                        <?php foreach ($shown as $project): ?>
                                            <a class="tm-chip<?= ($project['project_role'] ?? '') === 'manager' ? ' is-manager' : '' ?>" href="<?= e(url('/projects/' . (int) $project['project_id'])) ?>">
                                                <span class="tm-dot" aria-hidden="true"></span><?= e((string) $project['name']) ?>
                                            </a>
                                        <?php endforeach; ?>
                                        <?php if ($more > 0): ?><span class="tm-chip-more">+<?= (int) $more ?> more</span><?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <?php if ($canWorkload): ?>
                                <td data-label="Workload">
                                    <?php if (!empty($row['has_load'])): ?>
                                        <div class="tm-load">
                                            <div class="tm-load-top">
                                                <span><?= e($hours((int) $row['load_seconds'])) ?>h <span class="tm-muted">of <?= e($capLabel) ?>h</span></span>
                                                <span class="tm-state is-<?= e((string) $row['load_state']) ?>"><?= e((string) $row['load_label']) ?></span>
                                            </div>
                                            <div class="tm-bar is-<?= e((string) $row['load_state']) ?>"><span style="width:<?= min(100, max(0, (int) $row['load_percent'])) ?>%"></span></div>
                                        </div>
                                    <?php else: ?>
                                        <span class="tm-muted">–</span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="Open tasks" class="tm-tasks">
                                    <?php if (!empty($row['has_load'])): ?>
                                        <?= (int) $row['open_tasks'] ?>
                                        <?php if ((int) $row['overdue'] > 0): ?><b class="is-overdue">(<?= (int) $row['overdue'] ?> overdue)</b><?php endif; ?>
                                    <?php else: ?>
                                        <span class="tm-muted">–</span>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
