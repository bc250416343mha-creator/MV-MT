<?php
declare(strict_types=1);

$me = AuthHelper::user() ?? ['name' => '', 'email' => '', 'role' => ''];
$current = Request::current()->path();
$appName = SettingsService::appName();
$groups = SidebarHelper::visibleGroups();
$navPaths = [];
foreach ($groups as $items) {
    foreach ($items as $item) {
        $navPaths[] = (string) $item['path'];
    }
}
if (PermissionHelper::has('time.track')) { $navPaths[] = '/agent'; }
$navPaths[] = '/profile';
$activePath = SidebarHelper::activePath($current, $navPaths);
$isActive = static fn (string $path): bool => $activePath === $path;
$initials = '';
foreach (array_slice(preg_split('/\s+/', trim((string) $me['name'])) ?: [], 0, 2) as $part) {
    $initials .= mb_strtoupper(mb_substr($part, 0, 1, 'UTF-8'), 'UTF-8');
}
$initials = $initials !== '' ? $initials : '?';
$unreadCount = SidebarHelper::unreadCount();
$recentNotifications = SidebarHelper::recentNotifications(6);
$pendingCount = SidebarHelper::pendingApprovalCount();
$reviewCount = SidebarHelper::pendingReviewCount();
?>
<aside class="app-sidebar offcanvas-lg offcanvas-start" tabindex="-1" id="appSidebar" aria-label="Main navigation">
    <div class="sidebar-brand">
        <a href="<?= e(url('/dashboard')) ?>" class="brand-link">
            <?= BrandingHelper::mark() ?>
            <span class="brand-name"><?= e($appName) ?></span>
        </a>
        <button type="button" class="btn-close d-lg-none" data-bs-dismiss="offcanvas" data-bs-target="#appSidebar" aria-label="Close menu"></button>
    </div>
    <?php $currentWorkspace = class_exists('Workspace') ? Workspace::current() : null; ?>
    <div class="workspace-switcher dropdown">
        <span class="workspace-dot" aria-hidden="true"></span>
        <span class="workspace-name"><?= e((string)($currentWorkspace['name'] ?? $appName)) ?></span>
        <?php if (PermissionHelper::has('workspace.manage')): ?>
            <button type="button" class="workspace-more" data-bs-toggle="dropdown" data-bs-auto-close="true" aria-expanded="false" aria-label="Workspace menu" title="Workspace menu">
                <i class="fa-solid fa-ellipsis" aria-hidden="true"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end workspace-menu">
                <li><a class="dropdown-item" href="<?= e(url('/workspace')) ?>"><i class="fa-solid fa-gear fa-fw me-2" aria-hidden="true"></i>Workspace settings</a></li>
            </ul>
        <?php endif; ?>
    </div>
    <nav class="sidebar-nav">
        <?php foreach ($groups as $heading => $items): ?>
            <div class="sidebar-heading"><?= e($heading) ?></div>
            <ul class="nav flex-column">
            <?php foreach ($items as $item): ?>
                <?php $active = $isActive($item['path']); ?>
                <li class="nav-item"><a class="sidebar-link<?= $active ? ' active' : '' ?>" href="<?= e(url($item['path'])) ?>" <?= $active ? 'aria-current="page"' : '' ?>><i class="fa-solid <?= e($item['icon']) ?> fa-fw" aria-hidden="true"></i><span><?= e($item['label']) ?></span><?php
                    $badgeKind = $item['badge'] ?? false;
                    $showBadge = ($badgeKind === true && $pendingCount > 0) || ($badgeKind === 'review' && $reviewCount > 0);
                    $badgeText = $badgeKind === 'review' ? ($reviewCount > 9 ? '9+' : (string) $reviewCount) : '!';
                    if ($showBadge): ?><span class="sidebar-badge"><?= e($badgeText) ?></span><?php endif; ?></a></li>
            <?php endforeach; ?>
            </ul>
        <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
        <?php if (PermissionHelper::has('time.track')): ?><a class="sidebar-link<?= $isActive('/agent') ? ' active' : '' ?>" href="<?= e(url('/agent')) ?>"><i class="fa-solid fa-desktop fa-fw" aria-hidden="true"></i><span>Desktop Agent</span></a><?php endif; ?>
        <a class="sidebar-link<?= $isActive('/profile') ? ' active' : '' ?>" href="<?= e(url('/profile')) ?>"><i class="fa-solid fa-user fa-fw" aria-hidden="true"></i><span>My profile</span></a>
        <div class="sidebar-user"><span class="avatar" aria-hidden="true"><?= e($initials) ?></span><span class="sidebar-user-text"><span class="sidebar-user-name"><?= e($me['name']) ?></span><span class="sidebar-user-role"><?= e(ucfirst((string) $me['role'])) ?></span></span></div>
    </div>
</aside>
<div class="app-main">
    <header class="app-topbar">
        <button class="btn btn-icon d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#appSidebar" aria-controls="appSidebar" aria-label="Open menu"><i class="fa-solid fa-bars" aria-hidden="true"></i></button>
        <div class="topbar-workspace"><strong><?= e($appName) ?></strong><span>Time &amp; project management</span></div>
        <div class="topbar-actions">
            <?php if (PermissionHelper::has('notifications.view')): ?>
            <div class="dropdown">
                <button class="btn btn-icon position-relative" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside"
                        aria-expanded="false" aria-label="Notifications"
                        data-notification-toggle data-url="<?= e(url('/notifications/unread')) ?>">
                    <i class="fa-regular fa-bell" aria-hidden="true"></i>
                    <span class="badge-dot" data-notification-badge<?= $unreadCount > 0 ? '' : ' hidden' ?>><?= $unreadCount > 9 ? '9+' : (int) $unreadCount ?></span>
                </button>
                <div class="dropdown-menu dropdown-menu-end notification-menu" data-notification-menu>
                    <div class="notification-head">
                        <strong>Notifications</strong>
                        <button type="button" class="btn btn-link btn-sm p-0" data-notification-read-all data-url="<?= e(url('/notifications/read-all')) ?>">Mark all read</button>
                    </div>
                    <div class="notification-list" data-notification-list>
                        <?php if ($recentNotifications === []): ?>
                            <div class="notification-empty" data-notification-empty>You are all caught up.</div>
                        <?php else: ?>
                            <?php foreach ($recentNotifications as $note): ?>
                                <a class="notification-item<?= (int) $note['is_read'] === 0 ? ' is-unread' : '' ?>"
                                   href="<?= e($note['link'] ?: url('/dashboard')) ?>"
                                   data-notification-item data-id="<?= (int) $note['id'] ?>"
                                   data-read-url="<?= e(url('/notifications/' . (int) $note['id'] . '/read')) ?>">
                                    <span class="feed-icon feed-<?= e((string) $note['type']) ?>" aria-hidden="true"><i class="fa-solid <?= e($note['type'] === 'success' ? 'fa-circle-check' : ($note['type'] === 'warning' ? 'fa-triangle-exclamation' : ($note['type'] === 'danger' ? 'fa-circle-exclamation' : 'fa-circle-info'))) ?>"></i></span>
                                    <span class="notification-body">
                                        <span class="notification-title"><?= e($note['title']) ?></span>
                                        <?php if (!empty($note['message'])): ?><span class="notification-text"><?= e($note['message']) ?></span><?php endif; ?>
                                        <span class="notification-time"><?= e(FormatHelper::datetime((string) $note['created_at'], 'M j, H:i')) ?></span>
                                    </span>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <a class="notification-foot" href="<?= e(url('/dashboard')) ?>#notifications">View all notifications</a>
                </div>
            </div>
            <?php endif; ?>
            <button class="btn btn-icon" type="button" data-theme-toggle aria-label="Toggle dark mode" title="Toggle dark mode"><i class="fa-regular fa-moon" aria-hidden="true"></i></button>
            <div class="dropdown"><button class="btn btn-user dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><span class="avatar avatar-sm" aria-hidden="true"><?= e($initials) ?></span><span class="d-none d-md-inline"><?= e($me['name']) ?></span></button><ul class="dropdown-menu dropdown-menu-end"><li class="dropdown-header"><?= e($me['email']) ?></li><li><a class="dropdown-item" href="<?= e(url('/profile')) ?>"><i class="fa-solid fa-user-gear fa-fw me-2" aria-hidden="true"></i>My profile</a></li><li><hr class="dropdown-divider"></li><li><form method="post" action="<?= e(url('/logout')) ?>" class="m-0"><?= csrf_field() ?><button type="submit" class="dropdown-item"><i class="fa-solid fa-arrow-right-from-bracket fa-fw me-2" aria-hidden="true"></i>Sign out</button></form></li></ul></div>
        </div>
    </header>
    <main class="app-content" id="main-content">
