<?php
/**
 * Sign-in page ("auth" layout: no sidebar).
 *
 * Errors and the previously typed e-mail come from the flashed form state
 * (field_error() / old()); one-off notices such as "You have been signed out" come from flash_pull().
 * The password is never sent back to the form.
 */

$appName = SettingsService::appName();
$flashes = flash_pull();
$emailError    = field_error('email');
$passwordError = field_error('password');
?>
<div class="login-page">
    <section class="login-aside" aria-hidden="true">
        <div class="login-aside-inner">
            <div class="brand-link">
                <?= BrandingHelper::mark() ?>
                <span class="brand-name"><?= e($appName) ?></span>
            </div>

            <p class="login-claim"><?= e(SettingsService::systemString('login_headline', 'See where every hour goes.')) ?></p>
            <?php $loginSub = trim(SettingsService::systemString('login_subtext', '')); ?>
            <?php if ($loginSub !== ''): ?><p class="login-sub"><?= e($loginSub) ?></p><?php endif; ?>

            <div class="week-ruler">
                <div class="ruler-day" style="--h: 58%"><span class="ruler-bar"></span><span class="ruler-label">Mon</span></div>
                <div class="ruler-day" style="--h: 82%"><span class="ruler-bar"></span><span class="ruler-label">Tue</span></div>
                <div class="ruler-day" style="--h: 46%"><span class="ruler-bar"></span><span class="ruler-label">Wed</span></div>
                <div class="ruler-day is-live" style="--h: 70%"><span class="ruler-bar"></span><span class="ruler-label">Thu</span></div>
                <div class="ruler-day" style="--h: 24%"><span class="ruler-bar"></span><span class="ruler-label">Fri</span></div>
            </div>
        </div>
    </section>

    <main class="login-main" id="main-content">
        <div class="login-card">
            <div class="login-mobile-brand d-lg-none">
                <?= BrandingHelper::mark() ?>
                <span class="brand-name"><?= e($appName) ?></span>
            </div>

            <h1 class="login-title">Sign in</h1>
            <p class="login-lead">Use the email and password for your account.</p>

            <?php foreach ($flashes as $type => $messages): ?>
                <?php foreach ((array) $messages as $message): ?>
                    <div class="alert alert-<?= e($type) ?> d-flex align-items-start gap-2" role="<?= $type === 'danger' ? 'alert' : 'status' ?>">
                        <i class="fa-solid fa-circle-info mt-1" aria-hidden="true"></i>
                        <div><?= e($message) ?></div>
                    </div>
                <?php endforeach; ?>
            <?php endforeach; ?>

            <?php if ($emailError !== null && $passwordError === null): ?>
                <div class="alert alert-danger d-flex align-items-start gap-2" role="alert" id="login-error">
                    <i class="fa-solid fa-circle-exclamation mt-1" aria-hidden="true"></i>
                    <div><?= e($emailError) ?></div>
                </div>
            <?php endif; ?>

            <form method="post" action="<?= e(url('/login')) ?>" novalidate data-single-submit>
                <?= csrf_field() ?>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" id="email" name="email" class="form-control form-control-lg<?= $passwordError === null && $emailError !== null ? ' is-invalid' : '' ?>"
                           value="<?= e(old('email')) ?>" autocomplete="username" autocapitalize="none" spellcheck="false"
                           required autofocus<?= $emailError !== null ? ' aria-describedby="login-error"' : '' ?>>
                </div>

                <div class="mb-4">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group input-group-lg has-validation">
                        <input type="password" id="password" name="password" class="form-control<?= $passwordError !== null ? ' is-invalid' : '' ?>"
                               autocomplete="current-password" required>
                        <button type="button" class="btn btn-outline-secondary" data-toggle-password="#password" aria-label="Show password" aria-pressed="false">
                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                        </button>
                        <?php if ($passwordError !== null): ?>
                            <div class="invalid-feedback"><?= e($passwordError) ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-lg w-100">Sign in</button>
            </form>

            <p class="login-foot"><a href="<?= e(url('/forgot-password')) ?>">Forgot your password?</a></p>
        </div>
    </main>
</div>
