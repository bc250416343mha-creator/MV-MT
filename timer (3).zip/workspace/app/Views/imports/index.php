<?php declare(strict_types=1); ?>
<div class="page-head d-flex flex-wrap justify-content-between align-items-center gap-3">
  <div><h1 class="page-heading mb-1">Import data</h1><p class="text-muted mb-0">Import your old team, clients, projects, tasks and historical time from CSV files.</p></div>
</div>
<div class="card mb-4"><div class="card-body">
<form method="post" action="<?= e(url('/import')) ?>" enctype="multipart/form-data" class="row g-3 align-items-end">
<?= csrf_field() ?>
<div class="col-md-5"><label class="form-label">Data type</label><select name="type" class="form-select"><?php foreach($types as $key=>$label): ?><option value="<?= e($key) ?>"<?= $selected===$key?' selected':'' ?>><?= e($label) ?></option><?php endforeach; ?></select></div>
<div class="col-md-5"><label class="form-label">CSV file</label><input type="file" name="csv" accept=".csv,text/csv" class="form-control" required></div>
<div class="col-md-2"><button class="btn btn-primary w-100" type="submit"><i class="fa-solid fa-upload me-2"></i>Import</button></div>
<div class="col-12 d-flex flex-wrap gap-3">
  <div class="form-check"><input class="form-check-input" type="checkbox" name="preview" value="1" id="importPreview"><label class="form-check-label" for="importPreview">Preview (dry run)</label></div>
  <div class="form-check"><input class="form-check-input" type="checkbox" name="all_or_nothing" value="1" id="importTxn"><label class="form-check-label" for="importTxn">All-or-nothing (rollback on any error)</label></div>
</div>
</form></div></div>
<div class="row g-3 mb-4">
<?php foreach($types as $key=>$label): ?><div class="col-md-6 col-xl-3"><div class="card h-100"><div class="card-body"><strong><?= e($label) ?></strong><div class="small text-muted mt-2"><a href="<?= e(url('/assets/imports/samples/'.$key.'.csv')) ?>" download="<?= e($key.'.csv') ?>">Download sample CSV</a></div></div></div></div><?php endforeach; ?>
</div>
<div class="alert alert-info"><strong>Import order:</strong> Users → Clients → Projects → Project members → Tasks → Task assignees → Time entries → Schedules. Team members are imported through <strong>Users</strong>; the Team page then derives team membership from project assignments.</div>
<?php if ($result !== null): ?><div class="card"><div class="card-header"><strong>Import result</strong></div><div class="card-body"><div class="row text-center g-3 mb-3"><div class="col-4"><div class="fs-4 fw-semibold"><?= (int)$result['created'] ?></div><div class="small text-muted">Created</div></div><div class="col-4"><div class="fs-4 fw-semibold"><?= (int)$result['updated'] ?></div><div class="small text-muted">Updated</div></div><div class="col-4"><div class="fs-4 fw-semibold"><?= (int)$result['skipped'] ?></div><div class="small text-muted">Skipped / errors</div></div></div><?php if(!empty($result['preview'])): ?><div class="alert alert-secondary">Preview only. No rows were written.</div><?php endif; ?><?php if(!empty($result['passwords_generated'])): ?><div class="alert alert-info"><?= (int)$result['passwords_generated'] ?> user(s) were created with a generated password and must change it on first sign-in.</div><?php endif; ?><?php if($result['errors']!==[]): ?><div class="alert alert-warning mb-0"><strong>Rows needing attention:</strong><ul class="mb-0 mt-2"><?php foreach($result['errors'] as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div><?php endif; ?></div></div><?php endif; ?>
