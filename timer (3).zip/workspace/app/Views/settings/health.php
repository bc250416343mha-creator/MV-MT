<?php
/**
 * Admin health diagnostics.
 *
 * @var array<string, mixed> $health
 */

$okBadge = static fn (bool $ok): string => $ok
    ? '<span class="badge text-bg-success">ok</span>'
    : '<span class="badge text-bg-danger">fail</span>';
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Health</h2>
        <p class="page-lead">Server, PHP, filesystem and database checks. Public /health never shows these details.</p>
    </div>
    <?= $okBadge((bool) $health['ok']) ?>
</div>

<div class="row g-4">
    <div class="col-lg-6">
        <section class="panel">
            <div class="panel-head"><h3 class="panel-title">PHP</h3></div>
            <dl class="facts panel-body">
                <div><dt>Version</dt><dd><?= e((string) $health['php_version']) ?> (required <?= e((string) $health['php_required']) ?>) <?= $okBadge((bool) $health['php_ok']) ?></dd></div>
                <?php foreach ((array) $health['extensions'] as $name => $loaded): ?>
                    <div><dt><?= e((string) $name) ?></dt><dd><?= $okBadge((bool) $loaded) ?></dd></div>
                <?php endforeach; ?>
            </dl>
        </section>
    </div>
    <div class="col-lg-6">
        <section class="panel">
            <div class="panel-head"><h3 class="panel-title">Filesystem</h3></div>
            <dl class="facts panel-body">
                <?php foreach ((array) $health['writable'] as $label => $writable): ?>
                    <div><dt><?= e((string) $label) ?></dt><dd><?= $okBadge((bool) $writable) ?></dd></div>
                <?php endforeach; ?>
            </dl>
        </section>
    </div>
    <div class="col-lg-6">
        <section class="panel">
            <div class="panel-head"><h3 class="panel-title">Database</h3></div>
            <dl class="facts panel-body">
                <div><dt>Connectivity</dt><dd><?= $okBadge((bool) $health['database_ok']) ?></dd></div>
                <div><dt>PHP time (UTC)</dt><dd><?= e((string) $health['php_time_utc']) ?></dd></div>
                <div><dt>DB time (UTC)</dt><dd><?= e((string) ($health['database_time_utc'] ?? 'unavailable')) ?></dd></div>
                <div><dt>Drift (seconds)</dt><dd><?= e((string) ($health['time_drift_seconds'] ?? 'n/a')) ?></dd></div>
            </dl>
        </section>
    </div>
    <div class="col-lg-6">
        <section class="panel">
            <div class="panel-head"><h3 class="panel-title">Configuration</h3></div>
            <dl class="facts panel-body">
                <div><dt>APP_KEY (desktop-agent pairing and SMTP password)</dt><dd><?= $okBadge((bool) ($health['app_key_ok'] ?? false)) ?></dd></div>
                <div><dt>Session bound to browser</dt><dd><?= !empty($health['bind_session_to_browser']) ? 'on' : 'off' ?></dd></div>
            </dl>
            <?php if (empty($health['app_key_ok'])): ?>
                <p class="panel-body small text-danger mb-0">APP_KEY is empty or still the placeholder, so desktop-agent pairing codes are not issued. Set a random 32+ character secret in config/config.php.</p>
            <?php endif; ?>
        </section>
    </div>
    <div class="col-lg-6">
        <section class="panel">
            <div class="panel-head"><h3 class="panel-title">Schema</h3></div>
            <div class="panel-body">
                <?php if ((array) $health['schema_missing'] === []): ?>
                    <p class="mb-0">Required tables and columns are present. <?= $okBadge(true) ?></p>
                <?php else: ?>
                    <p>Missing:</p>
                    <ul>
                        <?php foreach ((array) $health['schema_missing'] as $item): ?>
                            <li><?= e((string) $item) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </section>
    </div>
</div>
