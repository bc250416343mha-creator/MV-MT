<?php
/**
 * Team setup: teams grouped by project, with the approval chain for each.
 *
 * @var bool $ready
 * @var list<array<string, mixed>> $rows
 * @var array<int, list<array{id: int, name: string}>> $members
 * @var list<array<string, mixed>> $projects
 * @var int $projectId
 * @var string $search
 */

$byProject = [];
foreach ($rows as $row) {
    $byProject[(int) $row['project_id']][] = $row;
}
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Team setup</h2>
        <p class="page-lead">Build the approval hierarchy: project &rarr; team manager &rarr; teams &rarr; members.</p>
    </div>
    <?php if ($ready): ?>
        <a class="btn btn-primary" href="<?= e(url('/teams/create' . ($projectId > 0 ? '?project_id=' . $projectId : ''))) ?>">
            <i class="fa-solid fa-plus me-1" aria-hidden="true"></i>New team
        </a>
    <?php endif; ?>
</div>

<?php if (!$ready): ?>
    <div class="alert alert-warning" role="alert">
        Team tables are not installed yet. Run <code>database/UPGRADE_LIVE.sql</code> on the live database, then reload this page.
    </div>
<?php else: ?>
    <div class="alert alert-info small" role="note">
        <div class="fw-semibold mb-1"><i class="fa-solid fa-sitemap me-1" aria-hidden="true"></i>Who approves a timesheet</div>
        A <strong>member</strong> submits to their <strong>team manager</strong>, the <strong>project manager</strong> and <strong>admins</strong>.
        A <strong>team manager</strong> submits to the project manager and admins.
        The project manager is chosen on the project itself (Projects &rarr; Edit). People who are on a project but in no team go to that project's manager and admins.
    </div>

    <form method="get" action="<?= e(url('/teams')) ?>" class="filter-bar">
        <div class="filter-search">
            <label for="team-q" class="visually-hidden">Search teams</label>
            <input type="search" id="team-q" name="q" class="form-control" placeholder="Search team or project" value="<?= e($search) ?>">
        </div>
        <div>
            <label for="team-project" class="visually-hidden">Project</label>
            <select id="team-project" name="project_id" class="form-select">
                <option value="0">All projects</option>
                <?php foreach ($projects as $project): ?>
                    <option value="<?= (int) $project['id'] ?>"<?= $projectId === (int) $project['id'] ? ' selected' : '' ?>><?= e((string) $project['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-outline-secondary">Filter</button>
    </form>

    <?php if ($byProject === []): ?>
        <section class="panel">
            <div class="empty-state">
                <i class="fa-solid fa-sitemap" aria-hidden="true"></i>
                <p><?= $search !== '' || $projectId > 0 ? 'No teams match these filters.' : 'No teams yet. Create a team under a project to start routing approvals.' ?></p>
            </div>
        </section>
    <?php endif; ?>

    <?php foreach ($byProject as $pid => $teams): ?>
        <?php $first = $teams[0]; ?>
        <section class="panel mb-4">
            <div class="panel-head">
                <h2 class="panel-title">
                    <?= e((string) $first['project_name']) ?>
                    <span class="count-pill"><?= count($teams) ?></span>
                </h2>
                <div class="small">
                    <i class="fa-solid fa-user-tie me-1" aria-hidden="true"></i>Project manager:
                    <?php if (!empty($first['project_manager_name'])): ?>
                        <strong><?= e((string) $first['project_manager_name']) ?></strong>
                    <?php else: ?>
                        <span class="text-warning">not set</span>
                        <a href="<?= e(url('/projects/' . (int) $pid . '/edit')) ?>">set on project</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table data-table mb-0">
                    <thead>
                        <tr>
                            <th>Team</th>
                            <th>Team manager</th>
                            <th>Members</th>
                            <th>Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($teams as $team): ?>
                            <?php $list = $members[(int) $team['id']] ?? []; ?>
                            <tr>
                                <td class="fw-semibold"><?= e((string) $team['name']) ?></td>
                                <td><?= !empty($team['manager_name']) ? e((string) $team['manager_name']) : '<span class="text-muted">—</span>' ?></td>
                                <td>
                                    <?php if ($list === []): ?>
                                        <span class="text-muted">No members</span>
                                    <?php else: ?>
                                        <span class="count-pill"><?= count($list) ?></span>
                                        <span class="small text-muted"><?= e(implode(', ', array_map(static fn (array $m): string => $m['name'], array_slice($list, 0, 4)))) ?><?= count($list) > 4 ? ' +' . (count($list) - 4) . ' more' : '' ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><span class="status-badge status-<?= (string) $team['status'] === 'active' ? 'completed' : 'planning' ?>"><?= e(ucfirst((string) $team['status'])) ?></span></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/teams/' . (int) $team['id'] . '/edit')) ?>">Edit</a>
                                      <?php
                                        $taskCount = (int) ($team['task_count'] ?? 0);
                                        $confirm = 'Delete team "' . (string) $team['name'] . '"? Members keep their accounts and project access.';
                                        if ($taskCount > 0) {
                                            $confirm .= ' ' . $taskCount . ' open task' . ($taskCount === 1 ? '' : 's') . ' will become project-level.';
                                        }
                                      ?>
                                      <form method="post" action="<?= e(url('/teams/' . (int) $team['id'] . '/delete')) ?>" class="d-inline"
                                          data-confirm="<?= e($confirm) ?>">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php endforeach; ?>
<?php endif; ?>
