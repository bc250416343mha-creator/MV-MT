<?php
/**
 * Invite a person by email. Existing accounts require explicit confirmation.
 *
 * @var list<array<string, mixed>> $roles
 * @var list<array<string, mixed>> $projects
 * @var list<array<string, mixed>> $tasks
 * @var list<array<string, mixed>> $teams
 * @var list<string> $statuses
 * @var array<string, mixed>|null $existing
 * @var array<string, mixed>|null $posted
 * @var bool $smtpReady
 * @var int $defaultExpiry
 */

$posted = is_array($posted) ? $posted : [];
$val = static fn (string $key, string $default = ''): string => old($key, (string) ($posted[$key] ?? $default));
$selectedRole = $val('role', AuthHelper::ROLE_EMPLOYEE);
$selectedStatus = $val('account_status', 'active');
$selectedProjects = array_map('intval', old_array('project_ids'));
$selectedTasks = array_map('intval', old_array('task_ids'));
$selectedTeams = array_map('intval', old_array('team_ids'));
if ($selectedProjects === [] && isset($posted['project_ids']) && is_array($posted['project_ids'])) {
    $selectedProjects = array_map('intval', $posted['project_ids']);
}
if ($selectedTasks === [] && isset($posted['task_ids']) && is_array($posted['task_ids'])) {
    $selectedTasks = array_map('intval', $posted['task_ids']);
}
if ($selectedTeams === [] && isset($posted['team_ids']) && is_array($posted['team_ids'])) {
    $selectedTeams = array_map('intval', $posted['team_ids']);
}
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Invite user</h2>
        <p class="page-lead">Send an email so they can create their own password. No password is ever emailed.</p>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <a class="btn btn-outline-secondary" href="<?= e(url('/users/invitations')) ?>">Invitations</a>
        <a class="btn btn-outline-secondary" href="<?= e(url('/users')) ?>"><i class="fa-solid fa-arrow-left me-1" aria-hidden="true"></i>Back to users</a>
    </div>
</div>

<?php if (!$smtpReady): ?>
    <div class="alert alert-warning" role="status">
        SMTP is not configured. Save the invitation, then add the mail server under
        <a href="<?= e(url('/settings#smtp')) ?>">System settings</a> and resend.
    </div>
<?php endif; ?>

<?php if (is_array($existing)): ?>
    <div class="alert alert-info" role="status">
        <strong><?= e((string) $existing['email']) ?></strong> already has an account
        (<?= e((string) ($existing['name'] ?? '')) ?>, <?= e((string) ($existing['role_name'] ?? $existing['role'] ?? '')) ?>,
        <?= e((string) ($existing['status'] ?? '')) ?>).
        Confirm below to assign the selected projects and tasks. The existing role is not changed unless you have role-management permission and choose a different role.
    </div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-xl-8">
        <section class="panel">
            <form method="post" action="<?= e(url('/users/invite')) ?>" novalidate data-single-submit class="panel-body invite-form" id="invite-form">
                <?= csrf_field() ?>
                <?php if (is_array($existing) && $posted !== []): ?>
                    <input type="hidden" name="confirm_existing" value="1">
                <?php endif; ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Full name</label>
                        <input type="text" id="name" name="name" maxlength="120" required autocomplete="name"
                               class="form-control<?= field_error('name') ? ' is-invalid' : '' ?>" value="<?= e($val('name', (string) ($existing['name'] ?? ''))) ?>">
                        <?php if (field_error('name')): ?><div class="invalid-feedback"><?= e(field_error('name')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" id="email" name="email" maxlength="190" required autocomplete="email"
                               class="form-control<?= field_error('email') ? ' is-invalid' : '' ?>" value="<?= e($val('email', (string) ($existing['email'] ?? ''))) ?>">
                        <?php if (field_error('email')): ?><div class="invalid-feedback"><?= e(field_error('email')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="job_title" class="form-label">Job title</label>
                        <input type="text" id="job_title" name="job_title" maxlength="100"
                               class="form-control<?= field_error('job_title') ? ' is-invalid' : '' ?>" value="<?= e($val('job_title')) ?>">
                        <?php if (field_error('job_title')): ?><div class="invalid-feedback"><?= e(field_error('job_title')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="tel" id="phone" name="phone" maxlength="30" autocomplete="tel"
                               class="form-control<?= field_error('phone') ? ' is-invalid' : '' ?>" value="<?= e($val('phone')) ?>">
                        <?php if (field_error('phone')): ?><div class="invalid-feedback"><?= e(field_error('phone')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="role" class="form-label">Role</label>
                        <select id="role" name="role" class="form-select<?= field_error('role') ? ' is-invalid' : '' ?>" required>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?= e((string) $role['name']) ?>"<?= $selectedRole === (string) $role['name'] ? ' selected' : '' ?>><?= e((string) $role['display_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (field_error('role')): ?><div class="invalid-feedback"><?= e(field_error('role')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-3">
                        <label for="account_status" class="form-label">Account status after accept</label>
                        <select id="account_status" name="account_status" class="form-select<?= field_error('account_status') ? ' is-invalid' : '' ?>" required>
                            <?php foreach ($statuses as $status): ?>
                                <option value="<?= e($status) ?>"<?= $selectedStatus === $status ? ' selected' : '' ?>><?= e(ucfirst($status)) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (field_error('account_status')): ?><div class="invalid-feedback"><?= e(field_error('account_status')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-3">
                        <label for="expires_days" class="form-label">Link expires (days)</label>
                        <input type="number" id="expires_days" name="expires_days" min="1" max="90" required
                               class="form-control<?= field_error('expires_days') ? ' is-invalid' : '' ?>" value="<?= e($val('expires_days', (string) $defaultExpiry)) ?>">
                        <?php if (field_error('expires_days')): ?><div class="invalid-feedback"><?= e(field_error('expires_days')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-12">
                        <label for="project_ids" class="form-label">Projects</label>
                        <select id="project_ids" name="project_ids[]" class="form-select" multiple size="8" data-invite-projects>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?= (int) $project['id'] ?>"<?= in_array((int) $project['id'], $selectedProjects, true) ? ' selected' : '' ?>><?= e((string) $project['name']) ?><?php if (!empty($project['project_code'])): ?> (<?= e((string) $project['project_code']) ?>)<?php endif; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">Hold Ctrl or Cmd to select several. Assigned as project members.</div>
                    </div>
                    <?php if ($tasks !== []): ?>
                        <div class="col-12">
                            <label for="task_ids" class="form-label">Tasks</label>
                            <select id="task_ids" name="task_ids[]" class="form-select" multiple size="8" data-invite-tasks>
                                <?php foreach ($tasks as $task): ?>
                                    <option value="<?= (int) $task['id'] ?>" data-project-id="<?= (int) $task['project_id'] ?>"<?= in_array((int) $task['id'], $selectedTasks, true) ? ' selected' : '' ?>><?= e((string) $task['project_name']) ?> — <?= e((string) $task['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">Tasks outside the selected projects are ignored.</div>
                        </div>
                    <?php endif; ?>
                    <?php if ($teams !== []): ?>
                        <div class="col-12">
                            <label for="team_ids" class="form-label">Teams</label>
                            <select id="team_ids" name="team_ids[]" class="form-select" multiple size="5">
                                <?php foreach ($teams as $team): ?>
                                    <option value="<?= (int) $team['id'] ?>"<?= in_array((int) $team['id'], $selectedTeams, true) ? ' selected' : '' ?>><?= e((string) $team['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="mt-4 d-flex gap-2 flex-wrap">
                    <button type="submit" class="btn btn-primary"><?= is_array($existing) ? 'Assign to existing account' : 'Send invitation' ?></button>
                    <a class="btn btn-outline-secondary" href="<?= e(url('/users')) ?>">Cancel</a>
                </div>
            </form>
        </section>
    </div>
</div>
<script src="<?= e(asset('js/invite-form.js')) ?>"></script>
