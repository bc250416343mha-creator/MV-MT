<?php
/**
 * Admin invitation management: invite, list, view, resend, cancel, assign existing.
 */

declare(strict_types=1);

final class InvitationController extends Controller
{
    private InvitationService $service;

    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER]);
        $this->service = new InvitationService();
    }

    /** GET /users/invite */
    public function create(Request $request, array $params): void
    {
        PermissionHelper::require('users.create');
        $this->ensureInstalled();

        $existing = null;
        $existingId = (int) $request->input('existing', 0);
        if ($existingId > 0) {
            $existing = Database::fetchOne(
                'SELECT u.id, u.name, u.email, r.name AS role, r.display_name AS role_name, u.status
                 FROM users u INNER JOIN roles r ON r.id = u.role_id WHERE u.id = :id LIMIT 1',
                ['id' => $existingId]
            );
        }

        $this->renderForm($existing, null);
    }

    /** POST /users/invite */
    public function store(Request $request, array $params): void
    {
        PermissionHelper::require('users.create');
        $this->ensureInstalled();
        $this->assertInviteRate();

        $data = $this->validate([
            'name' => 'required|string|max:120',
            'email' => 'required|email|max:190',
            'role' => 'required|in:' . implode(',', AuthHelper::ROLES),
            'job_title' => 'nullable|string|max:100',
            'phone' => ['nullable', 'string', 'max:30', 'regex:/^[0-9+().\-\s]+$/'],
            'account_status' => 'required|in:' . implode(',', InvitationService::ACCOUNT_STATUSES),
            'expires_days' => 'required|int|min:1|max:90',
        ], '/users/invite', $this->labels());

        $confirmExisting = $request->input('confirm_existing') === '1';
        $result = $this->service->invite(
            $data,
            $this->postedIds('project_ids'),
            $this->postedIds('task_ids'),
            $this->postedIds('team_ids'),
            $confirmExisting
        );

        if (!empty($result['existing']) && !$confirmExisting) {
            $this->renderForm($result['existing'], array_merge($data, [
                'project_ids' => $this->postedIds('project_ids'),
                'task_ids' => $this->postedIds('task_ids'),
                'team_ids' => $this->postedIds('team_ids'),
            ]));

            return;
        }

        if (!$result['ok']) {
            $this->flash('danger', (string) ($result['error'] ?? 'The invitation could not be sent.'));
            if (!empty($result['invitation_id'])) {
                $this->redirect('/users/invitations');
            }
            $this->backWithErrors('/users/invite', ['email' => (string) ($result['error'] ?? 'Could not send invitation.')]);
        }

        if (!empty($result['assigned'])) {
            $this->flash('success', 'That person already has an account. The selected projects and tasks were assigned.');
            $this->redirect('/users');
        }

        $this->flash('success', 'Invitation sent to ' . strtolower((string) $data['email']) . '.');
        $this->redirect('/users/invitations');
    }

    /** GET /users/invitations */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('users.view');
        $this->ensureInstalled();

        $filters = [
            'q' => trim((string) $request->input('q', '')),
            'status' => (string) $request->input('status', 'all'),
        ];
        if (!in_array($filters['status'], array_merge(['all'], UserInvitation::STATUSES), true)) {
            $filters['status'] = 'all';
        }

        $result = (new UserInvitation())->search($filters, (int) $request->input('page', 1), 20);

        $this->render('users/invitations', [
            'pageTitle' => 'Invitations',
            'result' => $result,
            'filters' => $filters,
            'statuses' => UserInvitation::STATUSES,
            'canManage' => PermissionHelper::has('users.create'),
            'smtpReady' => SmtpSettings::isConfigured(),
        ]);
    }

    /** GET /users/invitations/{id} */
    public function show(Request $request, array $params): void
    {
        PermissionHelper::require('users.view');
        $this->ensureInstalled();

        $invitation = (new UserInvitation())->findDetailed((int) ($params['id'] ?? 0));
        if ($invitation === null) {
            $this->notFound();
        }

        $this->render('users/invitation_show', [
            'pageTitle' => 'Invitation',
            'invitation' => $invitation,
            'canManage' => PermissionHelper::has('users.create'),
        ]);
    }

    /** POST /users/invitations/{id}/resend */
    public function resend(Request $request, array $params): void
    {
        PermissionHelper::require('users.create');
        $this->ensureInstalled();
        $this->assertInviteRate();

        $result = $this->service->resend((int) ($params['id'] ?? 0));
        if ($result['ok']) {
            $this->flash('success', 'Invitation was resent.');
        } else {
            $this->flash('danger', $result['error']);
        }
        $this->redirect('/users/invitations');
    }

    /** POST /users/invitations/{id}/cancel */
    public function cancel(Request $request, array $params): void
    {
        PermissionHelper::require('users.create');
        $this->ensureInstalled();

        $result = $this->service->cancel((int) ($params['id'] ?? 0));
        if ($result['ok']) {
            $this->flash('success', 'Invitation was cancelled.');
        } else {
            $this->flash('danger', $result['error']);
        }
        $this->redirect('/users/invitations');
    }

    /**
     * @param array<string, mixed>|null $existing
     * @param array<string, mixed>|null $posted
     */
    private function renderForm(?array $existing, ?array $posted): void
    {
        $this->render('users/invite', [
            'pageTitle' => 'Invite user',
            'roles' => $this->service->grantableRoles(),
            'projects' => $this->service->projectOptions(),
            'tasks' => $this->service->taskOptions(),
            'teams' => $this->service->teamOptions(),
            'statuses' => InvitationService::ACCOUNT_STATUSES,
            'existing' => $existing,
            'posted' => $posted,
            'smtpReady' => SmtpSettings::isConfigured(),
            'defaultExpiry' => SmtpSettings::inviteExpiryDays(),
        ]);
    }

    private function ensureInstalled(): void
    {
        if (!UserInvitation::installed()) {
            $this->flash('danger', 'Run database/UPGRADE_LIVE.sql to enable invitations.');
            $this->redirect('/users');
        }
    }

    private function assertInviteRate(): void
    {
        if (RateLimitHelper::tooMany('invitation.sent', $this->request->ip(), 20, 15)
            || RateLimitHelper::tooMany('invitation.resent', $this->request->ip(), 20, 15)
            || RateLimitHelper::tooMany('invitation.created', $this->request->ip(), 30, 15)) {
            LoggerHelper::warning('Invitation rate limit', ['ip' => $this->request->ip()]);
            $this->flash('danger', 'Too many invitation emails from this address. Wait a few minutes and try again.');
            $this->redirect('/users/invitations');
        }
    }

    /** @return list<int> */
    private function postedIds(string $field): array
    {
        $raw = $this->request->input($field, []);
        if (!is_array($raw)) {
            $raw = [$raw];
        }

        return array_values(array_unique(array_filter(
            array_map('intval', $raw),
            static fn (int $id): bool => $id > 0
        )));
    }

    /** @return array<string, string> */
    private function labels(): array
    {
        return [
            'name' => 'Full name',
            'email' => 'Email',
            'role' => 'Role',
            'job_title' => 'Job title',
            'phone' => 'Phone',
            'account_status' => 'Account status',
            'expires_days' => 'Invitation expiry',
        ];
    }
}
