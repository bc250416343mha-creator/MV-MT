<?php
/**
 * Read-side of the audit trail (activity_logs). Writes happen through
 * LoggerHelper::logEvent() so that every entry carries the same shape.
 *
 * The table is append-only from the application's point of view; this model only
 * reads, filters and deletes-on-retention are intentionally not offered.
 */

declare(strict_types=1);

final class ActivityLog extends Model
{
    protected string $table = 'activity_logs';

    protected bool $timestamps = false;

    protected array $columns = [
        'id', 'user_id', 'action', 'module', 'entity_type', 'entity_id',
        'ip_address', 'user_agent', 'meta', 'old_value', 'new_value', 'created_at',
    ];

    protected array $fillable = [
        'user_id', 'action', 'module', 'entity_type', 'entity_id',
        'ip_address', 'user_agent', 'meta', 'old_value', 'new_value',
    ];

    /** True when the Phase 9 audit table is present. */
    public static function installed(): bool
    {
        return SchemaHelper::tableExists('activity_logs');
    }

    /**
     * Filtered, paginated audit rows joined to the acting user.
     *
     * @param array{q?: string, module?: string, action?: string, user_id?: int, from?: string, to?: string} $filters
     * @return array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int}
     */
    public function search(array $filters, int $page = 1, int $perPage = 25): array
    {
        [$where, $params] = $this->buildFilters($filters);

        $total = (int) Database::fetchValue(
            "SELECT COUNT(*) FROM activity_logs a LEFT JOIN users u ON u.id = a.user_id{$where}",
            $params
        );

        $perPage = min(100, max(1, $perPage));
        $pages   = max(1, (int) ceil($total / $perPage));
        $page    = min(max(1, $page), $pages);
        $offset  = ($page - 1) * $perPage;

        $items = Database::fetchAll(
            "SELECT a.id, a.user_id, a.action, a.module, a.entity_type, a.entity_id,
                    a.ip_address, a.meta, a.old_value, a.new_value, a.created_at,
                    u.name AS user_name, u.email AS user_email
             FROM activity_logs a
             LEFT JOIN users u ON u.id = a.user_id{$where}
             ORDER BY a.created_at DESC, a.id DESC
             LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        return [
            'items'    => $items,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $perPage,
            'pages'    => $pages,
        ];
    }

    /**
     * Distinct modules present in the log, for the filter dropdown.
     *
     * @return list<string>
     */
    public function modules(): array
    {
        try {
            $rows = Database::fetchAll(
                "SELECT DISTINCT module FROM activity_logs
                 WHERE module IS NOT NULL AND module <> ''
                 ORDER BY module ASC"
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('ActivityLog modules lookup failed', ['error' => $e->getMessage()]);
            return [];
        }

        return array_values(array_filter(array_map(static fn (array $r): string => (string) $r['module'], $rows)));
    }

    /** Decode the meta/old/new JSON columns for display. */
    public function decorate(array $row): array
    {
        foreach (['meta', 'old_value', 'new_value'] as $key) {
            $row[$key . '_pretty'] = $this->pretty((string) ($row[$key] ?? ''));
        }

        return $row;
    }

    private function pretty(string $raw): string
    {
        if ($raw === '') {
            return '';
        }

        $decoded = json_decode($raw, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            return (string) json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }

        return $raw;
    }

    /**
     * @param array<string, mixed> $filters
     * @return array{0: string, 1: array<string, mixed>}
     */
    private function buildFilters(array $filters): array
    {
        $clauses = [];
        $params  = [];

        $q = trim((string) ($filters['q'] ?? ''));
        if ($q !== '') {
            $clauses[] = '(a.action LIKE :q OR a.module LIKE :q OR u.name LIKE :q OR u.email LIKE :q OR a.ip_address LIKE :q)';
            $params['q'] = '%' . str_replace(['%', '_'], ['\\%', '\\_'], mb_substr($q, 0, 100, 'UTF-8')) . '%';
        }

        $module = (string) ($filters['module'] ?? '');
        if ($module !== '' && $module !== 'all') {
            $clauses[] = 'a.module = :module';
            $params['module'] = mb_substr($module, 0, 60, 'UTF-8');
        }

        $action = trim((string) ($filters['action'] ?? ''));
        if ($action !== '') {
            $clauses[] = 'a.action = :action';
            $params['action'] = mb_substr($action, 0, 100, 'UTF-8');
        }

        $userId = (int) ($filters['user_id'] ?? 0);
        if ($userId > 0) {
            $clauses[] = 'a.user_id = :user_id';
            $params['user_id'] = $userId;
        }

        return [$clauses === [] ? '' : ' WHERE ' . implode(' AND ', $clauses), $params];
    }
}
