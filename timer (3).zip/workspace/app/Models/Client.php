<?php
/**
 * Clients. Full CRUD plus the projects that belong to a client.
 */

declare(strict_types=1);

final class Client extends Model
{
    public const STATUS_ACTIVE   = 'active';
    public const STATUS_INACTIVE = 'inactive';

    public const STATUSES = [self::STATUS_ACTIVE, self::STATUS_INACTIVE];

    protected string $table = 'clients';

    protected array $columns = [
        'id', 'name', 'email', 'phone', 'address', 'status', 'created_at', 'updated_at',
    ];

    protected array $fillable = [
        'name', 'email', 'phone', 'address', 'status',
    ];

    /**
     * Paginated list with optional status/search and a project count.
     *
     * @return array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int}
     */
    public function listFiltered(int $page, int $perPage, ?string $status, string $search = ''): array
    {
        $perPage = min(100, max(1, $perPage));
        $where   = [];
        $params  = [];

        if ($status !== null && in_array($status, self::STATUSES, true)) {
            $where[]         = 'c.status = :status';
            $params['status'] = $status;
        }

        $search = trim($search);
        if ($search !== '') {
            $term = '%' . self::like($search) . '%';
            $where[] = '(c.name LIKE :q_name OR c.email LIKE :q_email)';
            $params['q_name']    = $term;
            $params['q_email']   = $term;
        }

        $whereSql = $where === [] ? '' : ' WHERE ' . implode(' AND ', $where);

        $total = (int) Database::fetchValue(
            "SELECT COUNT(*) FROM clients c{$whereSql}",
            $params
        );

        $pages = max(1, (int) ceil($total / $perPage));
        $page  = min(max(1, $page), $pages);

        $params['limit']  = $perPage;
        $params['offset'] = ($page - 1) * $perPage;

        $items = Database::fetchAll(
            "SELECT c.*,
                    (SELECT COUNT(*) FROM projects p WHERE p.client_id = c.id) AS project_count
             FROM clients c
             {$whereSql}
             ORDER BY c.name ASC
             LIMIT :limit OFFSET :offset",
            $params
        );

        return [
            'items'    => $items,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $perPage,
            'pages'    => $pages,
        ];
    }

    /** @return list<array<string, mixed>> */
    public function activeOptions(): array
    {
        return Database::fetchAll(
            "SELECT id, name FROM clients WHERE status = 'active' ORDER BY name ASC"
        );
    }

    /** @return list<array<string, mixed>> */
    public function projects(int $clientId): array
    {
        return Database::fetchAll(
            'SELECT id, project_code, name, status, priority, due_date, estimated_hours
             FROM projects
             WHERE client_id = :id
             ORDER BY name ASC',
            ['id' => $clientId]
        );
    }

    public function projectCount(int $clientId): int
    {
        return (int) Database::fetchValue(
            'SELECT COUNT(*) FROM projects WHERE client_id = :id',
            ['id' => $clientId]
        );
    }

    private static function like(string $value): string
    {
        return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $value);
    }
}
