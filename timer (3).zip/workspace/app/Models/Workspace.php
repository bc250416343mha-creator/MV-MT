<?php

declare(strict_types=1);

final class Workspace extends Model
{
    protected string $table = 'workspaces';

    protected array $columns = [
        'id', 'name', 'logo_path', 'created_by', 'created_at', 'updated_at',
    ];

    protected array $fillable = [
        'name', 'logo_path', 'created_by',
    ];

    public const DEFAULT_SETTINGS = [
        'timesheet_enabled' => '0',
        'hide_tracker' => '0',
        'kiosk_enabled' => '0',
        'default_project_visibility' => 'private',
        'organize_time_by' => 'project_task',
        'duration_format' => 'clock_seconds',
        'week_start' => 'monday',
        'working_days' => 'Mon,Tue,Wed,Thu,Fri',
        'daily_capacity' => '8',
        'favorites_enabled' => '0',
        'favorite_entries_enabled' => '0',
        'required_fields' => '',
        'breaks_enabled' => '0',
        'time_rounding_minutes' => '1',
        'time_approval_enabled' => '0',
        'approval_period' => 'weekly',
        'expense_approval_enabled' => '0',
        'time_off_enabled' => '0',
        'invoicing_enabled' => '0',
        'expenses_enabled' => '0',
        'scheduling_enabled' => '1',
        'activity_monitoring_enabled' => '0',
        'gps_enabled' => '0',
        'screenshots_enabled' => '0',
        'audit_log_enabled' => '1',
        'billable_hours_enabled' => '1',
        'project_creation_policy' => 'admins',
        'task_creation_policy' => 'admins_project_managers',
        'tag_creation_policy' => 'admins',
        'regular_user_time_visibility' => 'own',
        'project_status_visibility' => 'admins',
        'hide_projects' => '0',
        'hide_team' => '0',
        'hide_reports' => '0',
        'timesheet_approver_policy' => 'admins_team_managers',
        'edit_time_others_policy' => 'admins',
        'invoice_manager_policy' => 'admins',
        'lock_time_enabled' => '0',
        'force_timer' => '0',
        'idle_detection_enabled' => '0',
        'idle_threshold_minutes' => '10',
        'idle_warning_seconds' => '60',
        'task_scope_mode' => 'legacy',
        'other_team_tasks_visibility' => 'readonly',
        'members_can_create_subtasks' => '0',
        'task_review_required' => '1',
    ];

    public static function current(): ?array
    {
        return Database::fetchOne(
            'SELECT * FROM workspaces ORDER BY id ASC LIMIT 1'
        );
    }

    public static function currentId(): int
    {
        return (int) Database::fetchValue('SELECT id FROM workspaces ORDER BY id ASC LIMIT 1');
    }

    /** @return array<string,string> */
    public static function settings(int $workspaceId): array
    {
        return SettingsService::workspace($workspaceId);
    }

    public static function putSetting(int $workspaceId, string $key, string $value): void
    {
        if (!array_key_exists($key, self::DEFAULT_SETTINGS)) {
            throw new InvalidArgumentException('Unknown workspace setting.');
        }

        SettingsService::setWorkspace($workspaceId, $key, $value);
    }

    public static function hasSetting(int $workspaceId, string $key, string $expected = '1'): bool
    {
        $settings = self::settings($workspaceId);
        return ($settings[$key] ?? '') === $expected;
    }

    /** @return list<array<string,mixed>> */
    public static function rolesWithPermissions(): array
    {
        return Database::fetchAll(
            'SELECT r.id, r.name, r.display_name, r.description
             FROM roles r ORDER BY r.id ASC'
        );
    }

    /** @return list<array<string,mixed>> */
    public static function permissions(): array
    {
        return Database::fetchAll(
            'SELECT id, name, display_name, module, description
             FROM permissions ORDER BY module ASC, id ASC'
        );
    }

    /** @return array<int,array<string,true>> */
    public static function rolePermissionMap(): array
    {
        $rows = Database::fetchAll(
            'SELECT role_id, permission_id FROM role_permissions'
        );
        $map = [];
        foreach ($rows as $row) {
            $map[(int) $row['role_id']][(int) $row['permission_id']] = true;
        }
        return $map;
    }
}
