# TimeTrack Windows Agent

This agent is the companion to the TimeTrack PHP app for workspace-level computer activity / idle detection.

## What it measures

- System-wide keyboard/mouse activity timestamp via Windows `GetLastInputInfo`.
- A lightweight heartbeat every 30 seconds.
- A simple workstation-lock signal.

It does **not** collect:

- keystrokes
- typed text
- screenshots
- window titles
- application names
- files or documents

Using AutoCAD, Excel, Photoshop, Chrome, YouTube, etc. all count simply as computer activity.

## Pairing

1. Sign in to TimeTrack.
2. Open **Desktop Agent**.
3. Click **Generate pairing code**.
4. Build/run `TimeTrackAgent` on the Windows computer.
5. Enter the TimeTrack URL and the eight-digit code.
6. The agent stores its device token under the user's Windows AppData and starts with Windows.

## Build

Requires the .NET 8 SDK on Windows.

```powershell
dotnet restore
dotnet publish .\TimeTrackAgent\TimeTrackAgent.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true
```

The published executable can be copied to the employee's Windows machine. On first pairing, the app adds itself to the current user's Windows startup registry.

## HTTPS and reverse proxies

The pairing and heartbeat APIs refuse non-HTTPS requests. The Windows agent **must** use `https://`.

If TimeTrack sits behind a reverse proxy (nginx, Cloudflare, a load balancer), set:

```
APP_TRUST_PROXY=true
```

Without that, `isHttps()` stays false and the agent receives `must use HTTPS`.

Set `APP_KEY` to a long random secret (32+ characters): replace the `CHANGE_ME...` placeholder in `config/config.php` (or set the `APP_KEY` environment variable). Pairing codes are HMAC-SHA256 hashed with this key. Until it is set, TimeTrack refuses to issue pairing codes and shows an admin message on the Desktop Agent page.

## Server deployment

1. Upload the PHP TimeTrack files from the main project ZIP.
2. Run `database/UPGRADE_LIVE.sql` once. (The other desktop-agent tables already exist on the live database; `/admin/health` lists any that are missing.)
3. In **Workspace → Features & policies**, enable **Computer activity / idle detection**.
4. Set the idle threshold, normally **10 minutes**.
5. Set the no-response period, normally **60 seconds**.
6. Configure Hostinger cron to run `tools/cron_auto_stop.php` every minute. The script now also enforces expired idle warnings.

The web app is the source of truth for timer state. The Windows agent only reports activity.
