using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using Microsoft.Win32;
using System.Windows.Forms;

namespace TimeTrackAgent;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new AgentApplicationContext());
    }
}

internal sealed class AgentApplicationContext : ApplicationContext
{
    private const string Version = "1.0.0";
    private readonly NotifyIcon _tray;
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(15) };
    private readonly System.Windows.Forms.Timer _heartbeatTimer;
    private AgentConfig _config;
    private bool _busy;

    public AgentApplicationContext()
    {
        _config = AgentConfig.Load();
        _tray = new NotifyIcon
        {
            Icon = SystemIcons.Application,
            Visible = true,
            Text = "TimeTrack Agent",
            ContextMenuStrip = BuildMenu()
        };
        _heartbeatTimer = new System.Windows.Forms.Timer { Interval = 30_000 };
        _heartbeatTimer.Tick += async (_, _) => await HeartbeatAsync();
        _heartbeatTimer.Start();
        _ = HeartbeatAsync();
    }

    private ContextMenuStrip BuildMenu()
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add("Configure / Pair", null, (_, _) => Configure());
        menu.Items.Add("Send heartbeat now", null, async (_, _) => await HeartbeatAsync());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Exit", null, (_, _) => ExitThread());
        return menu;
    }

    private void Configure()
    {
        using var form = new PairForm(_config.BaseUrl);
        if (form.ShowDialog() != DialogResult.OK) return;
        _config.BaseUrl = form.BaseUrl;
        _config.Save();
        _ = PairAsync(form.Code);
    }

    private async Task PairAsync(string code)
    {
        if (string.IsNullOrWhiteSpace(_config.BaseUrl) || string.IsNullOrWhiteSpace(code)) return;
        try
        {
            var payload = new
            {
                code,
                device_id = _config.DeviceId,
                device_name = Environment.MachineName,
                agent_version = Version
            };
            var response = await PostJsonAsync("/api/agent/pair", payload, null);
            if (!response.Ok)
            {
                MessageBox.Show(response.Error ?? "Pairing failed.", "TimeTrack Agent", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            _config.Token = response.Token ?? "";
            _config.DeviceId = response.DeviceId ?? _config.DeviceId;
            _config.AgentVersion = Version;
            _config.Save();
            InstallStartup();
            MessageBox.Show("This computer is now connected to TimeTrack.", "TimeTrack Agent", MessageBoxButtons.OK, MessageBoxIcon.Information);
            await HeartbeatAsync();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "TimeTrack Agent", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task HeartbeatAsync()
    {
        if (_busy || string.IsNullOrWhiteSpace(_config.BaseUrl) || string.IsNullOrWhiteSpace(_config.Token)) return;
        _busy = true;
        try
        {
            var payload = new
            {
                last_activity_unix = Activity.GetLastActivityUnixSeconds(),
                locked = Activity.IsWorkstationLocked(),
                agent_version = Version
            };
            var result = await PostJsonAsync("/api/agent/heartbeat", payload, _config.Token);
            if (!result.Ok && result.HttpStatus == 401)
            {
                _config.Token = "";
                _config.Save();
            }
        }
        catch
        {
            // Network outages are expected. Keep the local state and retry on the next heartbeat.
        }
        finally { _busy = false; }
    }

    private async Task<ApiResult> PostJsonAsync(string path, object payload, string? token)
    {
        var baseUrl = _config.BaseUrl.TrimEnd('/');
        using var request = new HttpRequestMessage(HttpMethod.Post, baseUrl + path);
        request.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        if (!string.IsNullOrWhiteSpace(token)) request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        using var response = await _http.SendAsync(request);
        var raw = await response.Content.ReadAsStringAsync();
        try
        {
            using var doc = JsonDocument.Parse(raw);
            var root = doc.RootElement;
            return new ApiResult(
                response.IsSuccessStatusCode && root.TryGetProperty("ok", out var ok) && ok.GetBoolean(),
                root.TryGetProperty("token", out var tokenEl) ? tokenEl.GetString() : null,
                root.TryGetProperty("device_id", out var deviceEl) ? deviceEl.GetString() : null,
                root.TryGetProperty("error", out var errEl) ? errEl.GetString() : null,
                (int)response.StatusCode);
        }
        catch { return new ApiResult(false, null, null, "The TimeTrack server returned an invalid response.", (int)response.StatusCode); }
    }

    private static void InstallStartup()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true);
            key?.SetValue("TimeTrackAgent", Environment.ProcessPath ?? "TimeTrackAgent.exe");
        }
        catch { }
    }

    protected override void ExitThreadCore()
    {
        _heartbeatTimer.Stop();
        _tray.Visible = false;
        _tray.Dispose();
        _http.Dispose();
        base.ExitThreadCore();
    }

    private sealed record ApiResult(bool Ok, string? Token, string? DeviceId, string? Error, int HttpStatus);
}

internal sealed class AgentConfig
{
    public string BaseUrl { get; set; } = "";
    public string Token { get; set; } = "";
    public string DeviceId { get; set; } = Guid.NewGuid().ToString("N");
    public string AgentVersion { get; set; } = "1.0.0";

    private static string Path => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "TimeTrackAgent", "agent.json");

    public static AgentConfig Load()
    {
        try
        {
            if (File.Exists(Path)) return JsonSerializer.Deserialize<AgentConfig>(File.ReadAllText(Path)) ?? new AgentConfig();
        }
        catch { }
        return new AgentConfig();
    }

    public void Save()
    {
        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(Path)!);
        File.WriteAllText(Path, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
    }
}

internal static class Activity
{
    [StructLayout(LayoutKind.Sequential)]
    private struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }

    [DllImport("user32.dll")]
    private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("kernel32.dll")]
    private static extern uint GetTickCount();

    public static long GetLastActivityUnixSeconds()
    {
        var info = new LASTINPUTINFO { cbSize = (uint)Marshal.SizeOf<LASTINPUTINFO>() };
        if (!GetLastInputInfo(ref info)) return DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        uint idleMs = unchecked(GetTickCount() - info.dwTime);
        return DateTimeOffset.UtcNow.ToUnixTimeSeconds() - (idleMs / 1000);
    }

    public static bool IsWorkstationLocked()
    {
        // A secure Windows desktop normally has no foreground application window.
        // This is a secondary signal; the server still relies on last activity time.
        return GetForegroundWindow() == IntPtr.Zero;
    }
}

internal sealed class PairForm : Form
{
    private readonly TextBox _url = new();
    private readonly TextBox _code = new();

    public string BaseUrl => _url.Text.Trim();
    public string Code => _code.Text.Trim();

    public PairForm(string existingUrl)
    {
        Text = "Connect TimeTrack Agent";
        Width = 440; Height = 230; StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;

        var urlLabel = new Label { Text = "TimeTrack URL", Left = 20, Top = 20, Width = 120 };
        _url.SetBounds(140, 17, 250, 25); _url.Text = existingUrl;
        var codeLabel = new Label { Text = "8-digit code", Left = 20, Top = 60, Width = 120 };
        _code.SetBounds(140, 57, 120, 25); _code.MaxLength = 8;
        var help = new Label { Text = "Open TimeTrack → Desktop Agent → Generate pairing code.", Left = 20, Top = 95, Width = 370, Height = 40 };
        var ok = new Button { Text = "Connect", Left = 230, Top = 145, Width = 100, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "Cancel", Left = 340, Top = 145, Width = 80, DialogResult = DialogResult.Cancel };
        Controls.AddRange(new Control[] { urlLabel, _url, codeLabel, _code, help, ok, cancel });
        AcceptButton = ok; CancelButton = cancel;
    }
}
