<?php
/** Lightweight Step 19 static checks; DB/integration matrix is in docs/STEP20_TEST_MATRIX.md. */
declare(strict_types=1);
require dirname(__DIR__) . '/app/Helpers/Csv.php';
$cases = [
    '=SUM(A1:A2)' => "'=SUM(A1:A2)",
    '+123' => "'+123",
    '-123' => "'-123",
    '@cmd' => "'@cmd",
    "\tformula" => "'\tformula",
    'normal' => 'normal',
];
$failed = [];
foreach ($cases as $in => $expected) {
    $actual = CsvHelper::safeCell($in);
    if ($actual !== $expected) $failed[] = [$in, $expected, $actual];
}
$routes = file_get_contents(dirname(__DIR__) . '/routes/web.php');
if ($routes === false || !str_contains($routes, "'/reports'") || !str_contains($routes, "'/reports/export.csv'")) {
    $failed[] = ['routes', 'report routes', 'missing'];
}
if ($failed !== []) {
    fwrite(STDERR, "Step 19 static checks FAILED\n");
    foreach ($failed as $f) fwrite(STDERR, implode(' | ', array_map('strval', $f)) . "\n");
    exit(1);
}
echo "Step 19 static checks PASSED\n";
echo "- CSV formula-injection cases: PASSED\n";
echo "- Report routes present: PASSED\n";
echo "- Full role/database/browser matrix: see docs/STEP20_TEST_MATRIX.md\n";
