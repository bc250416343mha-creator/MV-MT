These are the key files changed/verified for the current request.
The root of the package is the complete application and should be deployed as a whole.
Do not copy only these files over a different version unless you intentionally want a patch.
