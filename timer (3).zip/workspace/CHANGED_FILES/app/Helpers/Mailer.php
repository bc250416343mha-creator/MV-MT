<?php
/**
 * Single SMTP mailer for the application.
 *
 * Speaks SMTP over a socket (STARTTLS / implicit SSL / none). No third-party
 * library. Secrets never appear in logs, exceptions, or returned errors.
 */

declare(strict_types=1);

final class Mailer
{
    private const TIMEOUT = 20;

    /**
     * @param array<string, string> $headers Extra headers (Reply-To, etc.)
     * @return array{ok: bool, error: string}
     */
    public static function send(string $to, string $subject, string $html, string $text = '', array $headers = []): array
    {
        $to = strtolower(trim($to));
        if (filter_var($to, FILTER_VALIDATE_EMAIL) === false) {
            return ['ok' => false, 'error' => 'The recipient email address is not valid.'];
        }

        if (!SmtpSettings::isConfigured()) {
            return ['ok' => false, 'error' => 'SMTP is not configured. Open System settings to add the mail server.'];
        }

        $fromEmail = SmtpSettings::fromEmail();
        $fromName = SmtpSettings::fromName();
        $host = trim(SmtpSettings::get('smtp_host'));
        $port = max(1, min(65535, (int) SmtpSettings::get('smtp_port', '587')));
        $encryption = strtolower(SmtpSettings::get('smtp_encryption', 'tls'));
        if (!in_array($encryption, SmtpSettings::ENCRYPTIONS, true)) {
            $encryption = 'tls';
        }

        $textBody = $text !== '' ? $text : self::htmlToText($html);
        $messageId = self::messageId($fromEmail);
        $boundary = 'b' . bin2hex(random_bytes(12));

        $packedHeaders = [
            'From' => self::mailbox($fromName, $fromEmail),
            'To' => $to,
            'Subject' => self::encodeHeader($subject),
            'Date' => gmdate('D, d M Y H:i:s O'),
            'Message-ID' => $messageId,
            'MIME-Version' => '1.0',
            'Content-Type' => 'multipart/alternative; boundary="' . $boundary . '"',
            'X-Mailer' => SettingsService::appName(),
        ];
        $replyTo = SmtpSettings::replyTo();
        if ($replyTo !== '' && filter_var($replyTo, FILTER_VALIDATE_EMAIL) !== false) {
            $packedHeaders['Reply-To'] = $replyTo;
        }
        foreach ($headers as $name => $value) {
            if (!preg_match('/^[A-Za-z0-9\-]+$/', $name)) {
                continue;
            }
            if (in_array(strtolower($name), ['from', 'to', 'subject', 'date', 'message-id', 'bcc', 'cc'], true)) {
                continue;
            }
            $packedHeaders[$name] = $value;
        }

        $body = self::mimeBody($boundary, $textBody, $html);
        $data = self::serializeHeaders($packedHeaders) . "\r\n" . $body;

        try {
            self::smtpSend($host, $port, $encryption, $fromEmail, $to, $data);
        } catch (Throwable $e) {
            LoggerHelper::error('SMTP send failed', [
                'to_domain' => self::emailDomain($to),
                'host' => self::safeHost($host),
                'code' => $e->getCode(),
            ]);

            return ['ok' => false, 'error' => self::publicError($e->getMessage())];
        }

        LoggerHelper::info('SMTP message sent', [
            'to_domain' => self::emailDomain($to),
            'host' => self::safeHost($host),
        ]);

        return ['ok' => true, 'error' => ''];
    }

    public static function sendTemplate(string $to, string $template, array $vars): array
    {
        if (!SmtpSettings::enabled()) {
            return ['ok' => false, 'error' => 'SMTP is turned off. Enable it in System settings, then try again.'];
        }

        $rendered = MailTemplate::render($template, $vars);

        return self::send($to, $rendered['subject'], $rendered['html'], $rendered['text']);
    }

    /**
     * @throws RuntimeException
     */
    private static function smtpSend(string $host, int $port, string $encryption, string $from, string $to, string $data): void
    {
        $remote = ($encryption === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port;
        $errno = 0;
        $errstr = '';
        $context = stream_context_create([
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
                'allow_self_signed' => false,
                'SNI_enabled' => true,
                'peer_name' => $host,
            ],
        ]);

        $fp = @stream_socket_client($remote, $errno, $errstr, self::TIMEOUT, STREAM_CLIENT_CONNECT, $context);
        if (!is_resource($fp)) {
            throw new RuntimeException('Could not connect to the mail server.');
        }

        stream_set_timeout($fp, self::TIMEOUT);

        try {
            self::expect($fp, [220]);
            self::command($fp, 'EHLO ' . self::ehloName(), [250]);

            if ($encryption === 'tls') {
                self::command($fp, 'STARTTLS', [220]);
                $crypto = STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
                if (defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT')) {
                    $crypto |= STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT;
                }
                $ok = @stream_socket_enable_crypto($fp, true, $crypto);
                if ($ok !== true) {
                    throw new RuntimeException('Could not start a TLS session with the mail server.');
                }
                self::command($fp, 'EHLO ' . self::ehloName(), [250]);
            }

            $username = SmtpSettings::get('smtp_username');
            $password = SmtpSettings::password();
            if (SmtpSettings::gmailHost() && ($username === '' || $password === '')) {
                throw new RuntimeException('Gmail SMTP needs the full Gmail address as username and an App Password.');
            }
            if ($username !== '' && $password === '') {
                throw new RuntimeException('SMTP username is set but no password is stored.');
            }
            if ($username !== '') {
                self::command($fp, 'AUTH LOGIN', [334]);
                self::command($fp, base64_encode($username), [334]);
                self::command($fp, base64_encode($password), [235]);
            }

            self::command($fp, 'MAIL FROM:<' . $from . '>', [250]);
            self::command($fp, 'RCPT TO:<' . $to . '>', [250, 251]);
            self::command($fp, 'DATA', [354]);
            $written = fwrite($fp, self::dotStuff($data) . "\r\n.\r\n");
            if ($written === false) {
                throw new RuntimeException('Could not send the message body to the mail server.');
            }
            self::expect($fp, [250]);
            try {
                self::command($fp, 'QUIT', [221]);
            } catch (Throwable) {
                // QUIT is polite; a closed socket after DATA success is not a send failure.
            }
        } finally {
            fclose($fp);
        }
    }

    /**
     * @param list<int> $okCodes
     */
    private static function command($fp, string $line, array $okCodes): void
    {
        fwrite($fp, $line . "\r\n");
        self::expect($fp, $okCodes);
    }

    /**
     * @param resource $fp
     * @param list<int> $okCodes
     */
    private static function expect($fp, array $okCodes): void
    {
        $reply = '';
        while (($line = fgets($fp, 2048)) !== false) {
            $reply .= $line;
            if (preg_match('/^\d{3}[\s-]/', $line) !== 1) {
                continue;
            }
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }

        $code = (int) substr($reply, 0, 3);
        if (!in_array($code, $okCodes, true)) {
            throw new RuntimeException('Mail server rejected the message.');
        }
    }

    private static function mimeBody(string $boundary, string $text, string $html): string
    {
        $parts = [
            '--' . $boundary,
            'Content-Type: text/plain; charset=UTF-8',
            'Content-Transfer-Encoding: quoted-printable',
            '',
            quoted_printable_encode($text),
            '--' . $boundary,
            'Content-Type: text/html; charset=UTF-8',
            'Content-Transfer-Encoding: quoted-printable',
            '',
            quoted_printable_encode($html),
            '--' . $boundary . '--',
            '',
        ];

        return implode("\r\n", $parts);
    }

    /** @param array<string, string> $headers */
    private static function serializeHeaders(array $headers): string
    {
        $lines = [];
        foreach ($headers as $name => $value) {
            $value = str_replace(["\r", "\n"], '', $value);
            $lines[] = $name . ': ' . $value;
        }

        return implode("\r\n", $lines);
    }

    private static function mailbox(string $name, string $email): string
    {
        $name = str_replace(["\r", "\n", '"'], '', $name);
        if ($name === '') {
            return $email;
        }

        return self::encodeHeader($name) . ' <' . $email . '>';
    }

    private static function encodeHeader(string $value): string
    {
        $value = str_replace(["\r", "\n"], '', $value);
        if (preg_match('/[^\x20-\x7E]/', $value) !== 1) {
            return $value;
        }

        return '=?UTF-8?B?' . base64_encode($value) . '?=';
    }

    private static function htmlToText(string $html): string
    {
        $text = preg_replace('/<br\s*\/?>/i', "\n", $html) ?? $html;
        $text = preg_replace('/<\/p>/i', "\n\n", $text) ?? $text;
        $text = html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');

        return trim(preg_replace("/[ \t]+/", ' ', $text) ?? $text);
    }

    private static function dotStuff(string $data): string
    {
        $data = str_replace("\r\n", "\n", $data);
        $data = str_replace("\n", "\r\n", $data);
        $data = preg_replace('/^\./m', '..', $data) ?? $data;

        return $data;
    }

    private static function messageId(string $from): string
    {
        $domain = self::emailDomain($from) ?: 'localhost';

        return '<' . bin2hex(random_bytes(12)) . '@' . $domain . '>';
    }

    private static function ehloName(): string
    {
        $host = Request::current()->host();
        $name = explode(':', $host)[0];

        return $name !== '' ? $name : 'localhost';
    }

    private static function emailDomain(string $email): string
    {
        $pos = strrpos($email, '@');

        return $pos === false ? '' : substr($email, $pos + 1);
    }

    private static function safeHost(string $host): string
    {
        return preg_replace('/[^\w.\-]/', '', $host) ?? '';
    }

    private static function publicError(string $technical): string
    {
        $technical = strtolower($technical);
        if (str_contains($technical, 'auth') || str_contains($technical, '535') || str_contains($technical, '534') || str_contains($technical, 'app password')) {
            return SmtpSettings::gmailHost()
                ? 'Gmail rejected the login. Use the full Gmail address as username and a 16-character App Password, not your Google password.'
                : 'The mail server rejected the login. Check the SMTP username and password.';
        }
        if (str_contains($technical, 'connect') || str_contains($technical, 'tls') || str_contains($technical, 'ssl')) {
            return 'Could not connect to the mail server. Check the host, port and encryption.';
        }
        if (str_contains($technical, 'recipient') || str_contains($technical, '550') || str_contains($technical, '551')) {
            return 'The mail server rejected the recipient address.';
        }

        return 'The email could not be sent. Check SMTP settings and try again.';
    }
}
